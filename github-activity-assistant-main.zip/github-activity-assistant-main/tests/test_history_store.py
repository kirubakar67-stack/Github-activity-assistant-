"""Unit tests for HistoryStore and ActivityRecord (app/monitoring/history_store.py)."""

from __future__ import annotations

from pathlib import Path
import pytest

from app.monitoring.history_store import ActivityRecord, HistoryStore


class TestHistoryStore:
    """Test suite for HistoryStore and ActivityRecord."""

    @pytest.fixture
    def store(self, tmp_path: Path) -> HistoryStore:
        """Provide HistoryStore configured with temporary JSON file."""
        return HistoryStore(history_file=tmp_path / "activity_history.json")

    def test_record_serialization(self) -> None:
        """ActivityRecord should convert to/from dictionary accurately."""
        rec = ActivityRecord(
            id="activity-001",
            date="2026-08-19",
            timestamp="2026-08-19T12:00:00Z",
            repository="owner/repo",
            activity_type="documentation",
            target_file="docs/notes.md",
            title="Note update",
            status="committed",
            commit_hash="a1b2c3d",
            commit_message="docs: note update",
            duration=1.5,
        )

        d = rec.to_dict()
        assert d["id"] == "activity-001"
        assert d["status"] == "committed"

        recreated = ActivityRecord.from_dict(d)
        assert recreated.id == "activity-001"
        assert recreated.commit_hash == "a1b2c3d"
        assert recreated.duration == 1.5

    def test_add_and_get_records(self, store: HistoryStore) -> None:
        """Adding records and querying without filters returns all records."""
        rec1 = ActivityRecord(repository="owner/repo1", status="committed", commit_hash="111")
        rec2 = ActivityRecord(repository="owner/repo2", status="failed", error="Dirty tree")

        store.add_record(rec1)
        store.add_record(rec2)

        records = store.get_records()
        assert len(records) == 2
        assert records[0].repository == "owner/repo1"
        assert records[1].status == "failed"

    def test_filter_by_repository_and_status(self, store: HistoryStore) -> None:
        """get_records should correctly filter by repository and status."""
        store.add_record(ActivityRecord(repository="owner/repoA", status="committed"))
        store.add_record(ActivityRecord(repository="owner/repoB", status="committed"))
        store.add_record(ActivityRecord(repository="owner/repoA", status="failed"))

        repo_a_records = store.get_records(repository="owner/repoa")
        assert len(repo_a_records) == 2

        committed_records = store.get_records(status="committed")
        assert len(committed_records) == 2

        failed_repo_a = store.get_records(repository="owner/repoa", status="failed")
        assert len(failed_repo_a) == 1

    def test_filter_by_date_range(self, store: HistoryStore) -> None:
        """get_records should correctly filter within date bounds."""
        store.add_record(ActivityRecord(date="2026-08-17", title="Day 17"))
        store.add_record(ActivityRecord(date="2026-08-18", title="Day 18"))
        store.add_record(ActivityRecord(date="2026-08-19", title="Day 19"))

        ranged = store.get_records(from_date="2026-08-18", to_date="2026-08-19")
        assert len(ranged) == 2
        assert ranged[0].date == "2026-08-18"
        assert ranged[1].date == "2026-08-19"

    def test_get_recent_activities_and_failures(self, store: HistoryStore) -> None:
        """get_recent_activities and get_recent_failures return sorted slices."""
        store.add_record(ActivityRecord(timestamp="2026-08-19T10:00:00Z", status="committed", title="First"))
        store.add_record(ActivityRecord(timestamp="2026-08-19T12:00:00Z", status="failed", error="Error", title="Second"))
        store.add_record(ActivityRecord(timestamp="2026-08-19T14:00:00Z", status="committed", title="Third"))

        recent = store.get_recent_activities(limit=2)
        assert len(recent) == 2
        assert recent[0].title == "Third"  # Newest first

        failures = store.get_recent_failures(limit=5)
        assert len(failures) == 1
        assert failures[0].title == "Second"

    def test_corrupted_json_recovery_creates_backup(self, store: HistoryStore) -> None:
        """Corrupted JSON should trigger backup creation and return empty list cleanly."""
        store.history_file.parent.mkdir(parents=True, exist_ok=True)
        store.history_file.write_text("INVALID { JSON DATA [[[", encoding="utf-8")

        records = store.get_records()
        assert records == []

        bak_file = store.history_file.with_suffix(".json.bak")
        assert bak_file.exists()
        assert "INVALID" in bak_file.read_text(encoding="utf-8")

    def test_missing_file_returns_empty(self, store: HistoryStore) -> None:
        """Non-existent history file should return empty list."""
        assert store.get_records() == []
