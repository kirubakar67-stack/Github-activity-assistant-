"""Unit tests for ReportGenerator (app/monitoring/reports.py)."""

from __future__ import annotations

import csv
import json
from pathlib import Path
import pytest

from app.monitoring.history_store import ActivityRecord, HistoryStore
from app.monitoring.reports import ReportGenerator


class TestReportGenerator:
    """Test suite for ReportGenerator JSON and CSV export capabilities."""

    @pytest.fixture
    def generator_with_data(self, tmp_path: Path) -> ReportGenerator:
        """Provide ReportGenerator with pre-populated history store."""
        store = HistoryStore(history_file=tmp_path / "activity_history.json")
        store.add_record(
            ActivityRecord(
                id="act-001",
                date="2026-08-18",
                timestamp="2026-08-18T15:00:00Z",
                repository="owner/repo1",
                activity_type="documentation",
                title="First activity",
                status="committed",
                commit_hash="h111",
                commit_message="docs: first commit",
                duration=1.2,
            )
        )
        store.add_record(
            ActivityRecord(
                id="act-002",
                date="2026-08-19",
                timestamp="2026-08-19T16:00:00Z",
                repository="owner/repo2",
                activity_type="changelog",
                title="Second activity",
                status="failed",
                error="Path error",
                duration=0.8,
            )
        )
        return ReportGenerator(
            history_store=store,
            default_output_dir=tmp_path / "reports",
        )

    def test_export_json_report(self, generator_with_data: ReportGenerator) -> None:
        """export_json should generate valid formatted JSON report."""
        report_file = generator_with_data.export_json(from_date="2026-08-18", to_date="2026-08-19")

        assert report_file.exists()
        assert report_file.suffix == ".json"

        with open(report_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        assert "report_metadata" in data
        assert "statistics_summary" in data
        assert "activity_records" in data
        assert len(data["activity_records"]) == 2
        assert data["statistics_summary"]["total_activities"] == 2

    def test_export_csv_report(self, generator_with_data: ReportGenerator) -> None:
        """export_csv should generate valid CSV file with standard columns."""
        report_file = generator_with_data.export_csv(from_date="2026-08-18", to_date="2026-08-19")

        assert report_file.exists()
        assert report_file.suffix == ".csv"

        with open(report_file, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        assert len(rows) == 2
        assert rows[0]["id"] == "act-001"
        assert rows[0]["status"] == "committed"
        assert rows[0]["commit_hash"] == "h111"
        assert rows[1]["id"] == "act-002"
        assert rows[1]["status"] == "failed"
        assert rows[1]["error"] == "Path error"

    def test_export_date_filtering(self, generator_with_data: ReportGenerator) -> None:
        """Report generator respects from_date and to_date filters."""
        report_file = generator_with_data.export_json(from_date="2026-08-19", to_date="2026-08-19")

        with open(report_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        assert len(data["activity_records"]) == 1
        assert data["activity_records"][0]["id"] == "act-002"
