"""Unit tests for Activity Planner (app/activity/planner.py)."""

from __future__ import annotations

from pathlib import Path
from unittest import mock
import pytest

from app.activity.history import ActivityHistoryManager
from app.activity.models import ActivityPlan, ActivityType
from app.activity.planner import ActivityPlanner
from app.activity.validator import ActivityValidator
from app.github_client import GitHubClient, RepositoryInfo
from app.repository_manager import RepositoryManager


class TestActivityPlanner:
    """Test suite for ActivityPlanner class."""

    @pytest.fixture
    def mock_repo_manager(self) -> mock.MagicMock:
        """Provide mocked RepositoryManager with 4 accessible repositories."""
        manager = mock.MagicMock(spec=RepositoryManager)
        manager.validate_repositories.return_value = [
            RepositoryInfo(
                name="repo1", full_name="owner/repo1", owner="owner",
                visibility="public", default_branch="main", accessible=True
            ),
            RepositoryInfo(
                name="repo2", full_name="owner/repo2", owner="owner",
                visibility="public", default_branch="main", accessible=True
            ),
            RepositoryInfo(
                name="repo3", full_name="owner/repo3", owner="owner",
                visibility="public", default_branch="main", accessible=True
            ),
            RepositoryInfo(
                name="repo4", full_name="owner/repo4", owner="owner",
                visibility="public", default_branch="main", accessible=True
            ),
        ]
        return manager

    @pytest.fixture
    def history_manager(self, tmp_path: Path) -> ActivityHistoryManager:
        """Provide history manager using temporary JSON file."""
        return ActivityHistoryManager(history_file=tmp_path / "test_history.json")

    def test_plan_daily_activities_target_5_across_4_repos(
        self, mock_repo_manager: mock.MagicMock, history_manager: ActivityHistoryManager
    ) -> None:
        """Target 5 across 4 repositories should distribute plans across all 4 repos."""
        planner = ActivityPlanner(
            repository_manager=mock_repo_manager,
            history_manager=history_manager,
            daily_target=5,
        )

        plans = planner.plan_daily_activities(target_count=5)

        assert len(plans) == 5
        assert all(p.valid for p in plans)

        # Repositories should include all 4
        repos_in_plans = [p.repository for p in plans]
        assert repos_in_plans.count("owner/repo1") == 2
        assert repos_in_plans.count("owner/repo2") == 1
        assert repos_in_plans.count("owner/repo3") == 1
        assert repos_in_plans.count("owner/repo4") == 1

    @pytest.mark.parametrize("target", [5, 6, 7])
    def test_plan_daily_activities_different_targets(
        self, mock_repo_manager: mock.MagicMock, history_manager: ActivityHistoryManager, target: int
    ) -> None:
        """Planner should generate exact target count for targets 5, 6, and 7."""
        planner = ActivityPlanner(
            repository_manager=mock_repo_manager,
            history_manager=history_manager,
            daily_target=target,
        )

        plans = planner.plan_daily_activities(target_count=target)
        assert len(plans) == target
        assert all(p.valid for p in plans)

    def test_plan_daily_activities_single_repository(
        self, history_manager: ActivityHistoryManager
    ) -> None:
        """Planner should successfully generate all targets for a single repository."""
        manager = mock.MagicMock(spec=RepositoryManager)
        manager.validate_repositories.return_value = [
            RepositoryInfo(
                name="single-repo", full_name="owner/single-repo", owner="owner",
                visibility="public", default_branch="main", accessible=True
            )
        ]

        planner = ActivityPlanner(
            repository_manager=manager,
            history_manager=history_manager,
            daily_target=5,
        )

        plans = planner.plan_daily_activities(target_count=5)
        assert len(plans) == 5
        assert all(p.repository == "owner/single-repo" for p in plans)
        # Content hashes should all be distinct
        hashes = {p.content_hash for p in plans}
        assert len(hashes) == 5

    def test_duplicate_prevention_skips_recorded_hash(
        self, mock_repo_manager: mock.MagicMock, history_manager: ActivityHistoryManager
    ) -> None:
        """Planner should avoid generating plans matching already recorded content hashes."""
        planner = ActivityPlanner(
            repository_manager=mock_repo_manager,
            history_manager=history_manager,
            daily_target=3,
        )

        # Generate first batch and record to history
        first_plans = planner.plan_daily_activities(target_count=3, record_in_history=True)
        assert len(first_plans) == 3

        # Second batch should produce new unique plans
        second_plans = planner.plan_daily_activities(target_count=3, record_in_history=True)
        assert len(second_plans) == 3

        first_hashes = {p.content_hash for p in first_plans}
        second_hashes = {p.content_hash for p in second_plans}
        # Overlap between batches must be zero
        assert first_hashes.isdisjoint(second_hashes)

    def test_inaccessible_repositories_filtered(
        self, history_manager: ActivityHistoryManager
    ) -> None:
        """Inaccessible repositories should be bypassed and only accessible ones planned."""
        manager = mock.MagicMock(spec=RepositoryManager)
        manager.validate_repositories.return_value = [
            RepositoryInfo(
                name="broken", full_name="owner/broken", owner="owner",
                visibility="unknown", default_branch="unknown", accessible=False
            ),
            RepositoryInfo(
                name="good", full_name="owner/good", owner="owner",
                visibility="public", default_branch="main", accessible=True
            ),
        ]

        planner = ActivityPlanner(
            repository_manager=manager,
            history_manager=history_manager,
            daily_target=3,
        )

        plans = planner.plan_daily_activities(target_count=3)
        assert len(plans) == 3
        assert all(p.repository == "owner/good" for p in plans)

    def test_zero_accessible_repositories_returns_empty(
        self, history_manager: ActivityHistoryManager
    ) -> None:
        """If no repositories are accessible, planner returns empty list."""
        manager = mock.MagicMock(spec=RepositoryManager)
        manager.validate_repositories.return_value = [
            RepositoryInfo(
                name="broken", full_name="owner/broken", owner="owner",
                visibility="unknown", default_branch="unknown", accessible=False
            ),
        ]

        planner = ActivityPlanner(
            repository_manager=manager,
            history_manager=history_manager,
            daily_target=5,
        )

        plans = planner.plan_daily_activities(target_count=5)
        assert plans == []
