"""Unit tests for Desktop GUI components (app/gui) in headless/offscreen mode."""

from __future__ import annotations

import os
from pathlib import Path
from unittest import mock
import pytest

# Ensure Qt runs in headless/offscreen mode during automated test execution
os.environ["QT_QPA_PLATFORM"] = "offscreen"

from PySide6.QtWidgets import QApplication

from app.activity.models import ActivityPlan, ActivityType
from app.config import AppConfig
from app.gui.dialogs import ActivityPreviewDialog, ConfirmationDialog
from app.gui.main_window import MainWindow
from app.gui.styles import get_theme_qss
from app.gui.widgets import (
    ActivityWidget,
    DashboardWidget,
    HistoryWidget,
    LogsWidget,
    ReportsWidget,
    RepositoriesWidget,
    SchedulerWidget,
    SettingsWidget,
)
from app.gui.workers import ActivityExecutionWorker, ActivityPlanWorker, GitHubValidationWorker
from app.monitoring.history_store import HistoryStore
from app.monitoring.statistics import StatisticsEngine
from app.scheduler.state import SchedulerStateManager


@pytest.fixture(scope="session")
def qapp() -> QApplication:
    """Provide or create singleton QApplication for GUI tests."""
    app = QApplication.instance()
    if not app:
        app = QApplication([])
    return app


@pytest.fixture
def mock_config(tmp_path: Path) -> AppConfig:
    """Provide valid AppConfig with temporary directories."""
    return AppConfig(
        github_token="ghp_test_token_1234567890abcdef",
        github_repository="testuser/repo1",
        github_repositories=("testuser/repo1", "testuser/repo2"),
        daily_activity_target=5,
        local_repository_path=tmp_path / "repositories",
        schedule_time="18:00",
        timezone="Asia/Kolkata",
        report_directory=tmp_path / "reports",
    )


class TestGUIComponents:
    """Test suite for PySide6 GUI windows, dialogs, widgets, and styles."""

    def test_theme_qss_retrieval(self) -> None:
        """Theme generator should produce non-empty CSS styles for dark and light themes."""
        dark_qss = get_theme_qss("dark")
        light_qss = get_theme_qss("light")

        assert len(dark_qss) > 100
        assert len(light_qss) > 100
        assert "QMainWindow" in dark_qss
        assert "QMainWindow" in light_qss

    def test_confirmation_dialog_creation(self, qapp: QApplication) -> None:
        """ConfirmationDialog should instantiate and set title/message."""
        dlg = ConfirmationDialog(
            title="Confirm Action",
            message="Are you sure you want to proceed?",
            detail_text="Detailed explanation of action.",
            is_danger=True,
        )
        assert dlg.windowTitle() == "Confirm Action"

    def test_activity_preview_dialog_creation(self, qapp: QApplication) -> None:
        """ActivityPreviewDialog displays plan metadata and diff."""
        plan = ActivityPlan(
            repository="owner/repo",
            activity_type=ActivityType.DOCUMENTATION,
            target_file="docs/notes.md",
            title="Note update",
            description="Doc update",
            proposed_content="## Content\n- Note.",
            reason="Routine maintenance",
        )
        dlg = ActivityPreviewDialog(plan=plan)
        assert "Note update" in dlg.windowTitle()

    def test_dashboard_widget_instantiation(self, qapp: QApplication, tmp_path: Path) -> None:
        """DashboardWidget initializes and renders stat cards and calendar."""
        store = HistoryStore(history_file=tmp_path / "activity_history.json")
        stats = StatisticsEngine(history_store=store)
        state_mgr = SchedulerStateManager(state_file=tmp_path / "scheduler_state.json")

        widget = DashboardWidget(
            history_store=store,
            stats_engine=stats,
            state_manager=state_mgr,
            timezone_name="Asia/Kolkata",
            daily_target=5,
        )
        assert widget.card_target.val_label.text() == "5"

    def test_repositories_widget_instantiation(self, qapp: QApplication, tmp_path: Path) -> None:
        """RepositoriesWidget creates repository cards."""
        widget = RepositoriesWidget(
            repositories=("owner/repo1", "owner/repo2"),
            local_base_path=tmp_path / "repositories",
        )
        assert widget.cards_layout.count() >= 2

    def test_history_widget_instantiation(self, qapp: QApplication, tmp_path: Path) -> None:
        """HistoryWidget creates interactive audit table with search and filters."""
        store = HistoryStore(history_file=tmp_path / "activity_history.json")
        widget = HistoryWidget(
            history_store=store,
            repositories=("owner/repo1", "owner/repo2"),
        )
        assert widget.table.columnCount() == 6

    def test_logs_widget_instantiation(self, qapp: QApplication, tmp_path: Path) -> None:
        """LogsWidget initializes log viewer with level filters."""
        log_file = tmp_path / "test.log"
        log_file.write_text("2026-08-19 12:00:00 [INFO] System ready.\n", encoding="utf-8")

        widget = LogsWidget(log_file=log_file)
        assert "System ready." in widget.log_view.toPlainText()

    def test_reports_widget_instantiation(self, qapp: QApplication, tmp_path: Path) -> None:
        """ReportsWidget creates date pickers and export buttons."""
        widget = ReportsWidget(output_dir=tmp_path / "reports")
        assert widget.json_btn.isEnabled()
        assert widget.csv_btn.isEnabled()

    def test_settings_widget_instantiation(self, qapp: QApplication, mock_config: AppConfig) -> None:
        """SettingsWidget populates form fields with AppConfig values."""
        widget = SettingsWidget(config=mock_config)
        assert widget.target_spin.value() == 5
        assert widget.schedule_time_input.text() == "18:00"

    @mock.patch("app.gui.main_window.GitHubClient")
    def test_main_window_lifecycle(
        self, mock_client_cls: mock.MagicMock, qapp: QApplication, mock_config: AppConfig
    ) -> None:
        """MainWindow should assemble all 8 widgets into stacked layout."""
        window = MainWindow(config=mock_config)

        assert window.stack.count() == 8
        assert len(window.nav_buttons) == 8

        # Test page switching
        window._switch_page(1)
        assert window.stack.currentIndex() == 1
        assert window.header_title.text() == "Repositories"

        window._switch_page(4)
        assert window.stack.currentIndex() == 4
        assert window.header_title.text() == "Activity History"
