"""Unit tests for Commit Manager (app/git/commit_manager.py) using isolated test Git repositories."""

from __future__ import annotations

import subprocess
from pathlib import Path
import pytest

from app.activity.history import ActivityHistoryManager
from app.activity.models import ActivityPlan, ActivityType
from app.activity.validator import ActivityValidator
from app.git.commit_manager import CommitManager, CommitResult
from app.git.git_manager import GitManager


@pytest.fixture
def temp_git_repo(tmp_path: Path) -> Path:
    """Create and initialize a temporary Git repository on disk."""
    repo_dir = tmp_path / "test_repo"
    repo_dir.mkdir(parents=True, exist_ok=True)

    subprocess.run(["git", "init", "-b", "main", str(repo_dir)], check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test Committer"], cwd=str(repo_dir), check=True)
    subprocess.run(["git", "config", "user.email", "committer@example.com"], cwd=str(repo_dir), check=True)

    readme = repo_dir / "README.md"
    readme.write_text("# Project Test\nInitial project documentation.\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=str(repo_dir), check=True)
    subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=str(repo_dir), check=True)

    return repo_dir


@pytest.fixture
def commit_manager(tmp_path: Path) -> CommitManager:
    """Provide CommitManager instance configured with test paths."""
    git_mgr = GitManager()
    history_mgr = ActivityHistoryManager(history_file=tmp_path / "test_history.json")
    validator = ActivityValidator()
    return CommitManager(
        git_manager=git_mgr,
        history_manager=history_mgr,
        validator=validator,
        local_base_path=tmp_path,
    )


class TestCommitManager:
    """Test suite for CommitManager class."""

    def test_execute_activity_success(
        self, commit_manager: CommitManager, temp_git_repo: Path
    ) -> None:
        """Valid ActivityPlan should apply change, stage file, commit, and record history."""
        plan = ActivityPlan(
            repository="owner/test_repo",
            activity_type=ActivityType.PROGRESS_LOG,
            target_file="docs/progress.md",
            title="Record development progress",
            description="Add daily progress log entry.",
            proposed_content="## Development Progress — 2026-08-19\n- Inspected module consistency.",
            reason="Maintain daily progress log.",
        )

        result = commit_manager.execute_activity(
            plan=plan,
            dry_run=False,
            repo_path_override=temp_git_repo,
        )

        assert result.success is True
        assert result.commit_hash is not None
        assert len(result.commit_hash) >= 6
        assert "docs: update development progress log" in (result.commit_message or "")
        assert result.diff is not None
        assert "docs/progress.md" in result.diff

        # Verify file exists on disk
        target_file = temp_git_repo / "docs" / "progress.md"
        assert target_file.exists()
        assert "Inspected module consistency" in target_file.read_text(encoding="utf-8")

        # Verify recorded in history
        history = commit_manager._history.get_history("owner/test_repo")
        assert len(history) == 1
        assert history[0]["content_hash"] == plan.content_hash

    def test_execute_activity_dry_run_leaves_clean_working_tree(
        self, commit_manager: CommitManager, temp_git_repo: Path
    ) -> None:
        """Dry-run mode should preview diff and message without leaving file modifications or commits."""
        plan = ActivityPlan(
            repository="owner/test_repo",
            activity_type=ActivityType.DOCUMENTATION,
            target_file="docs/notes.md",
            title="Update developer notes",
            description="Add developer architecture notes.",
            proposed_content="## Architecture Notes — 2026-08-19\n- Reviewed core layout.",
            reason="Maintain developer notes.",
        )

        result = commit_manager.execute_activity(
            plan=plan,
            dry_run=True,
            repo_path_override=temp_git_repo,
        )

        assert result.success is True
        assert result.commit_hash is None
        assert "docs: update developer reference notes" in (result.commit_message or "")
        assert result.diff is not None
        assert "docs/notes.md" in result.diff

        # Working tree must be clean
        assert commit_manager._git.is_clean(temp_git_repo) is True
        # Target file must not exist on disk
        assert not (temp_git_repo / "docs" / "notes.md").exists()

    def test_execute_activity_dirty_working_tree_aborts_safely(
        self, commit_manager: CommitManager, temp_git_repo: Path
    ) -> None:
        """If repository has uncommitted changes, execution must abort without wiping work."""
        # Create uncommitted dirty change
        dirty_file = temp_git_repo / "user_work.txt"
        dirty_file.write_text("User work in progress...", encoding="utf-8")

        plan = ActivityPlan(
            repository="owner/test_repo",
            activity_type=ActivityType.CHANGELOG,
            target_file="CHANGELOG.md",
            title="Update changelog",
            description="Add changelog entry.",
            proposed_content="### Maintenance — 2026-08-19\n- Verified build.",
            reason="Keep changelog updated.",
        )

        result = commit_manager.execute_activity(
            plan=plan,
            dry_run=False,
            repo_path_override=temp_git_repo,
        )

        assert result.success is False
        assert "uncommitted changes" in (result.error_message or "").lower()

        # User's uncommitted file must be completely untouched
        assert dirty_file.exists()
        assert dirty_file.read_text(encoding="utf-8") == "User work in progress..."

    def test_execute_activity_invalid_plan_rejected(
        self, commit_manager: CommitManager, temp_git_repo: Path
    ) -> None:
        """ActivityPlan marked valid=False should be rejected immediately."""
        plan = ActivityPlan(
            repository="owner/test_repo",
            activity_type=ActivityType.PROGRESS_LOG,
            target_file="docs/progress.md",
            title="Bad plan",
            description="Invalid plan description.",
            proposed_content="Some content here.",
            reason="Testing.",
            valid=False,
            validation_error="Manually invalidated",
        )

        result = commit_manager.execute_activity(
            plan=plan,
            dry_run=False,
            repo_path_override=temp_git_repo,
        )

        assert result.success is False
        assert "is invalid" in (result.error_message or "")

    def test_execute_activity_secret_detection_blocks_commit(
        self, commit_manager: CommitManager, temp_git_repo: Path
    ) -> None:
        """Proposed content containing credentials must block commit."""
        plan = ActivityPlan(
            repository="owner/test_repo",
            activity_type=ActivityType.CONFIGURATION_DOCS,
            target_file="docs/config.md",
            title="Leaked token doc",
            description="Configuration notes with secret.",
            proposed_content="GITHUB_TOKEN=ghp_123456789012345678901234567890abcdef\n- Added token note.",
            reason="Testing secret block.",
        )

        result = commit_manager.execute_activity(
            plan=plan,
            dry_run=False,
            repo_path_override=temp_git_repo,
        )

        assert result.success is False
        assert "COMMIT BLOCKED" in (result.error_message or "")
        assert commit_manager._git.is_clean(temp_git_repo) is True

    def test_generate_commit_messages(self, commit_manager: CommitManager) -> None:
        """generate_commit_message should create conventional, descriptive commit messages."""
        for act_type in ActivityType:
            plan = ActivityPlan(
                repository="owner/my_project",
                activity_type=act_type,
                target_file="docs/file.md",
                title="Test",
                description="Test description.",
                proposed_content="Valid proposed content string.",
                reason="Reason.",
            )
            msg = commit_manager.generate_commit_message(plan)
            assert msg.startswith("docs:")
            assert "my_project" in msg
            assert "contribution graph" not in msg.lower()
            assert "daily commit" not in msg.lower()

    def test_execute_plans_batch(
        self, commit_manager: CommitManager, temp_git_repo: Path
    ) -> None:
        """execute_plans should sequentially execute multiple plans."""
        plans = [
            ActivityPlan(
                repository="owner/test_repo",
                activity_type=ActivityType.PROGRESS_LOG,
                target_file="docs/progress.md",
                title="Progress 1",
                description="First progress log entry.",
                proposed_content="## Entry 1\n- Step 1 done.",
                reason="Audit.",
            ),
            ActivityPlan(
                repository="owner/test_repo",
                activity_type=ActivityType.CHANGELOG,
                target_file="CHANGELOG.md",
                title="Changelog 1",
                description="First changelog entry.",
                proposed_content="### Update 1\n- Log 1 recorded.",
                reason="Audit.",
            ),
        ]

        # Patch ensure_repository to use temp_git_repo
        commit_manager.ensure_repository = lambda repo, clone_url=None: temp_git_repo

        results = commit_manager.execute_plans(plans=plans, dry_run=False)

        assert len(results) == 2
        assert all(r.success for r in results)
        assert results[0].commit_hash != results[1].commit_hash
