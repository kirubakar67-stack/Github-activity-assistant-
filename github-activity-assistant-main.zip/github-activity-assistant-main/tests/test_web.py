"""Unit tests for Mobile Web App & REST API Server (app/web)."""

from __future__ import annotations

import io
import json
from pathlib import Path
from unittest import mock
import pytest

from app.activity.models import ActivityPlan, ActivityType
from app.config import AppConfig
from app.git.commit_manager import CommitManager
from app.monitoring.history_store import HistoryStore
from app.scheduler.daily_runner import DailyRunner
from app.scheduler.scheduler import ActivityScheduler
from app.scheduler.state import DailyState, SchedulerStatus, SchedulerStateManager
from app.web.server import AssistantRequestHandler, get_local_ip


class MockRequest:
    """Mock socket request object for BaseHTTPRequestHandler testing."""

    def __init__(self, raw_input: bytes = b"") -> None:
        self._raw_input = raw_input

    def makefile(self, *args, **kwargs):
        if "b" in args[0] or kwargs.get("mode") == "rb":
            return io.BytesIO(self._raw_input)
        return io.BytesIO(self._raw_input)

    def sendall(self, data):
        pass


@pytest.fixture
def mock_web_context(tmp_path: Path):
    """Setup mock dependencies on AssistantRequestHandler."""
    config = AppConfig(
        github_token="ghp_test123",
        github_repository="owner/repo1",
        github_repositories=("owner/repo1", "owner/repo2"),
        daily_activity_target=4,
        local_repository_path=tmp_path / "repos",
        schedule_time="18:00",
        timezone="Asia/Kolkata",
    )

    state_mgr = SchedulerStateManager(state_file=tmp_path / "state.json")
    history_store = HistoryStore(history_file=tmp_path / "history.json")

    mock_runner = mock.MagicMock(spec=DailyRunner)
    mock_runner.get_today_date_str.return_value = "2026-08-19"
    mock_runner.run.return_value = DailyState(
        date="2026-08-19",
        target=4,
        completed=4,
        failed=0,
        status=SchedulerStatus.COMPLETED,
    )

    mock_scheduler = mock.MagicMock(spec=ActivityScheduler)
    mock_scheduler.is_running = False

    mock_commit_mgr = mock.MagicMock(spec=CommitManager)
    mock_commit_mgr.author_name = "Kavin Palanisamy"

    AssistantRequestHandler.config = config
    AssistantRequestHandler.runner = mock_runner
    AssistantRequestHandler.scheduler = mock_scheduler
    AssistantRequestHandler.state_mgr = state_mgr
    AssistantRequestHandler.history_store = history_store
    AssistantRequestHandler.commit_mgr = mock_commit_mgr

    return {
        "config": config,
        "runner": mock_runner,
        "scheduler": mock_scheduler,
        "state_mgr": state_mgr,
        "history_store": history_store,
    }


class TestMobileWebServer:
    """Test suite for HTTP handlers and REST API."""

    def test_get_local_ip(self) -> None:
        """IP detector should return a non-empty IP string."""
        ip = get_local_ip()
        assert isinstance(ip, str)
        assert len(ip.split(".")) == 4

    def test_api_status_endpoint(self, mock_web_context) -> None:
        """GET /api/status should return JSON status information."""
        handler = AssistantRequestHandler.__new__(AssistantRequestHandler)
        handler.path = "/api/status"
        handler.headers = {}
        handler.wfile = io.BytesIO()

        with mock.patch.object(handler, "send_response"), \
             mock.patch.object(handler, "send_header"), \
             mock.patch.object(handler, "end_headers"):
            handler.do_GET()

        response_bytes = handler.wfile.getvalue()
        data = json.loads(response_bytes.decode("utf-8"))

        assert data["success"] is True
        assert data["target"] == 4
        assert data["user"] == "Kavin Palanisamy"
        assert len(data["repositories"]) == 2

    def test_api_execute_endpoint(self, mock_web_context) -> None:
        """POST /api/execute should trigger DailyRunner and return completed counts."""
        handler = AssistantRequestHandler.__new__(AssistantRequestHandler)
        handler.path = "/api/execute"
        payload = json.dumps({"dry_run": False, "push": False}).encode("utf-8")
        handler.headers = {"Content-Length": str(len(payload))}
        handler.rfile = io.BytesIO(payload)
        handler.wfile = io.BytesIO()

        with mock.patch.object(handler, "send_response"), \
             mock.patch.object(handler, "send_header"), \
             mock.patch.object(handler, "end_headers"):
            handler.do_POST()

        response_bytes = handler.wfile.getvalue()
        data = json.loads(response_bytes.decode("utf-8"))

        assert data["success"] is True
        assert data["completed"] == 4
        assert data["dry_run"] is False

    def test_api_scheduler_toggle_endpoint(self, mock_web_context) -> None:
        """POST /api/scheduler/toggle should toggle scheduler state."""
        handler = AssistantRequestHandler.__new__(AssistantRequestHandler)
        handler.path = "/api/scheduler/toggle"
        handler.headers = {"Content-Length": "0"}
        handler.rfile = io.BytesIO(b"")
        handler.wfile = io.BytesIO()

        with mock.patch.object(handler, "send_response"), \
             mock.patch.object(handler, "send_header"), \
             mock.patch.object(handler, "end_headers"):
            handler.do_POST()

        response_bytes = handler.wfile.getvalue()
        data = json.loads(response_bytes.decode("utf-8"))

        assert data["success"] is True
        assert "status" in data

    def test_get_static_index_html(self, mock_web_context) -> None:
        """GET / should serve HTML content."""
        handler = AssistantRequestHandler.__new__(AssistantRequestHandler)
        handler.path = "/"
        handler.headers = {}
        handler.wfile = io.BytesIO()

        with mock.patch.object(handler, "send_response"), \
             mock.patch.object(handler, "send_header"), \
             mock.patch.object(handler, "end_headers"):
            handler.do_GET()

        response_bytes = handler.wfile.getvalue()
        assert b"<!DOCTYPE html>" in response_bytes
        assert b"GitHub Assistant" in response_bytes
