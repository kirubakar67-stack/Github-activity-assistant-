"""Unit tests for GitHub Client (app/github_client.py) and CLI flow (app/main.py).

All tests utilize mocks to prevent real network calls or token exposure.
"""

from __future__ import annotations

from unittest import mock

import pytest
from github import (
    BadCredentialsException,
    GithubException,
    RateLimitExceededException,
    UnknownObjectException,
)

from app.config import AppConfig, ConfigError
from app.github_client import (
    GitHubAuthError,
    GitHubClient,
    GitHubClientError,
    GitHubRateLimitError,
    GitHubRepositoryError,
    RepositoryInfo,
    UserInfo,
)
from app.main import run_phase1


class TestGitHubClient:
    """Test suite for GitHubClient methods and exception mapping."""

    def test_init_empty_token_raises_error(self) -> None:
        """Client initialization should fail if an empty token is supplied."""
        with pytest.raises(GitHubAuthError, match="Cannot initialize GitHubClient with an empty token"):
            GitHubClient(token="")

    def test_init_whitespace_token_raises_error(self) -> None:
        """Client initialization should fail if whitespace-only token is supplied."""
        with pytest.raises(GitHubAuthError, match="Cannot initialize GitHubClient with an empty token"):
            GitHubClient(token="   ")

    def test_init_valid_client(self) -> None:
        """Client should properly store default repository and initialize PyGithub."""
        client = GitHubClient(token="valid_test_token", default_repository="owner/repo")
        assert client.default_repository == "owner/repo"

    @mock.patch("app.github_client.Github")
    def test_authenticate_success(self, mock_github_cls: mock.MagicMock) -> None:
        """Successful authentication should return populated UserInfo."""
        mock_user = mock.MagicMock()
        mock_user.login = "octocat"
        mock_user.name = "The Octocat"
        mock_user.email = "octocat@github.com"
        mock_user.html_url = "https://github.com/octocat"
        mock_user.type = "User"

        mock_instance = mock_github_cls.return_value
        mock_instance.get_user.return_value = mock_user

        client = GitHubClient(token="test_token")
        user_info = client.authenticate()

        assert isinstance(user_info, UserInfo)
        assert user_info.login == "octocat"
        assert user_info.name == "The Octocat"
        assert user_info.email == "octocat@github.com"
        assert user_info.user_type == "User"

    @mock.patch("app.github_client.Github")
    def test_authenticate_bad_credentials_raises_auth_error(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """BadCredentialsException must be mapped to GitHubAuthError."""
        mock_instance = mock_github_cls.return_value
        mock_instance.get_user.side_effect = BadCredentialsException(
            status=401, data={"message": "Bad credentials"}, headers={}
        )

        client = GitHubClient(token="invalid_token")
        with pytest.raises(GitHubAuthError, match="Invalid, expired, or revoked"):
            client.authenticate()

    @mock.patch("app.github_client.Github")
    def test_authenticate_rate_limit_exceeded(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """RateLimitExceededException must be mapped to GitHubRateLimitError."""
        mock_instance = mock_github_cls.return_value
        mock_instance.get_user.side_effect = RateLimitExceededException(
            status=403, data={"message": "API rate limit exceeded"}, headers={}
        )

        client = GitHubClient(token="valid_token")
        with pytest.raises(GitHubRateLimitError, match="rate limit exceeded"):
            client.authenticate()

    @mock.patch("app.github_client.Github")
    def test_authenticate_github_exception_401(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """GithubException with status 401 must raise GitHubAuthError."""
        mock_instance = mock_github_cls.return_value
        mock_instance.get_user.side_effect = GithubException(
            status=401, data={"message": "Unauthorized"}, headers={}
        )

        client = GitHubClient(token="bad_token")
        with pytest.raises(GitHubAuthError, match="Bad credentials"):
            client.authenticate()

    @mock.patch("app.github_client.Github")
    def test_get_repository_success_with_default(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """get_repository should use default_repository when no argument provided."""
        mock_repo = mock.MagicMock()
        mock_repo.id = 12345
        mock_repo.full_name = "test-owner/test-repo"

        mock_instance = mock_github_cls.return_value
        mock_instance.get_repo.return_value = mock_repo

        client = GitHubClient(token="test_token", default_repository="test-owner/test-repo")
        repo = client.get_repository()

        mock_instance.get_repo.assert_called_once_with("test-owner/test-repo")
        assert repo.full_name == "test-owner/test-repo"

    def test_get_repository_no_repo_provided_raises_error(self) -> None:
        """get_repository without argument or default should raise GitHubRepositoryError."""
        client = GitHubClient(token="test_token")
        with pytest.raises(GitHubRepositoryError, match="No repository specified"):
            client.get_repository()

    @mock.patch("app.github_client.Github")
    def test_get_repository_not_found_raises_repository_error(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """UnknownObjectException must raise GitHubRepositoryError with helpful message."""
        mock_instance = mock_github_cls.return_value
        mock_instance.get_repo.side_effect = UnknownObjectException(
            status=404, data={"message": "Not Found"}, headers={}
        )

        client = GitHubClient(token="test_token")
        with pytest.raises(GitHubRepositoryError, match="was not found"):
            client.get_repository("owner/nonexistent-repo")

    @mock.patch("app.github_client.Github")
    def test_get_repository_forbidden_403_raises_repository_error(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """HTTP 403 on repository retrieval should raise GitHubRepositoryError."""
        mock_instance = mock_github_cls.return_value
        mock_instance.get_repo.side_effect = GithubException(
            status=403, data={"message": "Must have admin rights to Repository"}, headers={}
        )

        client = GitHubClient(token="test_token")
        with pytest.raises(GitHubRepositoryError, match="Access forbidden"):
            client.get_repository("owner/forbidden-repo")

    @mock.patch("app.github_client.Github")
    def test_check_repository_access_success(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """check_repository_access should return populated RepositoryInfo."""
        mock_repo = mock.MagicMock()
        mock_repo.id = 999
        mock_repo.name = "Hello-World"
        mock_repo.full_name = "octocat/Hello-World"
        mock_repo.owner.login = "octocat"
        mock_repo.private = False
        mock_repo.default_branch = "main"
        mock_repo.description = "My first repository"
        mock_repo.html_url = "https://github.com/octocat/Hello-World"
        mock_repo.permissions.push = True

        mock_instance = mock_github_cls.return_value
        mock_instance.get_repo.return_value = mock_repo

        client = GitHubClient(token="test_token", default_repository="octocat/Hello-World")
        info = client.check_repository_access()

        assert isinstance(info, RepositoryInfo)
        assert info.name == "Hello-World"
        assert info.full_name == "octocat/Hello-World"
        assert info.owner == "octocat"
        assert info.visibility == "public"
        assert info.default_branch == "main"
        assert info.description == "My first repository"
        assert info.can_push is True

    @mock.patch("app.github_client.Github")
    def test_client_context_manager_closes_session(
        self, mock_github_cls: mock.MagicMock
    ) -> None:
        """Using client as context manager should close session upon exit."""
        mock_instance = mock_github_cls.return_value

        with GitHubClient(token="test_token") as client:
            assert client is not None

        mock_instance.close.assert_called_once()


class TestCLIFlow:
    """Test suite for app/main.py CLI orchestration."""

    @mock.patch("app.main.CommitManager")
    @mock.patch("app.main.load_config")
    @mock.patch("app.main.GitHubClient")
    def test_run_phase1_success(
        self,
        mock_client_cls: mock.MagicMock,
        mock_load_config: mock.MagicMock,
        mock_commit_mgr_cls: mock.MagicMock,
    ) -> None:
        """Full successful execution returns exit code 0."""
        mock_load_config.return_value = AppConfig(
            github_token="ghp_mock_token_12345",
            github_repository="owner/repo",
        )

        mock_client = mock_client_cls.return_value
        mock_client.authenticate.return_value = UserInfo(
            login="testuser",
            name="Test User",
            email="test@example.com",
            html_url="https://github.com/testuser",
            user_type="User",
        )
        mock_client.check_repository_access.return_value = RepositoryInfo(
            name="repo",
            full_name="owner/repo",
            owner="owner",
            visibility="public",
            default_branch="main",
            description="Test repo",
            html_url="https://github.com/owner/repo",
            is_private=False,
            can_push=True,
        )

        mock_commit_mgr = mock_commit_mgr_cls.return_value
        from app.git.commit_manager import CommitResult
        mock_commit_mgr.execute_activity.return_value = CommitResult(
            success=True,
            repository="owner/repo",
            activity_plan=mock.MagicMock(),
            commit_hash=None,
            commit_message="docs: update notes",
            diff="+ Note",
        )

        exit_code = run_phase1()
        assert exit_code == 0
        mock_client.close.assert_called_once()


    @mock.patch("app.main.load_config")
    def test_run_phase1_config_error(self, mock_load_config: mock.MagicMock) -> None:
        """Configuration failure returns exit code 1."""
        mock_load_config.side_effect = ConfigError("Missing token")

        exit_code = run_phase1()
        assert exit_code == 1

    @mock.patch("app.main.load_config")
    @mock.patch("app.main.GitHubClient")
    def test_run_phase1_auth_error(
        self, mock_client_cls: mock.MagicMock, mock_load_config: mock.MagicMock
    ) -> None:
        """Authentication failure returns exit code 1."""
        mock_load_config.return_value = AppConfig(
            github_token="bad_token",
            github_repository="owner/repo",
        )
        mock_client = mock_client_cls.return_value
        mock_client.authenticate.side_effect = GitHubAuthError("Bad credentials")

        exit_code = run_phase1()
        assert exit_code == 1

    @mock.patch("app.main.load_config")
    @mock.patch("app.main.GitHubClient")
    def test_run_phase1_repository_error(
        self, mock_client_cls: mock.MagicMock, mock_load_config: mock.MagicMock
    ) -> None:
        """Repository access failure returns exit code 1."""
        mock_load_config.return_value = AppConfig(
            github_token="valid_token",
            github_repository="owner/repo",
        )
        mock_client = mock_client_cls.return_value
        mock_client.authenticate.return_value = UserInfo(
            login="testuser",
            name=None,
            email=None,
            html_url="https://github.com/testuser",
            user_type="User",
        )
        mock_client.check_repository_access.side_effect = GitHubRepositoryError(
            "Repository not found"
        )

        exit_code = run_phase1()
        assert exit_code == 1
