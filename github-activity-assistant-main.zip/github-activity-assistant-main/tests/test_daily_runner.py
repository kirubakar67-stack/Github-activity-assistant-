"""Unit tests for DailyRunner engine (app/scheduler/daily_runner.py)."""

from __future__ import annotations

from pathlib import Path
from unittest import mock
import pytest

from app.activity.models import ActivityPlan, ActivityType
from app.activity.planner import ActivityPlanner
from app.git.commit_manager import CommitManager, CommitResult
from app.scheduler.daily_runner import DailyRunner
from app.scheduler.state import SchedulerStatus, SchedulerStateManager


class TestDailyRunner:
    """Test suite for DailyRunner class."""

    @pytest.fixture
    def mock_planner(self) -> mock.MagicMock:
        """Provide mocked ActivityPlanner generating mock ActivityPlans."""
        planner = mock.MagicMock(spec=ActivityPlanner)

        def side_effect(target_count=5, record_in_history=False):
            return [
                ActivityPlan(
                    repository=f"owner/repo{i}",
                    activity_type=ActivityType.DOCUMENTATION,
                    target_file="docs/notes.md",
                    title=f"Note {i}",
                    description=f"Description {i}",
                    proposed_content=f"## Content {i}\n- Note entry.",
                    reason="Maintenance",
                )
                for i in range(target_count)
            ]

        planner.plan_daily_activities.side_effect = side_effect
        return planner

    @pytest.fixture
    def mock_commit_mgr(self) -> mock.MagicMock:
        """Provide mocked CommitManager returning successful results."""
        mgr = mock.MagicMock(spec=CommitManager)
        mgr.execute_activity.return_value = CommitResult(
            success=True,
            repository="owner/repo",
            activity_plan=mock.MagicMock(),
            commit_hash="a1b2c3d",
            commit_message="docs: update developer notes",
            diff="+ Note entry.",
        )
        return mgr

    @pytest.fixture
    def state_manager(self, tmp_path: Path) -> SchedulerStateManager:
        """Provide state manager with temporary file."""
        return SchedulerStateManager(state_file=tmp_path / "scheduler_state.json")

    def test_daily_runner_success(
        self,
        mock_planner: mock.MagicMock,
        mock_commit_mgr: mock.MagicMock,
        state_manager: SchedulerStateManager,
    ) -> None:
        """DailyRunner should plan, execute, and reach daily target count."""
        runner = DailyRunner(
            planner=mock_planner,
            commit_manager=mock_commit_mgr,
            state_manager=state_manager,
            target_count=3,
            min_interval_minutes=0,
            sleep_func=lambda s: None,
        )

        state = runner.run(dry_run=False)

        assert state.status == SchedulerStatus.COMPLETED
        assert state.completed == 3
        assert state.failed == 0
        assert mock_commit_mgr.execute_activity.call_count == 3

    def test_duplicate_day_protection(
        self,
        mock_planner: mock.MagicMock,
        mock_commit_mgr: mock.MagicMock,
        state_manager: SchedulerStateManager,
    ) -> None:
        """Calling run a second time on the same date should do nothing unless force=True."""
        runner = DailyRunner(
            planner=mock_planner,
            commit_manager=mock_commit_mgr,
            state_manager=state_manager,
            target_count=2,
            min_interval_minutes=0,
            sleep_func=lambda s: None,
        )

        # First run completes
        runner.run(dry_run=False)
        assert mock_commit_mgr.execute_activity.call_count == 2

        # Second run should skip execution
        state2 = runner.run(dry_run=False, force=False)
        assert state2.completed == 2
        assert mock_commit_mgr.execute_activity.call_count == 2  # No new calls

        # Forced run should execute again
        runner.run(dry_run=False, force=True)
        assert mock_commit_mgr.execute_activity.call_count == 4

    def test_partial_failure_handling(
        self,
        mock_planner: mock.MagicMock,
        state_manager: SchedulerStateManager,
    ) -> None:
        """When an individual activity fails, runner records failure and continues."""
        mock_mgr = mock.MagicMock(spec=CommitManager)
        # First succeeds, second fails, third succeeds
        mock_mgr.execute_activity.side_effect = [
            CommitResult(success=True, repository="owner/r1", activity_plan=mock.MagicMock(), commit_hash="111"),
            CommitResult(success=False, repository="owner/r2", activity_plan=mock.MagicMock(), error_message="Dirty tree"),
            CommitResult(success=True, repository="owner/r3", activity_plan=mock.MagicMock(), commit_hash="222"),
        ]

        runner = DailyRunner(
            planner=mock_planner,
            commit_manager=mock_mgr,
            state_manager=state_manager,
            target_count=3,
            min_interval_minutes=0,
            sleep_func=lambda s: None,
        )

        state = runner.run(dry_run=False)
        assert state.completed == 2
        assert state.failed == 1
        assert state.status == SchedulerStatus.COMPLETED

    def test_resume_run_executes_only_remaining(
        self,
        mock_planner: mock.MagicMock,
        mock_commit_mgr: mock.MagicMock,
        state_manager: SchedulerStateManager,
    ) -> None:
        """Resuming an incomplete run should only plan and execute remaining items."""
        runner = DailyRunner(
            planner=mock_planner,
            commit_manager=mock_commit_mgr,
            state_manager=state_manager,
            target_count=5,
            min_interval_minutes=0,
            sleep_func=lambda s: None,
        )

        today_str = runner.get_today_date_str()
        # Seed an incomplete state (2/5 completed)
        seed_state = state_manager.get_or_create_state(today_str, target=5)
        seed_state.completed = 2
        seed_state.status = SchedulerStatus.RUNNING
        state_manager.save_state(seed_state)

        # Resume run
        final_state = runner.run(dry_run=False, is_resume=True)
        assert final_state.completed == 5
        # Planner should have been called for remaining 3 items
        mock_planner.plan_daily_activities.assert_called_once_with(
            target_count=3,
            record_in_history=False,
        )
