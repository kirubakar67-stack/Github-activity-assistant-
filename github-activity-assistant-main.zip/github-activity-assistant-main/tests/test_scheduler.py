"""Unit tests for ActivityScheduler (app/scheduler/scheduler.py)."""

from __future__ import annotations

from datetime import datetime
from unittest import mock
from zoneinfo import ZoneInfo
import pytest

from app.scheduler.daily_runner import DailyRunner
from app.scheduler.scheduler import ActivityScheduler
from app.scheduler.state import DailyState, SchedulerStatus


class TestActivityScheduler:
    """Test suite for ActivityScheduler class."""

    @pytest.fixture
    def mock_runner(self) -> mock.MagicMock:
        """Provide mocked DailyRunner."""
        runner = mock.MagicMock(spec=DailyRunner)
        runner.target = 5
        runner.run.return_value = DailyState(
            date="2026-08-19",
            status=SchedulerStatus.COMPLETED,
            target=5,
            completed=5,
        )
        return runner

    def test_calculate_next_run_before_target_time(self, mock_runner: mock.MagicMock) -> None:
        """If current time is before schedule time, next run is today."""
        scheduler = ActivityScheduler(
            daily_runner=mock_runner,
            schedule_time_str="18:00",
            timezone_name="Asia/Kolkata",
        )

        tz = ZoneInfo("Asia/Kolkata")
        # 10:00 AM on 2026-08-19
        ref_dt = datetime(2026, 8, 19, 10, 0, 0, tzinfo=tz)

        next_run = scheduler.calculate_next_run(from_dt=ref_dt)
        assert next_run.year == 2026
        assert next_run.month == 8
        assert next_run.day == 19
        assert next_run.hour == 18
        assert next_run.minute == 0

    def test_calculate_next_run_after_target_time(self, mock_runner: mock.MagicMock) -> None:
        """If current time is after schedule time, next run is tomorrow."""
        scheduler = ActivityScheduler(
            daily_runner=mock_runner,
            schedule_time_str="18:00",
            timezone_name="Asia/Kolkata",
        )

        tz = ZoneInfo("Asia/Kolkata")
        # 19:30 on 2026-08-19
        ref_dt = datetime(2026, 8, 19, 19, 30, 0, tzinfo=tz)

        next_run = scheduler.calculate_next_run(from_dt=ref_dt)
        assert next_run.day == 20
        assert next_run.hour == 18
        assert next_run.minute == 0

    def test_calculate_seconds_until_next_run(self, mock_runner: mock.MagicMock) -> None:
        """Seconds calculation should return accurate positive difference."""
        scheduler = ActivityScheduler(
            daily_runner=mock_runner,
            schedule_time_str="18:00",
            timezone_name="Asia/Kolkata",
        )

        tz = ZoneInfo("Asia/Kolkata")
        ref_dt = datetime(2026, 8, 19, 17, 30, 0, tzinfo=tz)

        seconds = scheduler.calculate_seconds_until_next_run(from_dt=ref_dt)
        assert seconds == 1800.0  # 30 minutes = 1800 seconds

    def test_scheduler_single_cycle_execution(self, mock_runner: mock.MagicMock) -> None:
        """Scheduler should trigger runner and exit after max_cycles reached."""
        scheduler = ActivityScheduler(
            daily_runner=mock_runner,
            schedule_time_str="18:00",
            timezone_name="Asia/Kolkata",
            sleep_func=lambda s: None,
        )

        # Mock seconds remaining to simulate immediate trigger
        scheduler.calculate_seconds_until_next_run = mock.MagicMock(return_value=0.0)

        scheduler.start(dry_run=False, max_cycles=1)

        mock_runner.run.assert_called_once_with(dry_run=False, force=False)

    def test_pause_and_resume(self, mock_runner: mock.MagicMock) -> None:
        """Pause and resume methods toggle state."""
        scheduler = ActivityScheduler(
            daily_runner=mock_runner,
            schedule_time_str="18:00",
            timezone_name="Asia/Kolkata",
        )

        assert scheduler.is_paused is False
        scheduler.pause()
        assert scheduler.is_paused is True
        scheduler.resume()
        assert scheduler.is_paused is False
