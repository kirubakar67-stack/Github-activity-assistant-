"""Unit tests for TerminalDashboard (app/monitoring/dashboard.py)."""

from __future__ import annotations

from pathlib import Path
from unittest import mock
import pytest

from app.monitoring.dashboard import TerminalDashboard
from app.monitoring.history_store import ActivityRecord, HistoryStore
from app.scheduler.state import DailyState, SchedulerStatus, SchedulerStateManager


class TestTerminalDashboard:
    """Test suite for TerminalDashboard formatting and rendering."""

    @pytest.fixture
    def dashboard(self, tmp_path: Path) -> TerminalDashboard:
        """Provide TerminalDashboard with temporary history and state."""
        store = HistoryStore(history_file=tmp_path / "activity_history.json")
        store.add_record(
            ActivityRecord(
                date="2026-08-19",
                timestamp="2026-08-19T18:00:00Z",
                repository="owner/repo1",
                activity_type="documentation",
                title="Documentation update",
                status="committed",
                commit_hash="c111222",
                commit_message="docs: update notes",
            )
        )
        store.add_record(
            ActivityRecord(
                date="2026-08-19",
                timestamp="2026-08-19T18:05:00Z",
                repository="owner/repo2",
                activity_type="changelog",
                title="Changelog update",
                status="failed",
                error="Working tree dirty",
            )
        )

        state_mgr = SchedulerStateManager(state_file=tmp_path / "scheduler_state.json")
        state_mgr.save_state(
            DailyState(
                date="2026-08-19",
                status=SchedulerStatus.COMPLETED,
                target=5,
                completed=1,
                failed=1,
            )
        )

        return TerminalDashboard(
            history_store=store,
            state_manager=state_mgr,
            timezone_name="Asia/Kolkata",
            daily_target=5,
            sleep_func=lambda s: None,
        )

    def test_dashboard_render_contains_all_sections(self, dashboard: TerminalDashboard) -> None:
        """Rendered dashboard string must contain all major monitoring sections."""
        rendered = dashboard.render()

        assert "GITHUB ACTIVITY ASSISTANT -- DASHBOARD" in rendered
        assert "TODAY'S PROGRESS" in rendered

        assert "REPOSITORY DISTRIBUTION" in rendered
        assert "ACTIVITY TYPES" in rendered
        assert "RECENT ACTIVITIES" in rendered
        assert "RECENT FAILURES" in rendered
        assert "APPLICATION ACTIVITY CALENDAR" in rendered
        assert "COMPLETED" in rendered
        assert "owner/repo1" in rendered or "repo1" in rendered

    def test_progress_bar_formatting(self, dashboard: TerminalDashboard) -> None:
        """_render_progress_bar renders accurate percentage and filled blocks."""
        bar_0 = dashboard._render_progress_bar(0.0)
        assert "0.0%" in bar_0
        assert "-" in bar_0

        bar_50 = dashboard._render_progress_bar(50.0)
        assert "50.0%" in bar_50
        assert "#" in bar_50
        assert "-" in bar_50

        bar_100 = dashboard._render_progress_bar(100.0)
        assert "100.0%" in bar_100
        assert "-" not in bar_100


    def test_render_live_single_tick(self, dashboard: TerminalDashboard) -> None:
        """render_live should execute max_ticks cycles cleanly."""
        with mock.patch("os.system") as mock_os:
            dashboard.render_live(refresh_seconds=1, max_ticks=1)
            mock_os.assert_called_once()
