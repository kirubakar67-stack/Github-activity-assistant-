"""Unit tests for StatisticsEngine (app/monitoring/statistics.py)."""

from __future__ import annotations

from pathlib import Path
import pytest

from app.monitoring.history_store import ActivityRecord, HistoryStore
from app.monitoring.statistics import StatisticsEngine


class TestStatisticsEngine:
    """Test suite for StatisticsEngine analytical computations."""

    @pytest.fixture
    def populated_engine(self, tmp_path: Path) -> StatisticsEngine:
        """Provide StatisticsEngine with seeded mock history records."""
        store = HistoryStore(history_file=tmp_path / "activity_history.json")

        records = [
            ActivityRecord(
                date="2026-08-19",
                repository="owner/repo1",
                activity_type="documentation",
                status="committed",
                commit_hash="c111",
                duration=2.0,
            ),
            ActivityRecord(
                date="2026-08-19",
                repository="owner/repo1",
                activity_type="documentation",
                status="committed",
                commit_hash="c222",
                duration=3.0,
            ),
            ActivityRecord(
                date="2026-08-19",
                repository="owner/repo2",
                activity_type="changelog",
                status="committed",
                commit_hash="c333",
                duration=1.0,
            ),
            ActivityRecord(
                date="2026-08-19",
                repository="owner/repo2",
                activity_type="progress_log",
                status="failed",
                error="Git lock error",
                duration=0.5,
            ),
        ]
        for r in records:
            store.add_record(r)

        return StatisticsEngine(history_store=store)

    def test_daily_progress_calculation(self, populated_engine: StatisticsEngine) -> None:
        """get_daily_progress computes target, completed, failed, and percentage."""
        prog = populated_engine.get_daily_progress(date_str="2026-08-19", target=5)

        assert prog["date"] == "2026-08-19"
        assert prog["target"] == 5
        assert prog["completed"] == 3
        assert prog["failed"] == 1
        assert prog["remaining"] == 2
        assert prog["progress_percent"] == 60.0

    def test_summary_statistics_metrics(self, populated_engine: StatisticsEngine) -> None:
        """get_summary_statistics computes aggregates and breakdown maps."""
        stats = populated_engine.get_summary_statistics(from_date="2026-08-19", to_date="2026-08-19")

        assert stats["total_activities"] == 4
        assert stats["successful_activities"] == 3
        assert stats["failed_activities"] == 1
        assert stats["success_rate"] == 75.0
        assert stats["most_active_repository"] in {"owner/repo1", "owner/repo2"}
        assert stats["most_common_activity_type"] == "Documentation"
        assert stats["average_duration_seconds"] == 1.62

        # Check repository breakdown
        repo1_stats = stats["repository_breakdown"]["owner/repo1"]
        assert repo1_stats["total"] == 2
        assert repo1_stats["successful"] == 2
        assert repo1_stats["success_rate"] == 100.0

        repo2_stats = stats["repository_breakdown"]["owner/repo2"]
        assert repo2_stats["total"] == 2
        assert repo2_stats["failed"] == 1
        assert repo2_stats["success_rate"] == 50.0

    def test_empty_statistics_handles_zero_division(self, tmp_path: Path) -> None:
        """Empty history store should return safe zeroes without errors."""
        empty_store = HistoryStore(history_file=tmp_path / "empty_history.json")
        engine = StatisticsEngine(history_store=empty_store)

        stats = engine.get_summary_statistics()
        assert stats["total_activities"] == 0
        assert stats["success_rate"] == 0.0
        assert stats["most_active_repository"] == "None"
        assert stats["most_common_activity_type"] == "None"

        prog = engine.get_daily_progress(target=5)
        assert prog["completed"] == 0
        assert prog["remaining"] == 5
        assert prog["progress_percent"] == 0.0

    def test_calendar_data_matrix(self, populated_engine: StatisticsEngine) -> None:
        """get_calendar_data returns correct 4-week grid of 28 day elements."""
        days = populated_engine.get_calendar_data(weeks=4, end_date_str="2026-08-19")
        assert len(days) == 28

        # 2026-08-19 should have activity recorded
        day_19 = next((d for d in days if d["date"] == "2026-08-19"), None)
        assert day_19 is not None
        assert day_19["has_activity"] is True
        assert day_19["activity_count"] == 3
