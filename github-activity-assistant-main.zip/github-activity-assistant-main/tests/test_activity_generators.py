"""Unit tests for activity generators (app/activity/generators.py)."""

from __future__ import annotations

from datetime import datetime, timezone
import pytest

from app.activity.generators import ActivityGenerator
from app.activity.models import ActivityType


class TestActivityGenerators:
    """Test suite for ActivityGenerator class."""

    @pytest.fixture
    def generator(self) -> ActivityGenerator:
        """Provide generator instance with fixed base date."""
        fixed_date = datetime(2026, 8, 19, 12, 0, 0, tzinfo=timezone.utc)
        return ActivityGenerator(base_date=fixed_date)

    @pytest.mark.parametrize(
        "act_type, expected_file",
        [
            (ActivityType.PROGRESS_LOG, "docs/progress.md"),
            (ActivityType.DOCUMENTATION, "docs/notes.md"),
            (ActivityType.CHANGELOG, "CHANGELOG.md"),
            (ActivityType.PROJECT_NOTES, "PROJECT_LOG.md"),
            (ActivityType.TODO_UPDATE, "TODO.md"),
            (ActivityType.CONFIGURATION_DOCS, "docs/configuration.md"),
            (ActivityType.TEST_DATA, "docs/test_scenarios.md"),
            (ActivityType.CODE_COMMENTS, "docs/code_structure.md"),
        ],
    )
    def test_generators_produce_valid_structure(
        self, generator: ActivityGenerator, act_type: ActivityType, expected_file: str
    ) -> None:
        """Each generator should produce structured metadata and non-trivial content."""
        title, description, target_file, content, reason = generator.generate(
            activity_type=act_type,
            repository_name="owner/sample-repo",
            sequence_index=0,
        )

        assert target_file == expected_file
        assert len(title) >= 10
        assert len(description) >= 15
        assert len(content) >= 30
        assert "sample-repo" in title or "sample-repo" in content or "2026-08-19" in content
        assert len(reason) >= 10

    def test_generator_respects_preferred_file(self, generator: ActivityGenerator) -> None:
        """Preferred file parameter should override standard default file path."""
        title, desc, target_file, content, reason = generator.generate(
            activity_type=ActivityType.DOCUMENTATION,
            repository_name="owner/my-repo",
            preferred_file="README.md",
        )
        assert target_file == "README.md"

    def test_generator_produces_variations(self, generator: ActivityGenerator) -> None:
        """Different sequence indices should produce distinct variations of content."""
        _, _, _, content_0, _ = generator.generate(
            activity_type=ActivityType.PROGRESS_LOG,
            repository_name="owner/repo",
            sequence_index=0,
        )
        _, _, _, content_1, _ = generator.generate(
            activity_type=ActivityType.PROGRESS_LOG,
            repository_name="owner/repo",
            sequence_index=1,
        )

        assert content_0 != content_1
        assert "2026-08-19" in content_0
        assert "2026-08-19" in content_1

    def test_generated_content_never_meaningless(self, generator: ActivityGenerator) -> None:
        """Generated content must never be short meaningless strings."""
        for act_type in ActivityType:
            _, _, _, content, _ = generator.generate(
                activity_type=act_type,
                repository_name="owner/test-project",
            )
            assert content not in {".", "..", "update", "test", "hello"}
            assert sum(1 for c in content if c.isalnum()) > 20
