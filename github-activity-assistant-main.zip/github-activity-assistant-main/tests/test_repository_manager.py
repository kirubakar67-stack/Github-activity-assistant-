"""Unit tests for Repository Manager (app/repository_manager.py).

All tests utilize mocks to prevent real network calls or token exposure.
"""

from __future__ import annotations

from unittest import mock

import pytest

from app.github_client import (
    GitHubClient,
    GitHubRepositoryError,
    RepositoryInfo,
)
from app.repository_manager import RepositoryManager


class TestRepositoryManager:
    """Test suite for RepositoryManager class."""

    def test_init_empty_repositories_raises_error(self) -> None:
        """Manager should fail initialization if empty repositories sequence is provided."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        with pytest.raises(ValueError, match="requires at least one repository"):
            RepositoryManager(client=mock_client, repositories=[])

    def test_init_valid_manager(self) -> None:
        """Manager should store configured repositories and client reference."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        repos = ["user/repo1", "user/repo2", "user/repo3", "user/repo4"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        assert manager.count() == 4
        assert manager.repositories == repos
        assert manager.client == mock_client

    def test_validate_repositories_all_success(self) -> None:
        """Validate that all accessible repositories produce populated RepositoryInfo list."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        mock_client.check_repository_access.side_effect = lambda r: RepositoryInfo(
            name=r.split("/")[1],
            full_name=r,
            owner=r.split("/")[0],
            visibility="public",
            default_branch="main",
            description=f"Description of {r}",
            accessible=True,
            can_push=True,
        )

        repos = ["user/repo1", "user/repo2", "user/repo3", "user/repo4"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        results = manager.validate_repositories()

        assert len(results) == 4
        assert all(r.accessible for r in results)
        assert results[0].full_name == "user/repo1"
        assert results[3].full_name == "user/repo4"
        assert mock_client.check_repository_access.call_count == 4

    def test_validate_repositories_mixed_failure(self) -> None:
        """Ensure failure in one repository does not crash validation for other repositories."""
        mock_client = mock.MagicMock(spec=GitHubClient)

        def mock_access(repo_name: str) -> RepositoryInfo:
            if repo_name == "user/broken-repo":
                raise GitHubRepositoryError("Repository 'user/broken-repo' was not found.")
            return RepositoryInfo(
                name=repo_name.split("/")[1],
                full_name=repo_name,
                owner=repo_name.split("/")[0],
                visibility="public",
                default_branch="main",
                accessible=True,
                can_push=True,
            )

        mock_client.check_repository_access.side_effect = mock_access

        repos = ["user/good-repo-1", "user/broken-repo", "user/good-repo-2"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        results = manager.validate_repositories()

        assert len(results) == 3
        assert results[0].accessible is True
        assert results[1].accessible is False
        assert "was not found" in (results[1].error_reason or "")
        assert results[2].accessible is True

    def test_get_repository_by_name(self) -> None:
        """get_repository with name should query client with resolved repo name."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        mock_repo = mock.MagicMock()
        mock_repo.full_name = "user/repo2"
        mock_client.get_repository.return_value = mock_repo

        repos = ["user/repo1", "user/repo2"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        result = manager.get_repository("user/repo2")
        mock_client.get_repository.assert_called_once_with("user/repo2")
        assert result.full_name == "user/repo2"

    def test_get_repository_by_index(self) -> None:
        """get_repository with 1-based index should resolve to corresponding repo name."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        mock_repo = mock.MagicMock()
        mock_repo.full_name = "user/repo2"
        mock_client.get_repository.return_value = mock_repo

        repos = ["user/repo1", "user/repo2", "user/repo3"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        result = manager.get_repository(2)
        mock_client.get_repository.assert_called_once_with("user/repo2")
        assert result.full_name == "user/repo2"

    def test_get_repository_index_out_of_bounds(self) -> None:
        """Invalid index (0 or > count) should raise IndexError."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        repos = ["user/repo1", "user/repo2"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        with pytest.raises(IndexError, match="out of range"):
            manager.get_repository(0)

        with pytest.raises(IndexError, match="out of range"):
            manager.get_repository(3)

    def test_get_repository_unconfigured_name(self) -> None:
        """Unconfigured repo name should raise GitHubRepositoryError."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        repos = ["user/repo1", "user/repo2"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        with pytest.raises(GitHubRepositoryError, match="not in configured repositories"):
            manager.get_repository("unconfigured/repo")

    def test_select_repository_valid_index(self) -> None:
        """select_repository should return RepositoryInfo for the 1-based index."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        mock_client.check_repository_access.return_value = RepositoryInfo(
            name="repo3",
            full_name="user/repo3",
            owner="user",
            visibility="private",
            default_branch="main",
            accessible=True,
        )

        repos = ["user/repo1", "user/repo2", "user/repo3", "user/repo4"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        info = manager.select_repository(3)
        mock_client.check_repository_access.assert_called_once_with("user/repo3")
        assert info.full_name == "user/repo3"
        assert info.visibility == "private"

    def test_get_all_repositories_uses_cached_validation(self) -> None:
        """get_all_repositories should not re-query client when results are cached."""
        mock_client = mock.MagicMock(spec=GitHubClient)
        mock_client.check_repository_access.return_value = RepositoryInfo(
            name="repo1",
            full_name="user/repo1",
            owner="user",
            visibility="public",
            default_branch="main",
            accessible=True,
        )

        repos = ["user/repo1"]
        manager = RepositoryManager(client=mock_client, repositories=repos)

        first_call = manager.validate_repositories()
        second_call = manager.get_all_repositories()

        assert first_call == second_call
        assert mock_client.check_repository_access.call_count == 1
