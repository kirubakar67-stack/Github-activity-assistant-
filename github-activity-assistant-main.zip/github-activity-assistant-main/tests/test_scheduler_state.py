"""Unit tests for Scheduler State model and Manager (app/scheduler/state.py)."""

from __future__ import annotations

from pathlib import Path
import pytest

from app.scheduler.state import DailyState, SchedulerStatus, SchedulerStateManager


class TestSchedulerState:
    """Test suite for DailyState and SchedulerStateManager."""

    @pytest.fixture
    def state_manager(self, tmp_path: Path) -> SchedulerStateManager:
        """Provide state manager using temporary JSON state file."""
        return SchedulerStateManager(state_file=tmp_path / "scheduler_state.json")

    def test_daily_state_serialization(self) -> None:
        """DailyState to_dict and from_dict roundtrip should preserve fields."""
        state = DailyState(
            date="2026-08-19",
            status=SchedulerStatus.COMPLETED,
            target=5,
            completed=5,
            failed=0,
            started_at="2026-08-19T12:00:00Z",
            completed_at="2026-08-19T12:05:00Z",
            activities=[{"repository": "owner/repo", "status": "SUCCESS"}],
        )

        d = state.to_dict()
        assert d["status"] == "COMPLETED"
        assert d["completed"] == 5

        recreated = DailyState.from_dict(d)
        assert recreated.date == "2026-08-19"
        assert recreated.status == SchedulerStatus.COMPLETED
        assert len(recreated.activities) == 1

    def test_get_or_create_state_new_day(self, state_manager: SchedulerStateManager) -> None:
        """get_or_create_state should create fresh state when no state exists."""
        state = state_manager.get_or_create_state(date_str="2026-08-19", target=5)
        assert state.date == "2026-08-19"
        assert state.target == 5
        assert state.completed == 0
        assert state.status == SchedulerStatus.IDLE

        # State file should now exist on disk
        assert state_manager.state_file.exists()

    def test_is_today_completed(self, state_manager: SchedulerStateManager) -> None:
        """is_today_completed returns True when COMPLETED or completed >= target."""
        assert state_manager.is_today_completed("2026-08-19") is False

        state = state_manager.get_or_create_state(date_str="2026-08-19", target=3)
        state.completed = 3
        state.status = SchedulerStatus.COMPLETED
        state_manager.save_state(state)

        assert state_manager.is_today_completed("2026-08-19") is True
        assert state_manager.is_today_completed("2026-08-20") is False

    def test_detect_incomplete_run(self, state_manager: SchedulerStateManager) -> None:
        """detect_incomplete_run detects interrupted runs."""
        assert state_manager.detect_incomplete_run() is None

        # Create RUNNING state with 2/5 completed
        state = state_manager.get_or_create_state(date_str="2026-08-19", target=5)
        state.completed = 2
        state.status = SchedulerStatus.RUNNING
        state_manager.save_state(state)

        incomplete = state_manager.detect_incomplete_run("2026-08-19")
        assert incomplete is not None
        assert incomplete.completed == 2
        assert incomplete.status == SchedulerStatus.RUNNING

    def test_clear_state(self, state_manager: SchedulerStateManager) -> None:
        """clear removes state file from disk."""
        state_manager.get_or_create_state("2026-08-19", 5)
        assert state_manager.state_file.exists()

        state_manager.clear()
        assert not state_manager.state_file.exists()
