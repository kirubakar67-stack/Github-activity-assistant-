"""Unit tests for Git Manager (app/git/git_manager.py) using isolated temporary Git repositories."""

from __future__ import annotations

import subprocess
from pathlib import Path
import pytest

from app.git.git_manager import GitError, GitManager


@pytest.fixture
def temp_git_repo(tmp_path: Path) -> Path:
    """Create and initialize a temporary Git repository on disk."""
    repo_dir = tmp_path / "test_git_repo"
    repo_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Git repository
    subprocess.run(["git", "init", "-b", "main", str(repo_dir)], check=True, capture_output=True)

    # Configure local git user for commits in test
    subprocess.run(["git", "config", "user.name", "Test Runner"], cwd=str(repo_dir), check=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=str(repo_dir), check=True)

    # Create initial commit so HEAD exists
    readme = repo_dir / "README.md"
    readme.write_text("# Test Repo\nInitial content.\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=str(repo_dir), check=True)
    subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=str(repo_dir), check=True)

    return repo_dir


class TestGitManager:
    """Test suite for GitManager methods."""

    @pytest.fixture
    def git_mgr(self) -> GitManager:
        """Provide GitManager instance."""
        return GitManager()

    def test_repository_exists(self, git_mgr: GitManager, temp_git_repo: Path, tmp_path: Path) -> None:
        """repository_exists returns True for valid git repo, False otherwise."""
        assert git_mgr.repository_exists(temp_git_repo) is True
        assert git_mgr.repository_exists(tmp_path / "non_existent_directory") is False

    def test_is_clean_and_get_status(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """is_clean returns True when working tree has no changes, False when dirty."""
        assert git_mgr.is_clean(temp_git_repo) is True
        assert len(git_mgr.get_status(temp_git_repo)) == 0

        # Modify a file to make working tree dirty
        (temp_git_repo / "README.md").write_text("Modified content", encoding="utf-8")
        assert git_mgr.is_clean(temp_git_repo) is False
        assert len(git_mgr.get_status(temp_git_repo)) > 0

    def test_get_current_branch(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """get_current_branch should return 'main'."""
        assert git_mgr.get_current_branch(temp_git_repo) == "main"

    def test_read_and_write_file_safe(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """write_file and read_file should safely write and retrieve file content."""
        content = "## Progress Log\n- Step 1 completed."
        written_path = git_mgr.write_file(temp_git_repo, "docs/progress.md", content, append=False)

        assert written_path.exists()
        read_back = git_mgr.read_file(temp_git_repo, "docs/progress.md")
        assert read_back is not None
        assert "Step 1 completed" in read_back

    def test_write_file_append_mode(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """write_file with append=True should preserve existing text and add new text."""
        git_mgr.write_file(temp_git_repo, "docs/notes.md", "First entry", append=False)
        git_mgr.write_file(temp_git_repo, "docs/notes.md", "Second entry", append=True)

        content = git_mgr.read_file(temp_git_repo, "docs/notes.md")
        assert content is not None
        assert "First entry" in content
        assert "Second entry" in content

    def test_path_traversal_forbidden(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """write_file and read_file must reject path traversal outside repo root."""
        with pytest.raises(GitError, match="Security Violation"):
            git_mgr.write_file(temp_git_repo, "../outside.txt", "evil content")

        with pytest.raises(GitError, match="Security Violation"):
            git_mgr.read_file(temp_git_repo, "../../etc/passwd")

    def test_stage_and_diff(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """stage_file, get_staged_files, and get_diff should accurately track staged changes."""
        git_mgr.write_file(temp_git_repo, "docs/activity.md", "# Activity Log\n- Note 1")
        git_mgr.stage_file(temp_git_repo, "docs/activity.md")

        staged = git_mgr.get_staged_files(temp_git_repo)
        assert "docs/activity.md" in staged

        diff = git_mgr.get_diff(temp_git_repo, cached=True)
        assert "+# Activity Log" in diff

    def test_create_commit_and_get_last_commit(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """create_commit should stage, commit, and return valid commit hash."""
        git_mgr.write_file(temp_git_repo, "docs/notes.md", "New note entry")
        git_mgr.stage_file(temp_git_repo, "docs/notes.md")

        commit_hash = git_mgr.create_commit(
            temp_git_repo,
            message="docs: add developer notes",
            author_name="Automation Bot",
            author_email="bot@example.com",
        )

        assert len(commit_hash) >= 6
        last_commit = git_mgr.get_last_commit(temp_git_repo)
        assert last_commit["message"] == "docs: add developer notes"
        assert last_commit["author"] == "Automation Bot"

    def test_destructive_commands_strictly_forbidden(self, git_mgr: GitManager, temp_git_repo: Path) -> None:
        """Destructive command arguments must raise GitError immediately."""
        with pytest.raises(GitError, match="Prohibited destructive Git argument"):
            git_mgr._run_git(args=["reset", "--hard", "HEAD~1"], cwd=temp_git_repo)

        with pytest.raises(GitError, match="Prohibited destructive Git argument"):
            git_mgr._run_git(args=["clean", "-fd"], cwd=temp_git_repo)
