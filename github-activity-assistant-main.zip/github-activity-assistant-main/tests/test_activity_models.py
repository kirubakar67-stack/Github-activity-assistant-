"""Unit tests for activity models and enums (app/activity/models.py)."""

from __future__ import annotations

import hashlib
import pytest

from app.activity.models import ActivityPlan, ActivityType, ValidationResult


class TestActivityModels:
    """Test suite for ActivityPlan, ActivityType, and ValidationResult."""

    def test_activity_type_from_string(self) -> None:
        """ActivityType enum should parse case-insensitively from string."""
        assert ActivityType.from_string("documentation") == ActivityType.DOCUMENTATION
        assert ActivityType.from_string("PROGRESS_LOG") == ActivityType.PROGRESS_LOG
        assert ActivityType.from_string("Changelog") == ActivityType.CHANGELOG
        assert ActivityType.from_string("PROJECT_NOTES") == ActivityType.PROJECT_NOTES
        assert ActivityType.from_string("todo_update") == ActivityType.TODO_UPDATE

    def test_activity_type_invalid_string_raises_error(self) -> None:
        """Invalid string should raise ValueError."""
        with pytest.raises(ValueError, match="Invalid ActivityType"):
            ActivityType.from_string("invalid_type_123")

    def test_activity_plan_content_hash_auto_generation(self) -> None:
        """ActivityPlan should compute SHA-256 content_hash automatically."""
        content = "## Development Progress\n- Inspected module structure."
        plan = ActivityPlan(
            repository="owner/repo",
            activity_type=ActivityType.DOCUMENTATION,
            target_file="docs/notes.md",
            title="Update Notes",
            description="Add review observations to documentation.",
            proposed_content=content,
            reason="Maintain clear developer records.",
        )

        expected_hash = hashlib.sha256(content.strip().encode("utf-8")).hexdigest()
        assert plan.content_hash == expected_hash
        assert plan.valid is True
        assert plan.validation_error is None

    def test_activity_plan_serialization(self) -> None:
        """to_dict and from_dict roundtrip should preserve all attributes."""
        plan = ActivityPlan(
            repository="owner/repo",
            activity_type=ActivityType.CHANGELOG,
            target_file="CHANGELOG.md",
            title="Changelog entry",
            description="Record maintenance updates.",
            proposed_content="### Maintenance\n- Verified build.",
            reason="Auditable changelog history.",
        )

        plan_dict = plan.to_dict()
        assert plan_dict["activity_type"] == "changelog"
        assert plan_dict["repository"] == "owner/repo"

        recreated = ActivityPlan.from_dict(plan_dict)
        assert recreated.activity_type == ActivityType.CHANGELOG
        assert recreated.repository == plan.repository
        assert recreated.content_hash == plan.content_hash

    def test_validation_result_helpers(self) -> None:
        """ValidationResult success and failure factory methods."""
        success = ValidationResult.success()
        assert success.valid is True
        assert success.reason is None

        failure = ValidationResult.failure("Content contains secrets")
        assert failure.valid is False
        assert failure.reason == "Content contains secrets"
