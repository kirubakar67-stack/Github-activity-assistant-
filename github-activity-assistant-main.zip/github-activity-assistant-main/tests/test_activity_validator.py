"""Unit tests for activity validator and secret scanning (app/activity/validator.py)."""

from __future__ import annotations

import pytest

from app.activity.models import ActivityPlan, ActivityType
from app.activity.validator import ActivityValidator


class TestActivityValidator:
    """Test suite for ActivityValidator."""

    @pytest.fixture
    def validator(self) -> ActivityValidator:
        """Provide validator instance."""
        return ActivityValidator()

    def test_valid_plan_passes_validation(self, validator: ActivityValidator) -> None:
        """Legitimate ActivityPlan should pass validation cleanly."""
        plan = ActivityPlan(
            repository="owner/valid-repo",
            activity_type=ActivityType.DOCUMENTATION,
            target_file="docs/notes.md",
            title="Update developer notes",
            description="Add documentation review notes for project modules.",
            proposed_content=(
                "## Developer Notes — 2026-08-19\n\n"
                "- Conducted review of repository structure.\n"
                "- Verified component documentation alignment.\n"
            ),
            reason="Maintain clear developer documentation.",
        )
        result = validator.validate(plan)
        assert result.valid is True
        assert result.reason is None

    def test_empty_content_rejected(self, validator: ActivityValidator) -> None:
        """Empty or whitespace-only content should be rejected."""
        res = validator.validate_content("")
        assert res.valid is False
        assert "empty or whitespace-only" in (res.reason or "")

        res_ws = validator.validate_content("   \n\t  ")
        assert res_ws.valid is False

    @pytest.mark.parametrize(
        "meaningless",
        [".", "..", "...", ":::", "---", "test", "update", "hello", "abc"],
    )
    def test_meaningless_content_rejected(
        self, validator: ActivityValidator, meaningless: str
    ) -> None:
        """Trivial and punctuation-only strings must be rejected."""
        res = validator.validate_content(meaningless)
        assert res.valid is False

    def test_short_content_rejected(self, validator: ActivityValidator) -> None:
        """Content with fewer than 15 alphanumeric characters must be rejected."""
        res = validator.validate_content("## Hello!")
        assert res.valid is False
        assert "insufficient descriptive text" in (res.reason or "")

    def test_secret_detection_classic_pat(self, validator: ActivityValidator) -> None:
        """Classic GitHub Personal Access Token in content must be detected and rejected."""
        fake_pat = "ghp_" + "000000000000000000000000000000000000"
        leaked = f"export GITHUB_TOKEN={fake_pat}\n- Added token configuration."
        res = validator.validate_content(leaked)
        assert res.valid is False
        assert "credential detected" in (res.reason or "").lower()

    def test_secret_detection_fine_grained_pat(self, validator: ActivityValidator) -> None:
        """Fine-grained GitHub Personal Access Token in content must be detected and rejected."""
        fake_pat = "github_pat_" + "11AAAAAA00000000000000_0000000000000000000000000000000000000000000000000000000000"
        leaked = f"token = '{fake_pat}'"
        res = validator.validate_content(leaked)
        assert res.valid is False
        assert "credential detected" in (res.reason or "").lower()


    def test_secret_detection_private_key(self, validator: ActivityValidator) -> None:
        """Private key header in content must be detected and rejected."""
        leaked = "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0...\n-----END RSA PRIVATE KEY-----"
        res = validator.validate_content(leaked)
        assert res.valid is False
        assert "credential detected" in (res.reason or "").lower()

    def test_secret_detection_blocked_session_token(self) -> None:
        """Explicitly blocked session token passed to constructor must be detected."""
        custom_validator = ActivityValidator(blocked_tokens=["custom_session_secret_token_123"])
        leaked = "Configured token: custom_session_secret_token_123 for repository access."
        res = custom_validator.validate_content(leaked)
        assert res.valid is False
        assert "Active session token detected" in (res.reason or "")

    @pytest.mark.parametrize(
        "file_path, expected_valid",
        [
            ("docs/progress.md", True),
            ("CHANGELOG.md", True),
            ("PROJECT_LOG.md", True),
            ("README.md", True),
            ("config/settings.json", True),
            ("docs/notes.txt", True),
            ("scripts/helper.py", True),
            ("docs/spec.rst", True),
            ("docs/config.yaml", True),
            ("docs/config.yml", True),
            ("bad_extension.exe", False),
            ("script.sh", False),
            ("file_no_extension", False),
            ("../escape/path.md", False),
            ("/absolute/path.md", False),
            ("", False),
        ],
    )
    def test_target_file_validation(
        self, validator: ActivityValidator, file_path: str, expected_valid: bool
    ) -> None:
        """Target file extensions and path boundaries must be validated."""
        res = validator.validate_target_file(file_path)
        assert res.valid is expected_valid
