"""Unit tests for configuration loading and validation (app/config.py)."""

from __future__ import annotations

import os
from pathlib import Path
from unittest import mock

import pytest

from app.config import AppConfig, ConfigError, load_config, validate_repository_name


class TestConfigValidation:
    """Test suite for repository format and configuration validation."""

    @pytest.mark.parametrize(
        "repo_name, expected",
        [
            ("octocat/Hello-World", True),
            ("user-name/repo.name_123", True),
            ("org-123/my_cool_project", True),
            ("a/b", True),
            ("invalid", False),
            ("owner/repo/extra", False),
            ("owner/", False),
            ("/repo", False),
            ("", False),
            ("owner/repo name", False),
            ("owner/repo$name", False),
        ],
    )
    def test_validate_repository_name(self, repo_name: str, expected: bool) -> None:
        """Validate that repository strings correctly pass/fail regex validation."""
        assert validate_repository_name(repo_name) is expected

    def test_load_config_success(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test successful configuration loading from environment variables."""
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test_token_1234567890abcdef")
        monkeypatch.setenv("GITHUB_REPOSITORY", "testuser/test-repository")
        monkeypatch.setenv("DAILY_ACTIVITY_TARGET", "7")
        monkeypatch.setenv("SCHEDULE_TIME", "19:30")
        monkeypatch.setenv("TIMEZONE", "Asia/Kolkata")
        monkeypatch.setenv("SCHEDULER_ENABLED", "true")
        monkeypatch.setenv("MIN_ACTIVITY_INTERVAL_MINUTES", "10")

        monkeypatch.setenv("DASHBOARD_REFRESH_SECONDS", "10")
        monkeypatch.setenv("REPORT_DIRECTORY", "./custom_reports")

        config = load_config(load_env_file=False)

        assert isinstance(config, AppConfig)
        assert config.github_token == "ghp_test_token_1234567890abcdef"
        assert config.github_repository == "testuser/test-repository"
        assert config.github_repositories == ("testuser/test-repository",)
        assert config.owner == "testuser"
        assert config.repo_name == "test-repository"
        assert config.daily_activity_target == 7
        assert config.schedule_time == "19:30"
        assert config.timezone == "Asia/Kolkata"
        assert config.scheduler_enabled is True
        assert config.min_activity_interval_minutes == 10
        assert config.dashboard_refresh_seconds == 10
        assert config.report_directory == Path("./custom_reports")


    def test_load_config_four_repositories(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading exactly four repositories via GITHUB_REPOSITORIES."""
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test_token_1234567890abcdef")
        monkeypatch.setenv(
            "GITHUB_REPOSITORIES",
            "Kavin-Palanisamy/Repo1, Kavin-Palanisamy/Repo2, Kavin-Palanisamy/Repo3, Kavin-Palanisamy/Repo4",
        )

        config = load_config(load_env_file=False)

        assert isinstance(config, AppConfig)
        assert len(config.github_repositories) == 4
        assert config.github_repository == "Kavin-Palanisamy/Repo1"
        assert config.github_repositories == (
            "Kavin-Palanisamy/Repo1",
            "Kavin-Palanisamy/Repo2",
            "Kavin-Palanisamy/Repo3",
            "Kavin-Palanisamy/Repo4",
        )
        assert config.daily_activity_target == 5

    def test_load_config_duplicate_repository_rejected(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test that duplicate repository names are detected and rejected."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv(
            "GITHUB_REPOSITORIES",
            "Kavin-Palanisamy/Repo1, Kavin-Palanisamy/Repo2, Kavin-Palanisamy/Repo1",
        )

        with pytest.raises(ConfigError, match="Duplicate repository detected: 'Kavin-Palanisamy/Repo1'"):
            load_config(load_env_file=False)

    def test_load_config_duplicate_repository_case_insensitive(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test that duplicate repository detection is case-insensitive."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv(
            "GITHUB_REPOSITORIES",
            "owner/my-repo, OWNER/MY-REPO",
        )

        with pytest.raises(ConfigError, match="Duplicate repository detected"):
            load_config(load_env_file=False)

    def test_token_masking_in_repr(self) -> None:
        """Ensure token is masked in string/repr outputs to prevent log leakage."""
        config = AppConfig(
            github_token="ghp_sensitive_secret_token_12345",
            github_repository="user/repo",
        )
        repr_str = repr(config)
        assert "ghp_sensitive_secret_token_12345" not in repr_str
        assert "ghp_...2345" in repr_str

    def test_short_token_masking_in_repr(self) -> None:
        """Ensure very short tokens are completely masked."""
        config = AppConfig(
            github_token="short",
            github_repository="user/repo",
        )
        repr_str = repr(config)
        assert "short" not in repr_str
        assert "***" in repr_str

    def test_load_config_missing_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that missing GITHUB_TOKEN raises ConfigError."""
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")

        with pytest.raises(ConfigError, match="Missing 'GITHUB_TOKEN'"):
            load_config(load_env_file=False)

    def test_load_config_empty_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that empty or whitespace-only GITHUB_TOKEN raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "   ")
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")

        with pytest.raises(ConfigError, match="Missing 'GITHUB_TOKEN'"):
            load_config(load_env_file=False)

    def test_load_config_missing_repository(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that missing repository configuration raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.delenv("GITHUB_REPOSITORY", raising=False)
        monkeypatch.delenv("GITHUB_REPOSITORIES", raising=False)

        with pytest.raises(ConfigError, match="Missing repository configuration"):
            load_config(load_env_file=False)

    def test_load_config_empty_repository_list(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that empty commas in repository configuration raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORIES", " , , ")

        with pytest.raises(ConfigError, match="No valid repositories found"):
            load_config(load_env_file=False)

    def test_load_config_invalid_repository_format(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that malformed repository format raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORY", "not_a_valid_repo_format")

        with pytest.raises(ConfigError, match="Invalid repository format"):
            load_config(load_env_file=False)

    def test_load_config_invalid_one_of_multiple_repositories(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test that if one repo in a list is invalid, ConfigError is raised."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORIES", "valid/repo, invalid_format, valid/repo2")

        with pytest.raises(ConfigError, match="Invalid repository format: 'invalid_format'"):
            load_config(load_env_file=False)

    def test_load_config_invalid_daily_target_range(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """DAILY_ACTIVITY_TARGET outside 1..20 should raise ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")
        monkeypatch.setenv("DAILY_ACTIVITY_TARGET", "0")

        with pytest.raises(ConfigError, match="Invalid DAILY_ACTIVITY_TARGET: 0"):
            load_config(load_env_file=False)

        monkeypatch.setenv("DAILY_ACTIVITY_TARGET", "25")
        with pytest.raises(ConfigError, match="Invalid DAILY_ACTIVITY_TARGET: 25"):
            load_config(load_env_file=False)

    def test_load_config_non_integer_daily_target(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Non-integer DAILY_ACTIVITY_TARGET should raise ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")
        monkeypatch.setenv("DAILY_ACTIVITY_TARGET", "five")

        with pytest.raises(ConfigError, match="Expected an integer value"):
            load_config(load_env_file=False)

    def test_load_config_invalid_schedule_time(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Invalid SCHEDULE_TIME format raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")
        monkeypatch.setenv("SCHEDULE_TIME", "25:00")

        with pytest.raises(ConfigError, match="Invalid SCHEDULE_TIME"):
            load_config(load_env_file=False)

    def test_load_config_invalid_timezone(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Invalid TIMEZONE name raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")
        monkeypatch.setenv("TIMEZONE", "Invalid/Fake_Zone")

        with pytest.raises(ConfigError, match="Invalid TIMEZONE"):
            load_config(load_env_file=False)

    def test_load_config_invalid_boolean(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Invalid SCHEDULER_ENABLED raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")
        monkeypatch.setenv("SCHEDULER_ENABLED", "maybe")

        with pytest.raises(ConfigError, match="Invalid boolean value"):
            load_config(load_env_file=False)

    def test_load_config_from_explicit_file(self, tmp_path: Path) -> None:
        """Test loading configuration from an explicit .env file path."""
        env_file = tmp_path / ".env.test"
        env_file.write_text(
            "GITHUB_TOKEN=ghp_file_loaded_token\n"
            "GITHUB_REPOSITORIES=file-owner/repo-1, file-owner/repo-2\n"
            "DAILY_ACTIVITY_TARGET=6\n"
            "SCHEDULE_TIME=18:30\n"
            "TIMEZONE=UTC\n"
            "SCHEDULER_ENABLED=false\n",
            encoding="utf-8",
        )

        config = load_config(env_path=env_file, load_env_file=True)
        assert config.github_token == "ghp_file_loaded_token"
        assert config.github_repository == "file-owner/repo-1"
        assert config.github_repositories == ("file-owner/repo-1", "file-owner/repo-2")
        assert config.daily_activity_target == 6
        assert config.schedule_time == "18:30"
        assert config.timezone == "UTC"

    def test_load_config_invalid_dashboard_refresh(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Invalid DASHBOARD_REFRESH_SECONDS out of 1..60 raises ConfigError."""
        monkeypatch.setenv("GITHUB_TOKEN", "valid_token")
        monkeypatch.setenv("GITHUB_REPOSITORY", "user/repo")
        monkeypatch.setenv("DASHBOARD_REFRESH_SECONDS", "0")

        with pytest.raises(ConfigError, match="Invalid DASHBOARD_REFRESH_SECONDS: 0"):
            load_config(load_env_file=False)

        monkeypatch.setenv("DASHBOARD_REFRESH_SECONDS", "100")
        with pytest.raises(ConfigError, match="Invalid DASHBOARD_REFRESH_SECONDS: 100"):
            load_config(load_env_file=False)

        monkeypatch.setenv("DASHBOARD_REFRESH_SECONDS", "ten")
        with pytest.raises(ConfigError, match="Invalid DASHBOARD_REFRESH_SECONDS: 'ten'"):
            load_config(load_env_file=False)

