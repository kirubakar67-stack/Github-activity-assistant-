"""Unit tests for Activity Logger (app/logging/activity_logger.py)."""

from __future__ import annotations

import logging
from pathlib import Path
import pytest

from app.logging.activity_logger import SecretMaskingFilter, setup_logger


class TestActivityLogger:
    """Test suite for ActivityLogger and SecretMaskingFilter."""

    def test_logger_file_creation_and_writing(self, tmp_path: Path) -> None:
        """Logger should create log file and record formatted messages."""
        log_file = tmp_path / "test_assistant.log"
        logger = setup_logger(log_file=log_file, level=logging.INFO)

        logger.info("Test activity log message.")

        # Force flush / verify file content
        for h in logger.handlers:
            h.flush()

        assert log_file.exists()
        content = log_file.read_text(encoding="utf-8")
        assert "INFO" in content
        assert "Test activity log message." in content

    def test_secret_masking_in_logs(self, tmp_path: Path) -> None:
        """Sensitive token in log messages must be redacted."""
        secret_token = "ghp_sensitive_token_1234567890abcdef"
        masking_filter = SecretMaskingFilter(blocked_tokens=[secret_token])

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg=f"Connecting with token {secret_token} to GitHub",
            args=(),
            exc_info=None,
        )

        masking_filter.filter(record)
        assert secret_token not in record.msg
        assert "***" in record.msg
