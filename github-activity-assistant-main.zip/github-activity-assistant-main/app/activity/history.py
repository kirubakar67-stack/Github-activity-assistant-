"""Local activity history manager for duplicate prevention and audit records."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from app.activity.models import ActivityPlan, ActivityType

DEFAULT_HISTORY_FILE: Path = Path("data") / "activity_history.json"


class ActivityHistoryManager:
    """Manages reading and writing activity history to a local JSON file."""

    def __init__(self, history_file: Optional[Path | str] = None) -> None:
        """Initialize ActivityHistoryManager.

        Args:
            history_file: Optional path to the activity history JSON file.
        """
        self._history_file = Path(history_file or DEFAULT_HISTORY_FILE)

    @property
    def history_file(self) -> Path:
        """Return the history file path."""
        return self._history_file

    def _load_records(self) -> list[dict[str, Any]]:
        """Load records from the JSON history file."""
        if not self._history_file.exists():
            return []
        try:
            with open(self._history_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception:
            return []

    def _save_records(self, records: list[dict[str, Any]]) -> None:
        """Save records to the JSON history file."""
        self._history_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self._history_file, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2)

    def has_content_hash(self, repository: str, content_hash: str) -> bool:
        """Check if identical content has already been proposed or recorded for a repository.

        Args:
            repository: Repository identifier ('owner/repo').
            content_hash: SHA-256 hash of proposed content.

        Returns:
            True if matching record exists, False otherwise.
        """
        if not content_hash:
            return False
        records = self._load_records()
        repo_lower = repository.lower()
        for r in records:
            if r.get("repository", "").lower() == repo_lower and r.get("content_hash") == content_hash:
                return True
        return False

    def count_activities_for_date(
        self, repository: str, date_str: Optional[str] = None
    ) -> int:
        """Count how many activities have been recorded for a repository on a given date.

        Args:
            repository: Target repository.
            date_str: Date string (YYYY-MM-DD), defaults to today UTC.

        Returns:
            Count of matching records.
        """
        target_date = date_str or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        repo_lower = repository.lower()
        records = self._load_records()
        return sum(
            1
            for r in records
            if r.get("repository", "").lower() == repo_lower and r.get("date") == target_date
        )

    def record_plan(
        self,
        plan: ActivityPlan,
        status: str = "PLANNED",
    ) -> None:
        """Record an activity plan in the local history.

        Args:
            plan: The ActivityPlan to record.
            status: Status label (e.g. 'PLANNED', 'DRY_RUN', 'COMPLETED').
        """
        records = self._load_records()
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        entry = {
            "date": date_str,
            "repository": plan.repository,
            "activity_type": plan.activity_type.value,
            "target_file": plan.target_file,
            "title": plan.title,
            "content_hash": plan.content_hash,
            "status": status,
            "created_at": plan.created_at,
        }
        records.append(entry)
        self._save_records(records)

    def get_history(self, repository: Optional[str] = None) -> list[dict[str, Any]]:
        """Retrieve recorded history, optionally filtered by repository.

        Args:
            repository: Optional repository identifier filter.

        Returns:
            List of record dictionaries.
        """
        records = self._load_records()
        if repository is None:
            return records
        repo_lower = repository.lower()
        return [r for r in records if r.get("repository", "").lower() == repo_lower]

    def clear(self) -> None:
        """Clear all records from the history file."""
        if self._history_file.exists():
            self._history_file.unlink()
