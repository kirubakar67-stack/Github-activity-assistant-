"""Data models and enums for activity planning and validation."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


class ActivityType(str, Enum):
    """Controlled, legitimate activity categories."""

    DOCUMENTATION = "documentation"
    CHANGELOG = "changelog"
    PROJECT_NOTES = "project_notes"
    PROGRESS_LOG = "progress_log"
    TODO_UPDATE = "todo_update"
    TEST_DATA = "test_data"
    CODE_COMMENTS = "code_comments"
    CONFIGURATION_DOCS = "configuration_docs"

    @classmethod
    def from_string(cls, value: str) -> ActivityType:
        """Parse activity type from string case-insensitively."""
        normalized = value.strip().lower()
        for item in cls:
            if item.value == normalized:
                return item
        raise ValueError(f"Invalid ActivityType: '{value}'")


@dataclass(frozen=True)
class ValidationResult:
    """Encapsulates the result of activity plan validation."""

    valid: bool
    reason: Optional[str] = None

    @classmethod
    def success(cls) -> ValidationResult:
        """Create a successful validation outcome."""
        return cls(valid=True, reason=None)

    @classmethod
    def failure(cls, reason: str) -> ValidationResult:
        """Create a failed validation outcome with an explanation."""
        return cls(valid=False, reason=reason)


@dataclass
class ActivityPlan:
    """Represents a planned, validated repository activity.

    Attributes:
        repository: Target repository in 'owner/repo' format.
        activity_type: Validated category of the activity.
        target_file: Relative repository path of the target file to be updated.
        title: Human-readable summary title.
        description: Detailed rationale of the planned activity.
        proposed_content: Exact Markdown or text content to be appended/recorded.
        reason: Justification for this legitimate activity.
        created_at: ISO 8601 UTC timestamp.
        valid: Whether the plan passed validation checks.
        validation_error: Optional reason if plan failed validation.
        content_hash: SHA-256 hash of proposed content for duplicate prevention.
    """

    repository: str
    activity_type: ActivityType
    target_file: str
    title: str
    description: str
    proposed_content: str
    reason: str
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    valid: bool = True
    validation_error: Optional[str] = None
    content_hash: str = field(default="")

    def __post_init__(self) -> None:
        """Compute content hash and normalize activity_type if necessary."""
        if isinstance(self.activity_type, str) and not isinstance(self.activity_type, ActivityType):
            self.activity_type = ActivityType.from_string(self.activity_type)

        if not self.content_hash and self.proposed_content:
            normalized = self.proposed_content.strip().encode("utf-8")
            self.content_hash = hashlib.sha256(normalized).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Convert the ActivityPlan to a serializable dictionary."""
        data = asdict(self)
        data["activity_type"] = self.activity_type.value
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActivityPlan:
        """Recreate an ActivityPlan from a dictionary."""
        return cls(
            repository=data["repository"],
            activity_type=ActivityType.from_string(data["activity_type"]),
            target_file=data["target_file"],
            title=data["title"],
            description=data["description"],
            proposed_content=data["proposed_content"],
            reason=data["reason"],
            created_at=data.get("created_at", datetime.now(timezone.utc).isoformat()),
            valid=data.get("valid", True),
            validation_error=data.get("validation_error"),
            content_hash=data.get("content_hash", ""),
        )
