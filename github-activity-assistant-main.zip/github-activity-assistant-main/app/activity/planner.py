"""Activity planning engine for GitHub Activity Assistant.

Coordinates multi-repository rotation, activity type selection, legitimate content generation,
safety validation, and duplicate prevention without modifying repository content.
"""

from __future__ import annotations

from typing import Optional, Sequence

from app.activity.generators import ActivityGenerator
from app.activity.history import ActivityHistoryManager
from app.activity.models import ActivityPlan, ActivityType
from app.activity.validator import ActivityValidator
from app.repository_manager import RepositoryManager

# Standard activity types used in daily planning rotation
STANDARD_ACTIVITY_ROTATION: list[ActivityType] = [
    ActivityType.PROGRESS_LOG,
    ActivityType.DOCUMENTATION,
    ActivityType.CHANGELOG,
    ActivityType.PROJECT_NOTES,
    ActivityType.TODO_UPDATE,
    ActivityType.CONFIGURATION_DOCS,
    ActivityType.TEST_DATA,
]


class ActivityPlanner:
    """Plans legitimate, verified repository activities across configured repositories."""

    def __init__(
        self,
        repository_manager: RepositoryManager,
        history_manager: Optional[ActivityHistoryManager] = None,
        validator: Optional[ActivityValidator] = None,
        generator: Optional[ActivityGenerator] = None,
        daily_target: int = 5,
    ) -> None:
        """Initialize ActivityPlanner.

        Args:
            repository_manager: Active RepositoryManager instance.
            history_manager: Optional ActivityHistoryManager (creates default if None).
            validator: Optional ActivityValidator (creates default if None).
            generator: Optional ActivityGenerator (creates default if None).
            daily_target: Default number of daily activities to plan.
        """
        self._repo_manager = repository_manager
        self._history = history_manager or ActivityHistoryManager()
        self._validator = validator or ActivityValidator()
        self._generator = generator or ActivityGenerator()
        self._daily_target = max(1, daily_target)

    @property
    def daily_target(self) -> int:
        """Return the configured daily planning target."""
        return self._daily_target

    @property
    def repository_manager(self) -> RepositoryManager:
        """Return the underlying RepositoryManager."""
        return self._repo_manager

    @property
    def history_manager(self) -> ActivityHistoryManager:
        """Return the underlying ActivityHistoryManager."""
        return self._history

    @property
    def validator(self) -> ActivityValidator:
        """Return the ActivityValidator."""
        return self._validator

    @property
    def generator(self) -> ActivityGenerator:
        """Return the ActivityGenerator."""
        return self._generator

    def plan_daily_activities(
        self,
        target_count: Optional[int] = None,
        record_in_history: bool = False,
    ) -> list[ActivityPlan]:
        """Generate and validate a batch of daily activity plans across repositories.

        Args:
            target_count: Optional override for the number of plans to generate.
            record_in_history: Whether to persist generated plans into local history.

        Returns:
            List of validated ActivityPlan instances.
        """
        total_target = max(1, target_count if target_count is not None else self._daily_target)

        # 1. Validate repositories and filter accessible ones
        validated_repos = self._repo_manager.validate_repositories()
        accessible_repos = [r.full_name for r in validated_repos if r.accessible]

        if not accessible_repos:
            return []

        plans: list[ActivityPlan] = []
        repo_count = len(accessible_repos)
        rotation_count = len(STANDARD_ACTIVITY_ROTATION)

        attempt = 0
        max_attempts = total_target * 5  # Allow extra attempts to bypass potential duplicates

        while len(plans) < total_target and attempt < max_attempts:
            # Round-robin selection of repository and activity type
            repo_idx = attempt % repo_count
            type_idx = attempt % rotation_count
            sequence_idx = attempt // repo_count

            target_repo = accessible_repos[repo_idx]
            activity_type = STANDARD_ACTIVITY_ROTATION[type_idx]

            title, description, target_file, proposed_content, reason = (
                self._generator.generate(
                    activity_type=activity_type,
                    repository_name=target_repo,
                    sequence_index=sequence_idx,
                )
            )

            plan = ActivityPlan(
                repository=target_repo,
                activity_type=activity_type,
                target_file=target_file,
                title=title,
                description=description,
                proposed_content=proposed_content,
                reason=reason,
            )

            # Check duplicate against local history
            if self._history.has_content_hash(target_repo, plan.content_hash):
                attempt += 1
                continue

            # Check duplicate against currently planned batch
            if any(
                p.repository == target_repo and p.content_hash == plan.content_hash
                for p in plans
            ):
                attempt += 1
                continue

            # Validate the plan
            val_result = self._validator.validate(plan)
            plan.valid = val_result.valid
            plan.validation_error = val_result.reason

            if plan.valid:
                plans.append(plan)
                if record_in_history:
                    self._history.record_plan(plan, status="PLANNED")

            attempt += 1

        return plans
