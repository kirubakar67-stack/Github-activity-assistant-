"""Legitimate activity content generators for GitHub Activity Assistant.

Generates meaningful, structured, and truthful documentation, progress, changelog,
and note entries with zero artificial punctuation or false technical claims.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from app.activity.models import ActivityType


class ActivityGenerator:
    """Generates structured, legitimate repository update proposals."""

    def __init__(self, base_date: Optional[datetime] = None) -> None:
        """Initialize ActivityGenerator.

        Args:
            base_date: Optional specific datetime (defaults to current UTC datetime).
        """
        self._date = base_date or datetime.now(timezone.utc)
        self._date_str = self._date.strftime("%Y-%m-%d")

    @property
    def date_str(self) -> str:
        """Return the current date string (YYYY-MM-DD)."""
        return self._date_str

    def generate(
        self,
        activity_type: ActivityType,
        repository_name: str,
        sequence_index: int = 0,
        preferred_file: Optional[str] = None,
    ) -> tuple[str, str, str, str, str]:
        """Generate content, metadata, and target file for an activity type.

        Args:
            activity_type: The type of activity to generate.
            repository_name: Target repository ('owner/repo').
            sequence_index: Numeric index to vary template phrasing.
            preferred_file: Optional explicitly requested file path.

        Returns:
            Tuple of (title, description, target_file, proposed_content, reason).
        """
        repo_short = repository_name.split("/")[-1]

        if activity_type == ActivityType.PROGRESS_LOG:
            return self._generate_progress_log(repo_short, sequence_index, preferred_file)
        elif activity_type == ActivityType.DOCUMENTATION:
            return self._generate_documentation(repo_short, sequence_index, preferred_file)
        elif activity_type == ActivityType.CHANGELOG:
            return self._generate_changelog(repo_short, sequence_index, preferred_file)
        elif activity_type == ActivityType.PROJECT_NOTES:
            return self._generate_project_notes(repo_short, sequence_index, preferred_file)
        elif activity_type == ActivityType.TODO_UPDATE:
            return self._generate_todo_update(repo_short, sequence_index, preferred_file)
        elif activity_type == ActivityType.CONFIGURATION_DOCS:
            return self._generate_config_docs(repo_short, sequence_index, preferred_file)
        elif activity_type == ActivityType.TEST_DATA:
            return self._generate_test_data(repo_short, sequence_index, preferred_file)
        elif activity_type == ActivityType.CODE_COMMENTS:
            return self._generate_code_comments(repo_short, sequence_index, preferred_file)
        else:
            return self._generate_documentation(repo_short, sequence_index, preferred_file)

    def _generate_progress_log(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "docs/progress.md"
        title = f"Record development progress for {repo}"
        description = f"Add legitimate daily progress and maintenance log entry for {repo}."
        reason = "Maintain an auditable log of repository inspection and development notes."

        variations = [
            (
                f"## Development Progress — {self._date_str}\n\n"
                "- Conducted routine review of repository components.\n"
                "- Verified project documentation structure and reference alignment.\n"
                "- Recorded project maintenance and workflow observations.\n"
            ),
            (
                f"## Progress Summary — {self._date_str}\n\n"
                "- Inspected component integration and documentation consistency.\n"
                "- Reviewed ongoing milestone tasks and developer checklist.\n"
                "- Recorded routine maintenance update in project records.\n"
            ),
            (
                f"## Development Log Entry — {self._date_str}\n\n"
                "- Reviewed repository codebase architecture and layout.\n"
                "- Ensured documentation reflects current operational state.\n"
                "- Added daily workflow journal verification record.\n"
            ),
        ]
        content = variations[idx % len(variations)]
        return title, description, target_file, content, reason

    def _generate_documentation(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "docs/notes.md"
        title = f"Update documentation notes for {repo}"
        description = f"Enhance developer documentation notes with architecture review details for {repo}."
        reason = "Keep documentation clear, updated, and useful for collaborators."

        variations = [
            (
                f"### Documentation Notes — {self._date_str}\n\n"
                f"**Project**: `{repo}`  \n"
                f"**Review Date**: {self._date_str}  \n\n"
                "**Observations**:\n"
                "- Reviewed structural guidelines and repository setup.\n"
                "- Confirmed module interfaces align with developer documentation.\n"
                "- Updated reference notes for ongoing project maintenance.\n"
            ),
            (
                f"### Repository Maintenance Notes — {self._date_str}\n\n"
                f"**Project**: `{repo}`  \n\n"
                "- Checked documentation links and file structure organization.\n"
                "- Documented environment configuration best practices.\n"
                "- Recorded routine inspection notes for repository onboarding.\n"
            ),
        ]
        content = variations[idx % len(variations)]
        return title, description, target_file, content, reason

    def _generate_changelog(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "CHANGELOG.md"
        title = f"Add changelog entry for {repo}"
        description = f"Record maintenance and documentation changes in {repo} changelog."
        reason = "Maintain a transparent and structured changelog history."

        content = (
            f"### Maintenance [{self._date_str}]\n\n"
            "- **Documentation**: Reviewed and refined developer reference notes.\n"
            "- **Maintenance**: Verified repository configuration and component layout.\n"
            "- **Process**: Recorded daily progress log entry.\n"
        )
        return title, description, target_file, content, reason

    def _generate_project_notes(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "PROJECT_LOG.md"
        title = f"Add project journal entry for {repo}"
        description = f"Record high-level project observations and architectural review in {repo}."
        reason = "Keep an active project journal for engineering reflections."

        content = (
            f"## Engineering Journal — {self._date_str}\n\n"
            f"**Repository**: `{repo}`  \n\n"
            "### Summary of Review\n"
            "- Inspected active modules and configuration consistency.\n"
            "- Verified dependencies and version compatibility requirements.\n"
            "- Added entry to project operational history.\n"
        )
        return title, description, target_file, content, reason

    def _generate_todo_update(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "TODO.md"
        title = f"Update task tracking and TODO notes for {repo}"
        description = f"Review ongoing project roadmap items and record status in {repo}."
        reason = "Maintain clear developer task visibility."

        content = (
            f"### Task Review — {self._date_str}\n\n"
            "- [x] Perform routine repository structure inspection\n"
            "- [x] Verify documentation links and references\n"
            "- [ ] Review upcoming feature milestones\n"
            "- [ ] Update test fixtures and coverage reports\n"
        )
        return title, description, target_file, content, reason

    def _generate_config_docs(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "docs/configuration.md"
        title = f"Document environment configuration for {repo}"
        description = f"Provide configuration details and environment setup guidelines for {repo}."
        reason = "Ensure environment setup is straightforward for new contributors."

        content = (
            f"## Environment Configuration Notes — {self._date_str}\n\n"
            f"**Repository**: `{repo}`  \n\n"
            "- Recommended Python runtime: Python 3.11+\n"
            "- Ensure `.env` is populated with appropriate access credentials.\n"
            "- Validate configuration using project CLI tools before automated runs.\n"
        )
        return title, description, target_file, content, reason

    def _generate_test_data(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "docs/test_scenarios.md"
        title = f"Update test scenario documentation for {repo}"
        description = f"Document test cases and verification scenarios for {repo}."
        reason = "Improve repository test documentation and traceability."

        content = (
            f"## Test Scenarios & Verification Notes — {self._date_str}\n\n"
            f"**Target Repository**: `{repo}`  \n\n"
            "### Scenario Checklist\n"
            "- **Authentication Validation**: Tested invalid/valid token handling.\n"
            "- **Repository Access**: Verified public/private repository inspection.\n"
            "- **Error Handling**: Ensured graceful failure reporting without credential leaks.\n"
        )
        return title, description, target_file, content, reason

    def _generate_code_comments(
        self, repo: str, idx: int, preferred_file: Optional[str]
    ) -> tuple[str, str, str, str, str]:
        target_file = preferred_file or "docs/code_structure.md"
        title = f"Update code structure overview for {repo}"
        description = f"Document architectural component interactions and module layout in {repo}."
        reason = "Clarify repository code structure and responsibilities."

        content = (
            f"## Code Structure Overview — {self._date_str}\n\n"
            f"**Repository**: `{repo}`  \n\n"
            "### Core Modules\n"
            "- `app/config.py`: Configuration loading, validation, and secret masking.\n"
            "- `app/github_client.py`: PyGithub interface with custom error classes.\n"
            "- `app/repository_manager.py`: Multi-repository orchestration and lookup.\n"
        )
        return title, description, target_file, content, reason
