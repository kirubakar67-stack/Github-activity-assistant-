"""Safety validator and secret scanner for proposed repository activity plans."""

from __future__ import annotations

import re
from pathlib import PurePosixPath
from typing import Optional

from app.activity.models import ActivityPlan, ActivityType, ValidationResult

ALLOWED_EXTENSIONS: set[str] = {
    ".md",
    ".txt",
    ".json",
    ".yml",
    ".yaml",
    ".rst",
    ".py",
    ".toml",
}

# Regex patterns for detecting potential secrets and sensitive credentials
SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "GitHub Personal Access Token (Classic)",
        re.compile(r"ghp_[A-Za-z0-9_]{20,}", re.IGNORECASE),
    ),
    (
        "GitHub Fine-grained Personal Access Token",
        re.compile(r"github_pat_[A-Za-z0-9_]{20,}", re.IGNORECASE),
    ),
    (
        "GitHub OAuth/App Token",
        re.compile(r"gh[ousr]_[A-Za-z0-9_]{20,}", re.IGNORECASE),
    ),
    (
        "Private Key Header",
        re.compile(r"-----BEGIN\s+[A-Z\s]+PRIVATE\s+KEY-----", re.IGNORECASE),
    ),
    (
        "Generic Secret or Password Assignment",
        re.compile(
            r"(api[_-]?key|client[_-]?secret|password|secret[_-]?token|auth[_-]?token)\s*[:=]\s*['\"][A-Za-z0-9_./+=]{16,}['\"]",
            re.IGNORECASE,
        ),
    ),
    (
        "Potential JWT Token",
        re.compile(r"eyJ[A-Za-z0-9-_=]{10,}\.[A-Za-z0-9-_=]{10,}\.[A-Za-z0-9-_.+/=]{10,}"),
    ),
]

# Patterns representing meaningless or random changes
MEANINGLESS_STRINGS: set[str] = {
    ".",
    "..",
    "...",
    ":",
    "::",
    ":::",
    "-",
    "--",
    "---",
    "test",
    "update",
    "hello",
    "abc",
    "123",
    "foo",
    "bar",
}


class ActivityValidator:
    """Validates activity plans for legitimacy, structural safety, and secret containment."""

    def __init__(self, blocked_tokens: Optional[list[str]] = None) -> None:
        """Initialize ActivityValidator.

        Args:
            blocked_tokens: Optional list of specific active tokens/secrets to explicitly scan for.
        """
        self._blocked_tokens: list[str] = [
            t.strip() for t in (blocked_tokens or []) if t and len(t.strip()) > 6
        ]

    def scan_for_secrets(self, text: str) -> Optional[str]:
        """Scan text for credentials, tokens, and private keys.

        Args:
            text: Text content to inspect.

        Returns:
            Description of the detected secret if found, or None if clean.
        """
        if not text:
            return None

        # Check explicitly blocked tokens (e.g. current session token)
        for token in self._blocked_tokens:
            if token in text:
                return "Active session token detected in proposed content"

        # Check regex secret patterns
        for name, pattern in SECRET_PATTERNS:
            if pattern.search(text):
                return f"Potential credential detected: {name}"

        return None

    def validate_target_file(self, target_file: str) -> ValidationResult:
        """Validate target file path and extension.

        Args:
            target_file: Relative repository path (e.g., 'docs/progress.md').

        Returns:
            ValidationResult.
        """
        if not target_file or not target_file.strip():
            return ValidationResult.failure("Target file path cannot be empty.")

        cleaned = target_file.strip().replace("\\", "/")
        path = PurePosixPath(cleaned)

        if path.is_absolute():
            return ValidationResult.failure("Target file path must be relative to repository root.")

        if ".." in path.parts:
            return ValidationResult.failure("Target file path cannot contain directory traversal ('..').")

        suffix = path.suffix.lower()
        if not suffix or suffix not in ALLOWED_EXTENSIONS:
            return ValidationResult.failure(
                f"Target file extension '{suffix}' is not allowed. "
                f"Allowed extensions: {sorted(ALLOWED_EXTENSIONS)}"
            )

        return ValidationResult.success()

    def validate_content(self, content: str) -> ValidationResult:
        """Validate that proposed content is meaningful, not purely punctuation, and free of secrets.

        Args:
            content: Proposed text content.

        Returns:
            ValidationResult.
        """
        if not content or not content.strip():
            return ValidationResult.failure("Proposed content cannot be empty or whitespace-only.")

        stripped = content.strip()

        # Reject meaningless single-word or punctuation patterns
        if stripped.lower() in MEANINGLESS_STRINGS:
            return ValidationResult.failure(
                f"Proposed content is meaningless or trivial: '{stripped}'"
            )

        # Ensure content contains sufficient alphanumeric characters
        alnum_count = sum(1 for c in stripped if c.isalnum())
        if alnum_count < 15:
            return ValidationResult.failure(
                "Proposed content contains insufficient descriptive text (fewer than 15 alphanumeric characters)."
            )

        # Check for secrets and sensitive keys
        secret_error = self.scan_for_secrets(stripped)
        if secret_error:
            return ValidationResult.failure(f"Security validation failed: {secret_error}.")

        return ValidationResult.success()

    def validate(self, plan: ActivityPlan) -> ValidationResult:
        """Perform comprehensive validation on an ActivityPlan.

        Args:
            plan: The proposed ActivityPlan.

        Returns:
            ValidationResult indicating whether the plan is safe and legitimate.
        """
        # 1. Validate activity type
        if not isinstance(plan.activity_type, ActivityType):
            try:
                ActivityType.from_string(str(plan.activity_type))
            except ValueError as exc:
                return ValidationResult.failure(str(exc))

        # 2. Validate repository format
        if not plan.repository or "/" not in plan.repository:
            return ValidationResult.failure(
                f"Invalid repository identifier in plan: '{plan.repository}'."
            )

        # 3. Validate target file
        file_result = self.validate_target_file(plan.target_file)
        if not file_result.valid:
            return file_result

        # 4. Validate title and description
        if not plan.title or len(plan.title.strip()) < 5:
            return ValidationResult.failure("Plan title must be at least 5 characters long.")

        if not plan.description or len(plan.description.strip()) < 10:
            return ValidationResult.failure("Plan description must be at least 10 characters long.")

        # 5. Validate proposed content
        content_result = self.validate_content(plan.proposed_content)
        if not content_result.valid:
            return content_result

        return ValidationResult.success()
