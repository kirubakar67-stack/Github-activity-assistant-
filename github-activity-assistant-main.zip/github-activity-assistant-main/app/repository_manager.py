"""Repository Manager module for GitHub Activity Assistant.

Manages multiple GitHub repositories, handles batch accessibility validation,
retrieves repository metadata, and supports repository selection for automation tasks.
"""

from __future__ import annotations

from typing import Optional, Sequence

from github.Repository import Repository

from app.github_client import (
    GitHubClient,
    GitHubClientError,
    GitHubRepositoryError,
    RepositoryInfo,
)


class RepositoryManager:
    """Manages validation, metadata inspection, and selection for configured repositories."""

    def __init__(
        self,
        client: GitHubClient,
        repositories: Sequence[str],
    ) -> None:
        """Initialize RepositoryManager.

        Args:
            client: An authenticated GitHubClient instance.
            repositories: A sequence of repository names in 'owner/repo' format.

        Raises:
            ValueError: If repositories sequence is empty.
        """
        if not repositories:
            raise ValueError("RepositoryManager requires at least one repository.")

        self._client = client
        self._repositories: list[str] = list(repositories)
        self._validated_cache: Optional[list[RepositoryInfo]] = None

    @property
    def client(self) -> GitHubClient:
        """Return the underlying GitHubClient."""
        return self._client

    @property
    def repositories(self) -> list[str]:
        """Return the list of configured repository names."""
        return list(self._repositories)

    def count(self) -> int:
        """Return the number of configured repositories."""
        return len(self._repositories)

    def _resolve_repo_name(self, target: str | int) -> str:
        """Resolve a 1-based index or repository name to a full repository string.

        Args:
            target: Either 1-based integer index or repository name string.

        Returns:
            The resolved repository name in 'owner/repo' format.

        Raises:
            IndexError: If integer index is out of bounds (not in 1..count).
            GitHubRepositoryError: If string name is not in configured repositories.
        """
        if isinstance(target, int):
            if 1 <= target <= len(self._repositories):
                return self._repositories[target - 1]
            raise IndexError(
                f"Repository index {target} is out of range. "
                f"Must be between 1 and {len(self._repositories)}."
            )

        target_str = str(target).strip()
        # Case-insensitive lookup against configured repositories
        for repo in self._repositories:
            if repo.lower() == target_str.lower():
                return repo

        raise GitHubRepositoryError(
            f"Repository '{target}' is not in configured repositories: {self._repositories}"
        )

    def validate_repositories(self, refresh: bool = False) -> list[RepositoryInfo]:
        """Validate accessibility and fetch metadata for all configured repositories.

        Does not raise exceptions on individual repository failures; instead,
        inaccessible repositories will have `accessible=False` and `error_reason` set.

        Args:
            refresh: If True, bypass cache and re-validate against GitHub API.

        Returns:
            List of RepositoryInfo objects for each configured repository.
        """
        if self._validated_cache is not None and not refresh:
            return self._validated_cache

        results: list[RepositoryInfo] = []
        for repo_name in self._repositories:
            try:
                repo_info = self._client.check_repository_access(repo_name)
                results.append(repo_info)
            except GitHubRepositoryError as exc:
                results.append(
                    RepositoryInfo.from_failed_access(
                        repository_name=repo_name,
                        reason=str(exc),
                    )
                )
            except GitHubClientError as exc:
                results.append(
                    RepositoryInfo.from_failed_access(
                        repository_name=repo_name,
                        reason=f"GitHub API Error: {exc}",
                    )
                )
            except Exception as exc:
                results.append(
                    RepositoryInfo.from_failed_access(
                        repository_name=repo_name,
                        reason=f"Unexpected error: {exc}",
                    )
                )

        self._validated_cache = results
        return results

    def get_all_repositories(self) -> list[RepositoryInfo]:
        """Get summary metadata for all repositories (uses cached validation if available).

        Returns:
            List of RepositoryInfo objects.
        """
        return self.validate_repositories()

    def get_repository(self, target: str | int) -> Repository:
        """Fetch the PyGithub Repository instance for a specific repository.

        Args:
            target: 1-based integer index or repository name in 'owner/repo' format.

        Returns:
            PyGithub Repository instance.

        Raises:
            IndexError: If target index is out of bounds.
            GitHubRepositoryError: If repository is inaccessible or not found.
        """
        repo_name = self._resolve_repo_name(target)
        return self._client.get_repository(repo_name)

    def get_repository_info(self, target: str | int) -> RepositoryInfo:
        """Fetch structured metadata for a specific repository.

        Args:
            target: 1-based integer index or repository name in 'owner/repo' format.

        Returns:
            RepositoryInfo instance.

        Raises:
            IndexError: If target index is out of bounds.
            GitHubRepositoryError: If repository is inaccessible.
        """
        repo_name = self._resolve_repo_name(target)
        return self._client.check_repository_access(repo_name)

    def select_repository(self, index: int) -> RepositoryInfo:
        """Select and inspect a repository by its 1-based index.

        Args:
            index: 1-based index (e.g., 1 for the first repository).

        Returns:
            RepositoryInfo for the selected repository.

        Raises:
            IndexError: If index is out of bounds.
        """
        return self.get_repository_info(index)
