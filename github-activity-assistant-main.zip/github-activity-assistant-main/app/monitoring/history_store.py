"""Standardized activity history store for GitHub Activity Assistant.

Provides robust JSON-based history storage, query filtering, and automatic corruption backup.
"""

from __future__ import annotations

import json
import shutil
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

DEFAULT_HISTORY_FILE: Path = Path("data") / "activity_history.json"


@dataclass
class ActivityRecord:
    """Standardized audit record representing a single planned or executed activity."""

    id: str = field(default_factory=lambda: f"activity-{uuid.uuid4().hex[:8]}")
    date: str = field(
        default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d")
    )
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    repository: str = ""
    activity_type: str = "documentation"
    target_file: str = "docs/notes.md"
    title: str = "Activity"
    status: str = "planned"  # 'committed', 'failed', 'dry_run', 'planned'
    commit_hash: Optional[str] = None
    commit_message: Optional[str] = None
    error: Optional[str] = None
    duration: Optional[float] = None
    content_hash: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert record to serializable dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActivityRecord:
        """Instantiate ActivityRecord from raw dictionary with backwards compatibility."""
        record_id = data.get("id") or f"activity-{uuid.uuid4().hex[:8]}"
        date_str = data.get("date") or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        timestamp = (
            data.get("timestamp")
            or data.get("created_at")
            or datetime.now(timezone.utc).isoformat()
        )
        status_val = data.get("status", "planned").lower()
        if "committed:" in status_val:
            parts = status_val.split(":", 1)
            status_val = "committed"
            commit_hash = data.get("commit_hash") or parts[1]
        else:
            commit_hash = data.get("commit_hash")

        return cls(
            id=record_id,
            date=date_str,
            timestamp=timestamp,
            repository=data.get("repository", ""),
            activity_type=data.get("activity_type", "documentation"),
            target_file=data.get("target_file", "docs/notes.md"),
            title=data.get("title", ""),
            status=status_val,
            commit_hash=commit_hash,
            commit_message=data.get("commit_message"),
            error=data.get("error"),
            duration=data.get("duration"),
            content_hash=data.get("content_hash"),
        )


class HistoryStore:
    """Manages reading, querying, and atomic writing of historical activity records."""

    def __init__(self, history_file: Optional[Path | str] = None) -> None:
        """Initialize HistoryStore.

        Args:
            history_file: Custom destination path for history JSON.
        """
        self._history_file = Path(history_file or DEFAULT_HISTORY_FILE)

    @property
    def history_file(self) -> Path:
        """Return the active history file path."""
        return self._history_file

    def _load_records_raw(self) -> list[dict[str, Any]]:
        """Safely load raw records from disk with automatic backup on corruption."""
        if not self._history_file.exists():
            return []
        try:
            with open(self._history_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception:
            # Create backup of corrupted file before resetting
            try:
                bak_file = self._history_file.with_suffix(".json.bak")
                shutil.copyfile(self._history_file, bak_file)
            except Exception:
                pass
            return []

    def _save_records_raw(self, records: list[dict[str, Any]]) -> None:
        """Atomically persist records list to JSON file."""
        self._history_file.parent.mkdir(parents=True, exist_ok=True)
        tmp_file = self._history_file.with_suffix(".tmp")
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2)
        tmp_file.replace(self._history_file)

    def add_record(self, record: ActivityRecord) -> None:
        """Append an ActivityRecord to the history store.

        Args:
            record: Standardized ActivityRecord to add.
        """
        raw_list = self._load_records_raw()
        raw_list.append(record.to_dict())
        self._save_records_raw(raw_list)

    def get_records(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        repository: Optional[str] = None,
        activity_type: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[ActivityRecord]:
        """Query and filter historical activity records.

        Args:
            from_date: Inclusive start date (YYYY-MM-DD).
            to_date: Inclusive end date (YYYY-MM-DD).
            repository: Case-insensitive repository filter.
            activity_type: Activity type filter.
            status: Status filter ('committed', 'failed', etc.).
            limit: Maximum number of records to return.

        Returns:
            List of matching ActivityRecord objects.
        """
        raw_list = self._load_records_raw()
        records: list[ActivityRecord] = [ActivityRecord.from_dict(d) for d in raw_list]

        if from_date:
            records = [r for r in records if r.date >= from_date]
        if to_date:
            records = [r for r in records if r.date <= to_date]
        if repository:
            repo_lower = repository.strip().lower()
            records = [r for r in records if r.repository.lower() == repo_lower]
        if activity_type:
            type_lower = activity_type.strip().lower()
            records = [r for r in records if r.activity_type.lower() == type_lower]
        if status:
            status_lower = status.strip().lower()
            records = [r for r in records if r.status.lower() == status_lower]

        if limit is not None and limit > 0:
            records = records[-limit:]

        return records

    def get_recent_activities(self, limit: int = 10) -> list[ActivityRecord]:
        """Retrieve most recent activity records sorted newest first."""
        records = self.get_records()
        records.sort(key=lambda r: r.timestamp or r.date, reverse=True)
        return records[:limit]

    def get_recent_failures(self, limit: int = 10) -> list[ActivityRecord]:
        """Retrieve most recent failed activity records sorted newest first."""
        records = self.get_records(status="failed")
        records.sort(key=lambda r: r.timestamp or r.date, reverse=True)
        return records[:limit]

    def has_content_hash(self, repository: str, content_hash: str) -> bool:
        """Check whether matching content_hash exists for repository."""
        if not content_hash:
            return False
        repo_lower = repository.strip().lower()
        records = self.get_records()
        for r in records:
            if r.repository.lower() == repo_lower and r.content_hash == content_hash:
                return True
        return False

    def count_activities_for_date(
        self, repository: str, date_str: Optional[str] = None
    ) -> int:
        """Count activities recorded for repository on date."""
        target_date = date_str or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        records = self.get_records(from_date=target_date, to_date=target_date, repository=repository)
        return len(records)

    def clear(self) -> None:
        """Delete local history file."""
        if self._history_file.exists():
            self._history_file.unlink()
