"""Report generation module for exporting JSON and CSV activity audit reports."""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from app.monitoring.history_store import HistoryStore
from app.monitoring.statistics import StatisticsEngine

DEFAULT_REPORTS_DIR: Path = Path("reports")


class ReportGenerator:
    """Exports structured audit reports in JSON and CSV formats."""

    def __init__(
        self,
        history_store: Optional[HistoryStore] = None,
        stats_engine: Optional[StatisticsEngine] = None,
        default_output_dir: Optional[Path | str] = None,
    ) -> None:
        """Initialize ReportGenerator.

        Args:
            history_store: Optional HistoryStore.
            stats_engine: Optional StatisticsEngine.
            default_output_dir: Destination directory for reports.
        """
        self._store = history_store or HistoryStore()
        self._stats = stats_engine or StatisticsEngine(self._store)
        self._output_dir = Path(default_output_dir or DEFAULT_REPORTS_DIR)

    @property
    def output_dir(self) -> Path:
        """Return destination reports directory."""
        return self._output_dir

    def _determine_filename(
        self, prefix: str, ext: str, from_date: Optional[str], to_date: Optional[str]
    ) -> str:
        """Construct a descriptive report filename based on date range."""
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if from_date and to_date and from_date != to_date:
            return f"{prefix}_{from_date}_to_{to_date}.{ext}"
        target = from_date or to_date or today
        return f"{prefix}_{target}.{ext}"

    def export_json(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        output_dir: Optional[Path | str] = None,
    ) -> Path:
        """Export comprehensive JSON audit report.

        Args:
            from_date: Optional start date filter (YYYY-MM-DD).
            to_date: Optional end date filter (YYYY-MM-DD).
            output_dir: Optional custom destination folder.

        Returns:
            Path of the generated JSON file.
        """
        target_dir = Path(output_dir or self._output_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        filename = self._determine_filename("report", "json", from_date, to_date)
        file_path = target_dir / filename

        stats = self._stats.get_summary_statistics(from_date=from_date, to_date=to_date)
        records = self._store.get_records(from_date=from_date, to_date=to_date)

        report_data = {
            "report_metadata": {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "from_date": from_date,
                "to_date": to_date,
                "total_records": len(records),
            },
            "statistics_summary": stats,
            "activity_records": [r.to_dict() for r in records],
        }

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(report_data, f, indent=2)

        return file_path

    def export_csv(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        output_dir: Optional[Path | str] = None,
    ) -> Path:
        """Export standardized CSV activity records report.

        Args:
            from_date: Optional start date filter (YYYY-MM-DD).
            to_date: Optional end date filter (YYYY-MM-DD).
            output_dir: Optional custom destination folder.

        Returns:
            Path of the generated CSV file.
        """
        target_dir = Path(output_dir or self._output_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        filename = self._determine_filename("activity_report", "csv", from_date, to_date)
        file_path = target_dir / filename

        records = self._store.get_records(from_date=from_date, to_date=to_date)

        fieldnames = [
            "id",
            "date",
            "timestamp",
            "repository",
            "activity_type",
            "target_file",
            "title",
            "status",
            "commit_hash",
            "commit_message",
            "duration",
            "error",
        ]

        with open(file_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in records:
                row = r.to_dict()
                row.pop("content_hash", None)
                writer.writerow(row)

        return file_path
