"""Statistics calculation engine for GitHub Activity Assistant.

Aggregates real recorded history to produce daily progress, repository metrics,
activity type distributions, success rates, and calendar data.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from zoneinfo import ZoneInfo

from app.monitoring.history_store import ActivityRecord, HistoryStore


class StatisticsEngine:
    """Computes comprehensive metrics and analytical views from HistoryStore records."""

    def __init__(self, history_store: Optional[HistoryStore] = None) -> None:
        """Initialize StatisticsEngine with history store."""
        self._store = history_store or HistoryStore()

    @property
    def history_store(self) -> HistoryStore:
        """Return underlying HistoryStore."""
        return self._store

    def _is_successful(self, record: ActivityRecord) -> bool:
        """Determine if a record represents a successful commit."""
        status = record.status.lower()
        return "committed" in status or status == "success" or record.commit_hash is not None

    def _is_failed(self, record: ActivityRecord) -> bool:
        """Determine if a record represents a failed execution."""
        return record.status.lower() == "failed"

    def get_daily_progress(
        self,
        date_str: Optional[str] = None,
        target: int = 5,
    ) -> dict[str, Any]:
        """Calculate progress metrics for a single date.

        Args:
            date_str: Date string (YYYY-MM-DD), defaults to today UTC.
            target: Daily activity planning target.

        Returns:
            Dictionary with target, completed, failed, remaining, and progress_percent.
        """
        target_date = date_str or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        records = self._store.get_records(from_date=target_date, to_date=target_date)

        completed = sum(1 for r in records if self._is_successful(r))
        failed = sum(1 for r in records if self._is_failed(r))
        remaining = max(0, target - completed)
        progress_pct = (
            min(100.0, round((completed / target) * 100.0, 1)) if target > 0 else 0.0
        )

        return {
            "date": target_date,
            "target": target,
            "completed": completed,
            "failed": failed,
            "remaining": remaining,
            "progress_percent": progress_pct,
            "total_recorded_today": len(records),
        }

    def get_summary_statistics(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
    ) -> dict[str, Any]:
        """Calculate aggregated statistics for a given date range.

        Args:
            from_date: Optional inclusive start date (YYYY-MM-DD).
            to_date: Optional inclusive end date (YYYY-MM-DD).

        Returns:
            Dictionary with overall metrics, repo breakdown, activity type distribution, etc.
        """
        records = self._store.get_records(from_date=from_date, to_date=to_date)
        total = len(records)

        successful = sum(1 for r in records if self._is_successful(r))
        failed = sum(1 for r in records if self._is_failed(r))
        attempted = successful + failed

        success_rate = (
            round((successful / attempted) * 100.0, 2) if attempted > 0 else 0.0
        )

        # Repository breakdown
        repo_counts: dict[str, dict[str, Any]] = {}
        for r in records:
            repo = r.repository or "Unknown"
            if repo not in repo_counts:
                repo_counts[repo] = {"total": 0, "successful": 0, "failed": 0}
            repo_counts[repo]["total"] += 1
            if self._is_successful(r):
                repo_counts[repo]["successful"] += 1
            elif self._is_failed(r):
                repo_counts[repo]["failed"] += 1

        for repo, stats in repo_counts.items():
            repo_attempted = stats["successful"] + stats["failed"]
            stats["success_rate"] = (
                round((stats["successful"] / repo_attempted) * 100.0, 1)
                if repo_attempted > 0
                else 0.0
            )

        most_active_repo = (
            max(repo_counts.keys(), key=lambda k: repo_counts[k]["total"])
            if repo_counts
            else "None"
        )

        # Activity type breakdown
        type_counts: dict[str, dict[str, Any]] = {}
        for r in records:
            act_type = r.activity_type.replace("_", " ").title()
            if act_type not in type_counts:
                type_counts[act_type] = {"count": 0, "percentage": 0.0}
            type_counts[act_type]["count"] += 1

        for act_type, stats in type_counts.items():
            stats["percentage"] = (
                round((stats["count"] / total) * 100.0, 1) if total > 0 else 0.0
            )

        most_common_type = (
            max(type_counts.keys(), key=lambda k: type_counts[k]["count"])
            if type_counts
            else "None"
        )

        # Duration averages
        durations = [r.duration for r in records if r.duration is not None and r.duration > 0]
        avg_duration = round(sum(durations) / len(durations), 2) if durations else 0.0

        return {
            "from_date": from_date,
            "to_date": to_date,
            "total_activities": total,
            "successful_activities": successful,
            "failed_activities": failed,
            "success_rate": success_rate,
            "repository_breakdown": repo_counts,
            "most_active_repository": most_active_repo,
            "activity_type_breakdown": type_counts,
            "most_common_activity_type": most_common_type,
            "average_duration_seconds": avg_duration,
        }

    def get_calendar_data(
        self,
        weeks: int = 4,
        end_date_str: Optional[str] = None,
        timezone_name: str = "UTC",
    ) -> list[dict[str, Any]]:
        """Generate grid data for application activity calendar view.

        Args:
            weeks: Number of weeks to include (default: 4).
            end_date_str: Reference end date (defaults to today).
            timezone_name: Local timezone name.

        Returns:
            List of day dicts with date, weekday, activity_count, has_activity.
        """
        try:
            tz = ZoneInfo(timezone_name)
        except Exception:
            tz = ZoneInfo("UTC")

        if end_date_str:
            end_dt = datetime.strptime(end_date_str, "%Y-%m-%d").replace(tzinfo=tz)
        else:
            end_dt = datetime.now(tz)

        # Compute calendar bounds aligning to full weeks (Monday to Sunday)
        # End on the Sunday of the current week (or today if aligned)
        days_ahead_to_sunday = (6 - end_dt.weekday()) % 7
        calendar_end = end_dt + timedelta(days=days_ahead_to_sunday)
        total_days = weeks * 7
        calendar_start = calendar_end - timedelta(days=total_days - 1)

        start_str = calendar_start.strftime("%Y-%m-%d")
        end_str = calendar_end.strftime("%Y-%m-%d")

        records = self._store.get_records(from_date=start_str, to_date=end_str)
        date_counts: dict[str, int] = {}
        for r in records:
            if self._is_successful(r):
                date_counts[r.date] = date_counts.get(r.date, 0) + 1

        days_data: list[dict[str, Any]] = []
        cur = calendar_start
        while cur <= calendar_end:
            cur_str = cur.strftime("%Y-%m-%d")
            count = date_counts.get(cur_str, 0)
            days_data.append({
                "date": cur_str,
                "weekday": cur.weekday(),  # 0 = Monday, 6 = Sunday
                "day_number": cur.day,
                "activity_count": count,
                "has_activity": count > 0,
                "is_future": cur.date() > end_dt.date(),
            })
            cur += timedelta(days=1)

        return days_data
