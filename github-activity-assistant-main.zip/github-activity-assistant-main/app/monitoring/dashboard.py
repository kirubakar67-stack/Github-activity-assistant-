"""Terminal dashboard rendering engine for GitHub Activity Assistant.

Renders high-level summaries, progress bars, repository breakdowns, recent logs,
and an application activity calendar view with optional live watch mode.
"""

from __future__ import annotations

import os
import time
from datetime import datetime
from typing import Callable, Optional
from zoneinfo import ZoneInfo

from app.monitoring.history_store import HistoryStore
from app.monitoring.statistics import StatisticsEngine
from app.scheduler.state import SchedulerStatus, SchedulerStateManager


class TerminalDashboard:
    """Renders formatted terminal monitoring views and live auto-refresh dashboard."""

    def __init__(
        self,
        history_store: Optional[HistoryStore] = None,
        stats_engine: Optional[StatisticsEngine] = None,
        state_manager: Optional[SchedulerStateManager] = None,
        timezone_name: str = "Asia/Kolkata",
        daily_target: int = 5,
        sleep_func: Optional[Callable[[float], None]] = None,
    ) -> None:
        """Initialize TerminalDashboard.

        Args:
            history_store: Optional HistoryStore.
            stats_engine: Optional StatisticsEngine.
            state_manager: Optional SchedulerStateManager.
            timezone_name: Configured local timezone.
            daily_target: Configured daily target.
            sleep_func: Sleep function for watch mode.
        """
        self._store = history_store or HistoryStore()
        self._stats = stats_engine or StatisticsEngine(self._store)
        self._state_mgr = state_manager or SchedulerStateManager()
        self._tz_name = timezone_name
        self._target = daily_target
        self._sleep = sleep_func or time.sleep

    def _render_progress_bar(self, percent: float, width: int = 20) -> str:
        """Render a text-based progress bar."""
        filled_length = int(round(width * (percent / 100.0)))
        filled_length = max(0, min(width, filled_length))
        bar = "#" * filled_length + "-" * (width - filled_length)
        return f"[{bar}] {percent:.1f}%"

    def _render_calendar_view(self, weeks: int = 4) -> list[str]:
        """Render ASCII/text calendar grid for the last N weeks."""
        days = self._stats.get_calendar_data(weeks=weeks, timezone_name=self._tz_name)
        lines = [
            "Mon  Tue  Wed  Thu  Fri  Sat  Sun",
            "---------------------------------",
        ]

        row: list[str] = []
        for d in days:
            if d.get("is_future"):
                symbol = " . "
            elif d.get("has_activity"):
                symbol = " * "
            else:
                symbol = " - "
            row.append(symbol)

            if len(row) == 7:
                lines.append(" ".join(row))
                row = []

        if row:
            lines.append(" ".join(row))

        lines.append("Legend: * = Activity recorded | - = No activity | . = Future")
        return lines


    def render(self) -> str:
        """Generate formatted dashboard string.

        Returns:
            Complete multi-line terminal dashboard text.
        """
        try:
            tz = ZoneInfo(self._tz_name)
        except Exception:
            tz = ZoneInfo("UTC")

        today_str = datetime.now(tz).strftime("%Y-%m-%d")
        now_time = datetime.now(tz).strftime("%H:%M:%S")

        state = self._state_mgr.load_state()
        scheduler_status = state.status.value if state else SchedulerStatus.IDLE.value

        progress = self._stats.get_daily_progress(date_str=today_str, target=self._target)
        summary = self._stats.get_summary_statistics()

        lines: list[str] = []
        lines.append("======================================================================")
        lines.append("               GITHUB ACTIVITY ASSISTANT -- DASHBOARD                 ")
        lines.append("======================================================================")

        lines.append(f"Date: {today_str} ({self._tz_name})  |  Time: {now_time}  |  Scheduler: {scheduler_status}")
        lines.append("----------------------------------------------------------------------")

        # Section 1: TODAY'S PROGRESS
        lines.append("TODAY'S PROGRESS")
        lines.append("----------------------------------------------------------------------")
        lines.append(f"Target       : {progress['target']}")
        lines.append(f"Completed    : {progress['completed']}")
        lines.append(f"Failed       : {progress['failed']}")
        lines.append(f"Remaining    : {progress['remaining']}")
        lines.append(f"Progress     : {self._render_progress_bar(progress['progress_percent'])}")
        lines.append("")

        # Section 2: REPOSITORY DISTRIBUTION
        lines.append("REPOSITORY DISTRIBUTION")
        lines.append("----------------------------------------------------------------------")
        repo_breakdown = summary.get("repository_breakdown", {})
        if repo_breakdown:
            for repo, stats in repo_breakdown.items():
                repo_short = repo.split("/")[-1] if "/" in repo else repo
                lines.append(
                    f"{repo_short:<30} {stats['total']:>3} activities  ({stats['success_rate']:>5.1f}% success)"
                )
        else:
            lines.append("No repository activities recorded yet.")
        lines.append("")

        # Section 3: ACTIVITY TYPES
        lines.append("ACTIVITY TYPES")
        lines.append("----------------------------------------------------------------------")
        type_breakdown = summary.get("activity_type_breakdown", {})
        if type_breakdown:
            for act_type, stats in type_breakdown.items():
                lines.append(f"{act_type:<24} {stats['count']:>3}  ({stats['percentage']:>5.1f}%)")
        else:
            lines.append("No activity types recorded yet.")
        lines.append("")

        # Section 4: RECENT ACTIVITIES
        lines.append("RECENT ACTIVITIES")
        lines.append("----------------------------------------------------------------------")
        recent = self._store.get_recent_activities(limit=5)
        if recent:
            for r in recent:
                timestamp_str = r.timestamp[11:16] if r.timestamp and len(r.timestamp) >= 16 else "--:--"
                repo_short = r.repository.split("/")[-1] if "/" in r.repository else (r.repository or "unknown")
                c_hash = f"[{r.commit_hash[:7]}]" if r.commit_hash else "[DRY_RUN]"
                status_tag = r.status.upper()
                msg = (r.commit_message or r.title or "")[:35]
                lines.append(f"{timestamp_str}  {repo_short:<18}  {msg:<35} {status_tag} {c_hash}")
        else:
            lines.append("No recent activities recorded.")
        lines.append("")

        # Section 5: RECENT ERRORS
        recent_failures = self._store.get_recent_failures(limit=3)
        if recent_failures:
            lines.append("RECENT FAILURES")
            lines.append("----------------------------------------------------------------------")
            for f in recent_failures:
                repo_short = f.repository.split("/")[-1] if "/" in f.repository else f.repository
                err_msg = (f.error or "Unknown failure")[:60]
                lines.append(f"* {f.date} ({repo_short}): {err_msg}")

            lines.append("")

        # Section 6: CALENDAR VIEW
        lines.append("APPLICATION ACTIVITY CALENDAR (Last 4 Weeks)")
        lines.append("----------------------------------------------------------------------")
        lines.extend(self._render_calendar_view(weeks=4))
        lines.append("======================================================================")

        return "\n".join(lines)

    def display(self) -> None:
        """Print the rendered dashboard to standard output."""
        print(self.render())

    def render_live(
        self,
        refresh_seconds: int = 5,
        max_ticks: Optional[int] = None,
    ) -> None:
        """Start live auto-refresh dashboard loop.

        Args:
            refresh_seconds: Interval in seconds between screen refreshes.
            max_ticks: Optional maximum number of refresh iterations.
        """
        ticks = 0
        try:
            while True:
                if max_ticks is not None and ticks >= max_ticks:
                    break

                # Clear console screen across Windows and Unix
                os.system("cls" if os.name == "nt" else "clear")
                self.display()
                print(f"\n[Live Mode] Auto-refreshing every {refresh_seconds}s. Press Ctrl+C to exit.")

                self._sleep(refresh_seconds)
                ticks += 1
        except KeyboardInterrupt:
            print("\nExited dashboard watch mode.")
