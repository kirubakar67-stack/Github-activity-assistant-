"""Monitoring, dashboard, and reporting package for GitHub Activity Assistant."""

from app.monitoring.dashboard import TerminalDashboard
from app.monitoring.history_store import ActivityRecord, HistoryStore
from app.monitoring.reports import ReportGenerator
from app.monitoring.statistics import StatisticsEngine

__all__ = [
    "ActivityRecord",
    "HistoryStore",
    "ReportGenerator",
    "StatisticsEngine",
    "TerminalDashboard",
]
