"""Configuration management module for GitHub Activity Assistant.

Handles loading, validation, duplicate detection, and sanitization of environment
variables from .env or system environment for multi-repository operations, scheduling,
and monitoring dashboards.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from dotenv import load_dotenv

# Regular expression validating standard GitHub 'owner/repository' format
REPO_PATTERN: re.Pattern[str] = re.compile(
    r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"
)

# Regular expression validating 24-hour HH:MM format
TIME_PATTERN: re.Pattern[str] = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")

DEFAULT_DAILY_ACTIVITY_TARGET: int = 5
MIN_DAILY_ACTIVITY_TARGET: int = 1
MAX_DAILY_ACTIVITY_TARGET: int = 20
DEFAULT_LOCAL_REPOSITORY_PATH: str = "./repositories"
DEFAULT_SCHEDULE_TIME: str = "18:00"
DEFAULT_TIMEZONE: str = "Asia/Kolkata"
DEFAULT_MIN_ACTIVITY_INTERVAL_MINUTES: int = 5
DEFAULT_DASHBOARD_REFRESH_SECONDS: int = 5
DEFAULT_REPORT_DIRECTORY: str = "./reports"


class ConfigError(Exception):
    """Raised when configuration values are missing, invalid, or malformed."""


@dataclass(frozen=True)
class AppConfig:
    """Application configuration container.

    Attributes:
        github_token: Personal access token used for GitHub API authentication.
        github_repository: Primary target repository in 'owner/repository' format.
        github_repositories: Tuple of all configured target repositories.
        daily_activity_target: Number of daily planned activities (1 to 20).
        local_repository_path: Base directory where local repositories are cloned.
        schedule_time: Configured daily execution time in 24-hr 'HH:MM' format.
        timezone: Valid IANA timezone name (e.g. 'Asia/Kolkata', 'UTC').
        scheduler_enabled: Whether daily automated scheduling is active.
        min_activity_interval_minutes: Minutes to wait between individual daily activities.
        dashboard_refresh_seconds: Refresh interval for live dashboard watch mode.
        report_directory: Destination directory for exported JSON/CSV reports.
    """

    github_token: str
    github_repository: str
    github_repositories: tuple[str, ...] = field(default_factory=tuple)
    daily_activity_target: int = DEFAULT_DAILY_ACTIVITY_TARGET
    local_repository_path: Path = field(
        default_factory=lambda: Path(DEFAULT_LOCAL_REPOSITORY_PATH)
    )
    schedule_time: str = DEFAULT_SCHEDULE_TIME
    timezone: str = DEFAULT_TIMEZONE
    scheduler_enabled: bool = False
    min_activity_interval_minutes: int = DEFAULT_MIN_ACTIVITY_INTERVAL_MINUTES
    dashboard_refresh_seconds: int = DEFAULT_DASHBOARD_REFRESH_SECONDS
    report_directory: Path = field(
        default_factory=lambda: Path(DEFAULT_REPORT_DIRECTORY)
    )

    def __post_init__(self) -> None:
        """Ensure github_repositories contains at least github_repository."""
        if not self.github_repositories and self.github_repository:
            object.__setattr__(self, "github_repositories", (self.github_repository,))

    @property
    def owner(self) -> str:
        """Extract the owner/organization portion of the primary repository."""
        return self.github_repository.split("/", 1)[0]

    @property
    def repo_name(self) -> str:
        """Extract the repository name portion of the primary repository."""
        return self.github_repository.split("/", 1)[1]

    def __repr__(self) -> str:
        """Mask the sensitive token to prevent accidental credential leakage in logs."""
        masked_token = (
            f"{self.github_token[:4]}...{self.github_token[-4:]}"
            if len(self.github_token) > 8
            else "***"
        )
        return (
            f"AppConfig(github_token='{masked_token}', "
            f"github_repository='{self.github_repository}', "
            f"github_repositories={self.github_repositories}, "
            f"daily_activity_target={self.daily_activity_target}, "
            f"local_repository_path={self.local_repository_path}, "
            f"schedule_time='{self.schedule_time}', "
            f"timezone='{self.timezone}', "
            f"scheduler_enabled={self.scheduler_enabled}, "
            f"min_activity_interval_minutes={self.min_activity_interval_minutes}, "
            f"dashboard_refresh_seconds={self.dashboard_refresh_seconds}, "
            f"report_directory={self.report_directory})"
        )


def validate_repository_name(repository: str) -> bool:
    """Check if repository string adheres to 'owner/repository' format.

    Args:
        repository: Repository identifier string.

    Returns:
        True if valid, False otherwise.
    """
    if not repository or not isinstance(repository, str):
        return False
    return bool(REPO_PATTERN.match(repository.strip()))


def parse_boolean(val: Optional[str], default: bool = False) -> bool:
    """Parse boolean from string representation."""
    if val is None:
        return default
    normalized = val.strip().lower()
    if normalized in {"true", "1", "yes", "y", "on", "enable", "enabled"}:
        return True
    if normalized in {"false", "0", "no", "n", "off", "disable", "disabled"}:
        return False
    raise ConfigError(f"Invalid boolean value: '{val}'. Expected 'true' or 'false'.")


def load_config(
    env_path: Optional[str | Path] = None,
    load_env_file: bool = True,
) -> AppConfig:
    """Load and validate configuration from environment variables or .env file.

    Args:
        env_path: Optional specific path to a .env file.
        load_env_file: If True, load environment variables from the .env file.

    Returns:
        A validated AppConfig instance.

    Raises:
        ConfigError: If configuration values are missing, invalid, or out of bounds.
    """
    if load_env_file:
        if env_path is not None:
            load_dotenv(dotenv_path=Path(env_path), override=True)
        else:
            load_dotenv(override=False)

    token = os.getenv("GITHUB_TOKEN")
    if not token or not token.strip():
        raise ConfigError(
            "Missing 'GITHUB_TOKEN' environment variable.\n"
            "Please create a .env file (see .env.example) and set GITHUB_TOKEN "
            "with a valid GitHub Personal Access Token."
        )

    raw_repositories = os.getenv("GITHUB_REPOSITORIES") or os.getenv("GITHUB_REPOSITORY")
    if not raw_repositories or not raw_repositories.strip():
        raise ConfigError(
            "Missing repository configuration.\n"
            "Please configure GITHUB_REPOSITORIES in your .env file in the format:\n"
            "GITHUB_REPOSITORIES=owner/repo1,owner/repo2,owner/repo3,owner/repo4"
        )

    token = token.strip()
    raw_entries = [r.strip() for r in raw_repositories.split(",") if r.strip()]
    if not raw_entries:
        raise ConfigError(
            "No valid repositories found in GITHUB_REPOSITORIES.\n"
            "Please provide at least one valid repository in 'owner/repository' format."
        )

    validated_repos: list[str] = []
    seen_lower: set[str] = set()

    for repo in raw_entries:
        if not validate_repository_name(repo):
            raise ConfigError(
                f"Invalid repository format: '{repo}'.\n"
                "Expected 'owner/repository' format containing only alphanumeric characters, "
                "hyphens, underscores, or dots (e.g., 'octocat/Hello-World')."
            )

        repo_lower = repo.lower()
        if repo_lower in seen_lower:
            raise ConfigError(
                f"Duplicate repository detected: '{repo}'.\n"
                "Please ensure each repository is configured only once in GITHUB_REPOSITORIES."
            )

        seen_lower.add(repo_lower)
        validated_repos.append(repo)

    # Parse DAILY_ACTIVITY_TARGET
    raw_target = os.getenv("DAILY_ACTIVITY_TARGET", str(DEFAULT_DAILY_ACTIVITY_TARGET)).strip()
    try:
        daily_target = int(raw_target)
        if not (MIN_DAILY_ACTIVITY_TARGET <= daily_target <= MAX_DAILY_ACTIVITY_TARGET):
            raise ConfigError(
                f"Invalid DAILY_ACTIVITY_TARGET: {daily_target}. "
                f"Must be an integer between {MIN_DAILY_ACTIVITY_TARGET} and {MAX_DAILY_ACTIVITY_TARGET}."
            )
    except ValueError:
        raise ConfigError(
            f"Invalid DAILY_ACTIVITY_TARGET: '{raw_target}'. Expected an integer value."
        )

    # Parse LOCAL_REPOSITORY_PATH
    raw_local_path = os.getenv("LOCAL_REPOSITORY_PATH", DEFAULT_LOCAL_REPOSITORY_PATH).strip()
    local_path = Path(raw_local_path)

    # Parse and validate SCHEDULE_TIME
    schedule_time = os.getenv("SCHEDULE_TIME", DEFAULT_SCHEDULE_TIME).strip()
    if not TIME_PATTERN.match(schedule_time):
        raise ConfigError(
            f"Invalid SCHEDULE_TIME: '{schedule_time}'. Expected 24-hour 'HH:MM' format (e.g., '18:00')."
        )

    # Parse and validate TIMEZONE
    timezone_name = os.getenv("TIMEZONE", DEFAULT_TIMEZONE).strip()
    try:
        ZoneInfo(timezone_name)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise ConfigError(
            f"Invalid TIMEZONE: '{timezone_name}'. Must be a valid IANA timezone (e.g. 'Asia/Kolkata', 'UTC', 'America/New_York')."
        ) from exc

    # Parse SCHEDULER_ENABLED
    scheduler_enabled = parse_boolean(os.getenv("SCHEDULER_ENABLED"), default=False)

    # Parse MIN_ACTIVITY_INTERVAL_MINUTES
    raw_interval = os.getenv(
        "MIN_ACTIVITY_INTERVAL_MINUTES", str(DEFAULT_MIN_ACTIVITY_INTERVAL_MINUTES)
    ).strip()
    try:
        min_interval = int(raw_interval)
        if min_interval < 0 or min_interval > 1440:
            raise ConfigError(
                f"Invalid MIN_ACTIVITY_INTERVAL_MINUTES: {min_interval}. Must be between 0 and 1440."
            )
    except ValueError:
        raise ConfigError(
            f"Invalid MIN_ACTIVITY_INTERVAL_MINUTES: '{raw_interval}'. Expected an integer value."
        )

    # Parse DASHBOARD_REFRESH_SECONDS
    raw_refresh = os.getenv(
        "DASHBOARD_REFRESH_SECONDS", str(DEFAULT_DASHBOARD_REFRESH_SECONDS)
    ).strip()
    try:
        dashboard_refresh = int(raw_refresh)
        if not (1 <= dashboard_refresh <= 60):
            raise ConfigError(
                f"Invalid DASHBOARD_REFRESH_SECONDS: {dashboard_refresh}. Must be between 1 and 60."
            )
    except ValueError:
        raise ConfigError(
            f"Invalid DASHBOARD_REFRESH_SECONDS: '{raw_refresh}'. Expected an integer value."
        )

    # Parse REPORT_DIRECTORY
    raw_report_dir = os.getenv("REPORT_DIRECTORY", DEFAULT_REPORT_DIRECTORY).strip()
    report_directory = Path(raw_report_dir)

    return AppConfig(
        github_token=token,
        github_repository=validated_repos[0],
        github_repositories=tuple(validated_repos),
        daily_activity_target=daily_target,
        local_repository_path=local_path,
        schedule_time=schedule_time,
        timezone=timezone_name,
        scheduler_enabled=scheduler_enabled,
        min_activity_interval_minutes=min_interval,
        dashboard_refresh_seconds=dashboard_refresh,
        report_directory=report_directory,
    )
