"""GitHub API Client module for GitHub Activity Assistant.

Provides a robust, typed interface around PyGithub to authenticate, validate credentials,
and inspect repository metadata without modifying any repository content.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from github import (
    Auth,
    BadCredentialsException,
    Github,
    GithubException,
    RateLimitExceededException,
    UnknownObjectException,
)
from github.AuthenticatedUser import AuthenticatedUser
from github.Repository import Repository


class GitHubClientError(Exception):
    """Base exception for all GitHub client errors."""


class GitHubAuthError(GitHubClientError):
    """Raised when authentication with GitHub fails (e.g., bad or revoked token)."""


class GitHubRepositoryError(GitHubClientError):
    """Raised when target repository is not found or inaccessible."""


class GitHubRateLimitError(GitHubClientError):
    """Raised when GitHub API rate limit is reached."""


@dataclass(frozen=True)
class UserInfo:
    """Encapsulates authenticated GitHub user details."""

    login: str
    name: Optional[str]
    email: Optional[str]
    html_url: str
    user_type: str

    @classmethod
    def from_github_user(cls, user: AuthenticatedUser) -> UserInfo:
        """Create a UserInfo instance from a PyGithub AuthenticatedUser."""
        return cls(
            login=user.login,
            name=user.name,
            email=user.email,
            html_url=user.html_url,
            user_type=user.type or "User",
        )


@dataclass(frozen=True)
class RepositoryInfo:
    """Encapsulates target GitHub repository metadata."""

    name: str
    full_name: str
    owner: str
    visibility: str
    default_branch: str
    description: Optional[str] = None
    html_url: str = ""
    is_private: bool = False
    can_push: bool = False
    accessible: bool = True
    error_reason: Optional[str] = None

    @classmethod
    def from_github_repo(cls, repo: Repository) -> RepositoryInfo:
        """Create a RepositoryInfo instance from a PyGithub Repository."""
        visibility = "private" if repo.private else "public"

        # Check permissions if available
        can_push = False
        if hasattr(repo, "permissions") and repo.permissions is not None:
            can_push = bool(getattr(repo.permissions, "push", False))

        return cls(
            name=repo.name,
            full_name=repo.full_name,
            owner=repo.owner.login if repo.owner else "",
            visibility=visibility,
            default_branch=repo.default_branch or "main",
            description=repo.description,
            html_url=repo.html_url or f"https://github.com/{repo.full_name}",
            is_private=repo.private,
            can_push=can_push,
            accessible=True,
            error_reason=None,
        )

    @classmethod
    def from_failed_access(cls, repository_name: str, reason: str) -> RepositoryInfo:
        """Create an inaccessible RepositoryInfo placeholder for failed validations."""
        parts = repository_name.split("/", 1)
        owner = parts[0] if len(parts) > 1 else ""
        name = parts[1] if len(parts) > 1 else repository_name

        return cls(
            name=name,
            full_name=repository_name,
            owner=owner,
            visibility="unknown",
            default_branch="unknown",
            description=None,
            html_url=f"https://github.com/{repository_name}",
            is_private=False,
            can_push=False,
            accessible=False,
            error_reason=reason,
        )


class GitHubClient:
    """High-level client for GitHub API interactions."""

    def __init__(
        self,
        token: str,
        default_repository: Optional[str] = None,
        timeout: int = 15,
        base_url: Optional[str] = None,
    ) -> None:
        """Initialize the GitHub Client.

        Args:
            token: GitHub Personal Access Token.
            default_repository: Optional default repository in 'owner/name' format.
            timeout: API request timeout in seconds.
            base_url: Optional base URL for GitHub Enterprise instances.
        """
        if not token or not token.strip():
            raise GitHubAuthError("Cannot initialize GitHubClient with an empty token.")

        self._token = token.strip()
        self._default_repository = (
            default_repository.strip() if default_repository else None
        )
        self._timeout = timeout
        self._auth = Auth.Token(self._token)

        if base_url:
            self._github = Github(
                auth=self._auth,
                base_url=base_url,
                timeout=self._timeout,
            )
        else:
            self._github = Github(
                auth=self._auth,
                timeout=self._timeout,
            )

    @property
    def default_repository(self) -> Optional[str]:
        """Return the configured default repository."""
        return self._default_repository

    def authenticate(self) -> UserInfo:
        """Verify that the provided token is valid by querying the authenticated user.

        Returns:
            UserInfo representing the authenticated account.

        Raises:
            GitHubAuthError: If the token is invalid, expired, or revoked.
            GitHubRateLimitError: If the rate limit is exceeded.
            GitHubClientError: If an unexpected error occurs during authentication.
        """
        try:
            user = self._github.get_user()
            # Accessing user.login forces a network request to validate credentials
            return UserInfo.from_github_user(user)
        except BadCredentialsException as exc:
            raise GitHubAuthError(
                "Authentication failed: Invalid, expired, or revoked GitHub token."
            ) from exc
        except RateLimitExceededException as exc:
            raise GitHubRateLimitError(
                "GitHub API rate limit exceeded during authentication."
            ) from exc
        except GithubException as exc:
            if exc.status == 401:
                raise GitHubAuthError(
                    "Authentication failed: Bad credentials (HTTP 401)."
                ) from exc
            raise GitHubClientError(
                f"GitHub API error during authentication (status {exc.status}): {exc.data}"
            ) from exc
        except Exception as exc:
            raise GitHubClientError(
                f"Failed to connect to GitHub API: {exc}"
            ) from exc

    def get_authenticated_user(self) -> AuthenticatedUser:
        """Retrieve the raw PyGithub AuthenticatedUser object.

        Returns:
            The PyGithub AuthenticatedUser.

        Raises:
            GitHubAuthError: If authentication fails.
            GitHubClientError: For network or other API errors.
        """
        try:
            user = self._github.get_user()
            _ = user.login  # Trigger lazy load
            return user
        except BadCredentialsException as exc:
            raise GitHubAuthError(
                "Authentication failed: Invalid or expired GitHub token."
            ) from exc
        except GithubException as exc:
            raise GitHubClientError(
                f"Failed to retrieve authenticated user: {exc}"
            ) from exc

    def get_repository(self, repository_name: Optional[str] = None) -> Repository:
        """Retrieve the PyGithub Repository object for the specified repository.

        Args:
            repository_name: Optional repository name in 'owner/repo' format.
                Defaults to the client's default_repository.

        Returns:
            The PyGithub Repository instance.

        Raises:
            GitHubRepositoryError: If the repository is not found or inaccessible.
            GitHubAuthError: If token authentication is invalid.
            GitHubClientError: For unexpected errors.
        """
        target_repo = repository_name or self._default_repository
        if not target_repo:
            raise GitHubRepositoryError(
                "No repository specified and no default repository configured."
            )

        try:
            repo = self._github.get_repo(target_repo)
            _ = repo.id  # Trigger lazy load to verify accessibility
            return repo
        except UnknownObjectException as exc:
            raise GitHubRepositoryError(
                f"Repository '{target_repo}' was not found or token lacks access."
            ) from exc
        except BadCredentialsException as exc:
            raise GitHubAuthError(
                "Authentication failed while accessing repository."
            ) from exc
        except RateLimitExceededException as exc:
            raise GitHubRateLimitError(
                "GitHub API rate limit exceeded while retrieving repository."
            ) from exc
        except GithubException as exc:
            if exc.status == 404:
                raise GitHubRepositoryError(
                    f"Repository '{target_repo}' not found or token lacks access (HTTP 404)."
                ) from exc
            if exc.status == 403:
                raise GitHubRepositoryError(
                    f"Access forbidden for repository '{target_repo}' (HTTP 403). "
                    "Ensure your token has the required 'repo' or 'public_repo' scope."
                ) from exc
            raise GitHubClientError(
                f"Error retrieving repository '{target_repo}': {exc}"
            ) from exc
        except Exception as exc:
            raise GitHubClientError(
                f"Unexpected error retrieving repository '{target_repo}': {exc}"
            ) from exc

    def check_repository_access(
        self, repository_name: Optional[str] = None
    ) -> RepositoryInfo:
        """Validate access to the repository and return structured metadata.

        Args:
            repository_name: Optional target repository ('owner/repo').

        Returns:
            RepositoryInfo with visibility, default branch, permissions, etc.

        Raises:
            GitHubRepositoryError: If access validation fails.
            GitHubAuthError: If authentication fails.
        """
        repo = self.get_repository(repository_name)
        return RepositoryInfo.from_github_repo(repo)

    def close(self) -> None:
        """Close the underlying GitHub session."""
        if hasattr(self._github, "close"):
            self._github.close()

    def __enter__(self) -> GitHubClient:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.close()
