"""Commit Manager module for GitHub Activity Assistant.

Takes validated ActivityPlan objects, applies safe file changes to local repositories,
verifies diffs, scans for secrets, creates conventional Git commits, and records history.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Optional, Sequence

from app.activity.history import ActivityHistoryManager
from app.activity.models import ActivityPlan, ActivityType
from app.activity.validator import ActivityValidator
from app.git.git_manager import GitError, GitManager


@dataclass
class CommitResult:
    """Outcome of an activity execution and commit attempt."""

    success: bool
    repository: str
    activity_plan: ActivityPlan
    commit_hash: Optional[str] = None
    commit_message: Optional[str] = None
    diff: Optional[str] = None
    error_message: Optional[str] = None


class CommitManager:
    """Executes validated ActivityPlans against local Git repositories."""

    def __init__(
        self,
        git_manager: GitManager,
        history_manager: Optional[ActivityHistoryManager] = None,
        validator: Optional[ActivityValidator] = None,
        local_base_path: Optional[Path | str] = None,
        token: Optional[str] = None,
        default_author_name: Optional[str] = None,
        default_author_email: Optional[str] = None,
    ) -> None:
        """Initialize CommitManager.

        Args:
            git_manager: Active GitManager instance.
            history_manager: Optional ActivityHistoryManager.
            validator: Optional ActivityValidator.
            local_base_path: Base directory for local repositories (defaults to './repositories').
            token: Optional GitHub PAT for authenticated cloning.
            default_author_name: Optional Git commit author name fallback.
            default_author_email: Optional Git commit author email fallback.
        """
        self._git = git_manager
        self._history = history_manager or ActivityHistoryManager()
        self._validator = validator or ActivityValidator(blocked_tokens=[token] if token else [])
        self._base_path = Path(local_base_path or "./repositories")
        self._token = token
        self._author_name = default_author_name or "GitHub Activity Assistant"
        self._author_email = default_author_email or "assistant@users.noreply.github.com"

    @property
    def author_name(self) -> str:
        """Return configured Git author name."""
        return self._author_name

    @author_name.setter
    def author_name(self, value: Optional[str]) -> None:
        """Set Git author name."""
        if value:
            self._author_name = value

    @property
    def author_email(self) -> str:
        """Return configured Git author email."""
        return self._author_email

    @author_email.setter
    def author_email(self, value: Optional[str]) -> None:
        """Set Git author email."""
        if value:
            self._author_email = value

    @property
    def base_path(self) -> Path:

        """Return the local repositories base storage path."""
        return self._base_path

    def get_local_repo_path(self, repository_full_name: str) -> Path:
        """Derive the local directory path for a repository identifier.

        Args:
            repository_full_name: Target repository in 'owner/repo' format.

        Returns:
            Path pointing to local repository directory.
        """
        parts = repository_full_name.split("/")
        dir_name = parts[-1] if len(parts) > 1 else repository_full_name
        return (self._base_path / dir_name).resolve()

    def ensure_repository(
        self,
        repository_full_name: str,
        clone_url: Optional[str] = None,
    ) -> Path:
        """Locate or clone target repository locally.

        Args:
            repository_full_name: Target repository ('owner/repo').
            clone_url: Optional explicit HTTPS clone URL.

        Returns:
            Path to the local Git repository.

        Raises:
            GitError: If cloning fails or repository cannot be initialized.
        """
        local_path = self.get_local_repo_path(repository_full_name)

        if self._git.repository_exists(local_path):
            return local_path

        url = clone_url or f"https://github.com/{repository_full_name}.git"
        return self._git.clone_repository(
            remote_url=url,
            local_path=local_path,
            token=self._token,
        )

    def generate_commit_message(self, plan: ActivityPlan) -> str:
        """Generate a conventional, truthful commit message from an ActivityPlan.

        Args:
            plan: The planned ActivityPlan.

        Returns:
            Formatted conventional commit message string.
        """
        repo_short = plan.repository.split("/")[-1]

        type_messages: dict[ActivityType, str] = {
            ActivityType.PROGRESS_LOG: f"docs: update development progress log for {repo_short}",
            ActivityType.DOCUMENTATION: f"docs: update developer reference notes for {repo_short}",
            ActivityType.CHANGELOG: f"docs: record changelog maintenance update for {repo_short}",
            ActivityType.PROJECT_NOTES: f"docs: record project engineering journal for {repo_short}",
            ActivityType.TODO_UPDATE: f"docs: update milestone checklist in {repo_short}",
            ActivityType.CONFIGURATION_DOCS: f"docs: document environment setup for {repo_short}",
            ActivityType.TEST_DATA: f"docs: update test scenario notes for {repo_short}",
            ActivityType.CODE_COMMENTS: f"docs: document architecture structure for {repo_short}",
        }

        return type_messages.get(
            plan.activity_type,
            f"docs: update documentation for {repo_short}",
        )

    def execute_activity(
        self,
        plan: ActivityPlan,
        dry_run: bool = False,
        repo_path_override: Optional[Path] = None,
    ) -> CommitResult:
        """Execute a single ActivityPlan against a local repository.

        Args:
            plan: Validated ActivityPlan to execute.
            dry_run: If True, inspect and preview diff without committing.
            repo_path_override: Optional specific local repository Path (useful for testing).

        Returns:
            CommitResult detailing success, commit hash, diff, or error message.
        """
        # 1. Verify plan validity
        if not plan.valid:
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"Activity plan is invalid: {plan.validation_error}",
            )

        # 2. Re-scan proposed content for secrets
        secret_error = self._validator.scan_for_secrets(plan.proposed_content)
        if secret_error:
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"COMMIT BLOCKED: Security validation failed ({secret_error}).",
            )

        # 3. Locate local repository
        try:
            repo_path = repo_path_override or self.ensure_repository(plan.repository)
        except GitError as exc:
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"Failed to locate or clone repository: {exc}",
            )

        # 4. Working Tree Cleanliness Check
        try:
            if not self._git.is_clean(repo_path):
                status_lines = self._git.get_status(repo_path)
                return CommitResult(
                    success=False,
                    repository=plan.repository,
                    activity_plan=plan,
                    error_message=(
                        f"Repository '{plan.repository}' contains uncommitted changes ({len(status_lines)} files). "
                        "The assistant will NOT modify dirty repositories. Please commit or stash existing work."
                    ),
                )
        except GitError as exc:
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"Failed to check working tree status: {exc}",
            )

        # 5. Capture existing file content for safe dry-run revert
        existing_content = self._git.read_file(repo_path, plan.target_file)

        # 6. Apply planned file change
        try:
            self._git.write_file(
                repo_path=repo_path,
                relative_file_path=plan.target_file,
                content=plan.proposed_content,
                append=True,
            )
        except GitError as exc:
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"Failed to write target file '{plan.target_file}': {exc}",
            )

        # 7. Stage only the expected target file
        try:
            self._git.stage_file(repo_path, plan.target_file)
            staged_files = self._git.get_staged_files(repo_path)
            normalized_target = str(PurePosixPath(plan.target_file.replace("\\", "/")))

            # Verify that only the intended file was staged
            normalized_staged = [str(PurePosixPath(f.replace("\\", "/"))) for f in staged_files]
            if normalized_staged != [normalized_target]:
                # Revert change immediately if unexpected files got staged
                self._revert_temporary_change(repo_path, plan.target_file, existing_content)
                return CommitResult(
                    success=False,
                    repository=plan.repository,
                    activity_plan=plan,
                    error_message=f"Staging verification failed: unexpected files staged {staged_files}.",
                )
        except GitError as exc:
            self._revert_temporary_change(repo_path, plan.target_file, existing_content)
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"Git staging failed: {exc}",
            )

        # 8. Inspect Diff
        try:
            diff_text = self._git.get_diff(repo_path, cached=True)
            # Scan diff for secrets
            diff_secret_err = self._validator.scan_for_secrets(diff_text)
            if diff_secret_err:
                self._revert_temporary_change(repo_path, plan.target_file, existing_content)
                return CommitResult(
                    success=False,
                    repository=plan.repository,
                    activity_plan=plan,
                    error_message=f"COMMIT BLOCKED: Secret detected in Git diff ({diff_secret_err}).",
                )
        except GitError as exc:
            self._revert_temporary_change(repo_path, plan.target_file, existing_content)
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"Failed to generate Git diff: {exc}",
            )

        commit_msg = self.generate_commit_message(plan)

        # 9. Handle Dry-Run vs Commit
        if dry_run:
            self._revert_temporary_change(repo_path, plan.target_file, existing_content)
            return CommitResult(
                success=True,
                repository=plan.repository,
                activity_plan=plan,
                commit_hash=None,
                commit_message=commit_msg,
                diff=diff_text,
            )

        # 10. Create Commit
        try:
            commit_hash = self._git.create_commit(
                repo_path=repo_path,
                message=commit_msg,
                author_name=self._author_name,
                author_email=self._author_email,
            )
            # Record success in history
            self._history.record_plan(plan, status=f"COMMITTED:{commit_hash}")
            return CommitResult(
                success=True,
                repository=plan.repository,
                activity_plan=plan,
                commit_hash=commit_hash,
                commit_message=commit_msg,
                diff=diff_text,
            )
        except GitError as exc:
            self._revert_temporary_change(repo_path, plan.target_file, existing_content)
            return CommitResult(
                success=False,
                repository=plan.repository,
                activity_plan=plan,
                error_message=f"Git commit creation failed: {exc}",
            )

    def _revert_temporary_change(
        self, repo_path: Path, relative_file: str, original_content: Optional[str]
    ) -> None:
        """Safely revert a file to its original state without using destructive git commands."""
        try:
            target_path = (repo_path / PurePosixPath(relative_file.replace("\\", "/"))).resolve()
            if original_content is None:
                if target_path.exists():
                    target_path.unlink()
            else:
                target_path.write_text(original_content, encoding="utf-8")

            # Re-stage or reset stage
            self._git.stage_file(repo_path, relative_file)
        except Exception:
            pass

    def execute_plans(
        self,
        plans: Sequence[ActivityPlan],
        dry_run: bool = False,
    ) -> list[CommitResult]:
        """Sequentially execute a batch of ActivityPlans.

        Args:
            plans: Sequence of ActivityPlans to execute.
            dry_run: Whether to run in preview/dry-run mode.

        Returns:
            List of CommitResult objects.
        """
        results: list[CommitResult] = []
        for plan in plans:
            res = self.execute_activity(plan=plan, dry_run=dry_run)
            results.append(res)
        return results
