"""Git command wrapper and local repository manager for GitHub Activity Assistant.

Provides safe, subprocess-based Git operations with working tree protection,
single-file staging, and strict prohibition of destructive commands.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path, PurePosixPath
from typing import Any, Optional


class GitError(Exception):
    """Raised when a Git command fails or an unsafe Git operation is requested."""


class GitManager:
    """Safely orchestrates Git repository operations using subprocess."""

    # Explicitly forbidden command tokens to prevent accidental data loss
    FORBIDDEN_TOKENS: set[str] = {
        "--hard",
        "--force",
        "-f",
        "clean",
    }

    def __init__(self, git_executable: str = "git") -> None:
        """Initialize GitManager.

        Args:
            git_executable: Command or path for Git binary (defaults to 'git').
        """
        self._git = git_executable

    def _sanitize_output(self, text: str, token: Optional[str] = None) -> str:
        """Remove sensitive tokens from command outputs or error messages."""
        if not text:
            return ""
        if token and len(token) > 5:
            text = text.replace(token, "***")
        return text

    def _run_git(
        self,
        args: list[str],
        cwd: Optional[Path] = None,
        token: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> str:
        """Execute a Git command safely using argument lists (no shell=True).

        Args:
            args: List of command arguments following 'git'.
            cwd: Working directory for the Git command.
            token: Optional sensitive token to mask in error messages.
            env: Optional environment variables.

        Returns:
            Command standard output as string.

        Raises:
            GitError: If command fails or contains forbidden destructive arguments.
        """
        # Guard against destructive operations
        for arg in args:
            if arg.lower() in self.FORBIDDEN_TOKENS:
                raise GitError(f"Prohibited destructive Git argument detected: '{arg}'.")

        cmd = [self._git] + args
        cmd_env = os.environ.copy()
        if env:
            cmd_env.update(env)

        try:
            result = subprocess.run(
                cmd,
                cwd=str(cwd) if cwd else None,
                check=True,
                capture_output=True,
                text=True,
                encoding="utf-8",
                env=cmd_env,
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError as exc:
            sanitized_err = self._sanitize_output(exc.stderr.strip() or exc.stdout.strip(), token)
            raise GitError(f"Git command failed (exit code {exc.returncode}): {sanitized_err}") from exc
        except FileNotFoundError as exc:
            raise GitError(f"Git executable '{self._git}' was not found on system PATH.") from exc
        except Exception as exc:
            raise GitError(f"Unexpected error executing Git: {exc}") from exc

    def repository_exists(self, repo_path: Path) -> bool:
        """Check if target path contains an initialized Git repository (.git).

        Args:
            repo_path: Local path to inspect.

        Returns:
            True if repository exists, False otherwise.
        """
        return repo_path.is_dir() and (repo_path / ".git").exists()

    def clone_repository(
        self,
        remote_url: str,
        local_path: Path,
        token: Optional[str] = None,
    ) -> Path:
        """Clone a remote repository into a local path.

        Args:
            remote_url: HTTPS or SSH remote URL.
            local_path: Target directory path where repository should be cloned.
            token: Optional GitHub PAT to inject for authenticated HTTPS cloning.

        Returns:
            The Path where repository was cloned.

        Raises:
            GitError: If cloning fails or target path already exists.
        """
        if self.repository_exists(local_path):
            return local_path

        local_path.parent.mkdir(parents=True, exist_ok=True)

        clone_url = remote_url
        if token and remote_url.startswith("https://"):
            # Inject token in memory for HTTPS clone without printing
            clean_url = remote_url.replace("https://", "")
            clone_url = f"https://x-access-token:{token}@{clean_url}"

        self._run_git(
            args=["clone", clone_url, str(local_path.resolve())],
            token=token,
        )
        return local_path

    def get_status(self, repo_path: Path) -> list[str]:
        """Get porcelain status lines for a local repository.

        Args:
            repo_path: Local repository path.

        Returns:
            List of non-empty porcelain status lines.
        """
        output = self._run_git(args=["status", "--porcelain"], cwd=repo_path)
        return [line for line in output.splitlines() if line.strip()]

    def is_clean(self, repo_path: Path) -> bool:
        """Check whether the working tree is clean (no uncommitted or untracked changes).

        Args:
            repo_path: Local repository path.

        Returns:
            True if clean, False if dirty.
        """
        return len(self.get_status(repo_path)) == 0

    def get_current_branch(self, repo_path: Path) -> str:
        """Get the active branch name.

        Args:
            repo_path: Local repository path.

        Returns:
            Branch name string (e.g. 'main').
        """
        return self._run_git(args=["rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_path)

    def read_file(self, repo_path: Path, relative_file_path: str) -> Optional[str]:
        """Safely read content of a file relative to repository root.

        Args:
            repo_path: Local repository path.
            relative_file_path: Relative path to target file.

        Returns:
            File content as string if file exists, None otherwise.

        Raises:
            GitError: If file path attempts directory traversal.
        """
        target = self._resolve_safe_path(repo_path, relative_file_path)
        if not target.is_file():
            return None
        return target.read_text(encoding="utf-8")

    def write_file(
        self,
        repo_path: Path,
        relative_file_path: str,
        content: str,
        append: bool = True,
    ) -> Path:
        """Safely write or append content to a file inside the repository.

        Args:
            repo_path: Local repository path.
            relative_file_path: Relative path to target file.
            content: Content to write or append.
            append: If True and file exists, append content with clean newline separation.

        Returns:
            Resolved absolute Path of the modified file.

        Raises:
            GitError: If path escapes repository root.
        """
        target = self._resolve_safe_path(repo_path, relative_file_path)
        target.parent.mkdir(parents=True, exist_ok=True)

        if append and target.is_file():
            existing = target.read_text(encoding="utf-8")
            separator = "\n\n" if existing and not existing.endswith("\n\n") else ""
            new_content = f"{existing}{separator}{content.strip()}\n"
            target.write_text(new_content, encoding="utf-8")
        else:
            target.write_text(f"{content.strip()}\n", encoding="utf-8")

        return target

    def stage_file(self, repo_path: Path, relative_file_path: str) -> None:
        """Stage a specific file relative to the repository root.

        Args:
            repo_path: Local repository path.
            relative_file_path: Relative path to the file to stage.
        """
        clean_rel = str(PurePosixPath(relative_file_path.replace("\\", "/")))
        self._run_git(args=["add", clean_rel], cwd=repo_path)

    def get_staged_files(self, repo_path: Path) -> list[str]:
        """Get the list of files currently staged for commit.

        Args:
            repo_path: Local repository path.

        Returns:
            List of relative staged file paths.
        """
        output = self._run_git(args=["diff", "--cached", "--name-only"], cwd=repo_path)
        if not output:
            # Fallback for initial repository commit before HEAD exists
            status_lines = self.get_status(repo_path)
            staged = []
            for line in status_lines:
                if len(line) >= 3 and line[0] in {"A", "M", "R"}:
                    staged.append(line[3:].strip())
            return staged
        return [line.strip() for line in output.splitlines() if line.strip()]

    def get_diff(self, repo_path: Path, cached: bool = True) -> str:
        """Get diff output for the repository.

        Args:
            repo_path: Local repository path.
            cached: If True, get staged diff (--cached); else get unstaged diff.

        Returns:
            Git diff string.
        """
        args = ["diff", "--cached"] if cached else ["diff"]
        return self._run_git(args=args, cwd=repo_path)

    def create_commit(
        self,
        repo_path: Path,
        message: str,
        author_name: Optional[str] = None,
        author_email: Optional[str] = None,
    ) -> str:
        """Create a Git commit with a structured commit message.

        Args:
            repo_path: Local repository path.
            message: Commit message.
            author_name: Optional Git author name.
            author_email: Optional Git author email.

        Returns:
            Short commit SHA hash (e.g. '7d3a1b4').

        Raises:
            GitError: If no files are staged or commit fails.
        """
        env = {}
        if author_name:
            env["GIT_AUTHOR_NAME"] = author_name
            env["GIT_COMMITTER_NAME"] = author_name
        if author_email:
            env["GIT_AUTHOR_EMAIL"] = author_email
            env["GIT_COMMITTER_EMAIL"] = author_email

        self._run_git(args=["commit", "-m", message], cwd=repo_path, env=env)
        commit_hash = self._run_git(args=["rev-parse", "--short", "HEAD"], cwd=repo_path)
        return commit_hash

    def get_last_commit(self, repo_path: Path) -> dict[str, str]:
        """Get metadata for the most recent commit on active branch.

        Args:
            repo_path: Local repository path.

        Returns:
            Dictionary with hash, author, email, date, and message.
        """
        output = self._run_git(
            args=["log", "-1", "--format=%h%x00%an%x00%ae%x00%ad%x00%s"],
            cwd=repo_path,
        )
        parts = output.split("\x00")
        if len(parts) >= 5:
            return {
                "hash": parts[0],
                "author": parts[1],
                "email": parts[2],
                "date": parts[3],
                "message": parts[4],
            }
        return {"raw": output}

    def _resolve_safe_path(self, repo_path: Path, relative_file_path: str) -> Path:
        """Ensure the target path is strictly within the repository boundaries.

        Args:
            repo_path: Base repository directory.
            relative_file_path: Target relative path.

        Returns:
            Resolved absolute Path.

        Raises:
            GitError: If target path escapes repository root.
        """
        cleaned = relative_file_path.strip().replace("\\", "/")
        posix_rel = PurePosixPath(cleaned)

        if posix_rel.is_absolute() or ".." in posix_rel.parts:
            raise GitError(
                f"Security Violation: Target path '{relative_file_path}' "
                "attempts directory traversal outside repository root."
            )

        resolved_repo = repo_path.resolve()
        target_path = (resolved_repo / posix_rel).resolve()

        if not str(target_path).startswith(str(resolved_repo)):
            raise GitError(
                f"Security Violation: Resolved path '{target_path}' is outside repository root '{resolved_repo}'."
            )

        return target_path
