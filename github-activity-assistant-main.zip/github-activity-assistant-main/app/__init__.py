"""GitHub Activity Assistant.

A modular automation toolkit designed to maintain consistent and legitimate GitHub
repository activity across multiple repositories with CLI automation and a professional PySide6 Desktop GUI.
"""

from app.activity import (
    ActivityGenerator,
    ActivityHistoryManager,
    ActivityPlan,
    ActivityPlanner,
    ActivityType,
    ActivityValidator,
    ValidationResult,
)
from app.config import AppConfig, ConfigError, load_config
from app.git import CommitManager, CommitResult, GitError, GitManager
from app.github_client import (
    GitHubAuthError,
    GitHubClient,
    GitHubClientError,
    GitHubRateLimitError,
    GitHubRepositoryError,
    RepositoryInfo,
    UserInfo,
)
from app.gui import (
    ActivityExecutionWorker,
    ActivityPlanWorker,
    ActivityPreviewDialog,
    ConfirmationDialog,
    FirstRunWizardDialog,
    GitHubValidationWorker,
    MainWindow,
    ReportExportWorker,
    get_theme_qss,
    run_gui_app,
)
from app.logging import get_logger, setup_logger
from app.monitoring import (
    ActivityRecord,
    HistoryStore,
    ReportGenerator,
    StatisticsEngine,
    TerminalDashboard,
)
from app.repository_manager import RepositoryManager
from app.scheduler import (
    ActivityScheduler,
    DailyRunner,
    DailyState,
    SchedulerStatus,
    SchedulerStateManager,
)
from app.web import start_mobile_server

__version__ = "1.0.0"


__all__ = [
    "ActivityExecutionWorker",
    "ActivityGenerator",
    "ActivityHistoryManager",
    "ActivityPlan",
    "ActivityPlanWorker",
    "ActivityPlanner",
    "ActivityPreviewDialog",
    "ActivityRecord",
    "ActivityScheduler",
    "ActivityType",
    "ActivityValidator",
    "AppConfig",
    "CommitManager",
    "CommitResult",
    "ConfigError",
    "ConfirmationDialog",
    "DailyRunner",
    "DailyState",
    "FirstRunWizardDialog",
    "GitHubAuthError",
    "GitHubClient",
    "GitHubClientError",
    "GitHubRateLimitError",
    "GitHubRepositoryError",
    "GitHubValidationWorker",
    "GitError",
    "GitManager",
    "HistoryStore",
    "MainWindow",
    "ReportExportWorker",
    "ReportGenerator",
    "RepositoryInfo",
    "RepositoryManager",
    "SchedulerStatus",
    "SchedulerStateManager",
    "StatisticsEngine",
    "TerminalDashboard",
    "UserInfo",
    "ValidationResult",
    "get_logger",
    "get_theme_qss",
    "load_config",
    "run_gui_app",
    "setup_logger",
]
