"""Daily runner engine coordinating activity planning, validation, execution, and state updates."""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Callable, Optional
from zoneinfo import ZoneInfo

from app.activity.models import ActivityPlan
from app.activity.planner import ActivityPlanner
from app.git.commit_manager import CommitManager, CommitResult
from app.logging.activity_logger import get_logger
from app.scheduler.state import DailyState, SchedulerStatus, SchedulerStateManager


class DailyRunner:
    """Coordinates daily planning, execution, duplicate prevention, and state persistence."""

    def __init__(
        self,
        planner: ActivityPlanner,
        commit_manager: CommitManager,
        state_manager: SchedulerStateManager,
        target_count: int = 5,
        timezone_name: str = "Asia/Kolkata",
        min_interval_minutes: int = 5,
        logger: Optional[logging.Logger] = None,
        sleep_func: Optional[Callable[[float], None]] = None,
    ) -> None:
        """Initialize DailyRunner.

        Args:
            planner: Phase 3 ActivityPlanner instance.
            commit_manager: Phase 4 CommitManager instance.
            state_manager: SchedulerStateManager instance.
            target_count: Target number of activities planned per day.
            timezone_name: Configured local timezone.
            min_interval_minutes: Interval in minutes between consecutive activities.
            logger: Optional custom logger.
            sleep_func: Optional sleep function for interval pacing (defaults to time.sleep).
        """
        self._planner = planner
        self._commit_mgr = commit_manager
        self._state_mgr = state_manager
        self._target = max(1, target_count)
        self._tz_name = timezone_name
        self._min_interval = max(0, min_interval_minutes)
        self._logger = logger or get_logger()
        self._sleep = sleep_func or time.sleep
        self._stop_requested = False

    @property
    def target(self) -> int:
        """Return daily target count."""
        return self._target

    @property
    def timezone_name(self) -> str:
        """Return configured timezone."""
        return self._tz_name

    def request_stop(self) -> None:
        """Signal the runner to stop gracefully after current activity."""
        self._stop_requested = True

    def get_today_date_str(self) -> str:
        """Return today's date (YYYY-MM-DD) in the configured timezone."""
        try:
            tz = ZoneInfo(self._tz_name)
        except Exception:
            tz = ZoneInfo("UTC")
        return datetime.now(tz).strftime("%Y-%m-%d")

    def run(
        self,
        dry_run: bool = False,
        force: bool = False,
        is_resume: bool = False,
    ) -> DailyState:
        """Execute daily workflow.

        Args:
            dry_run: If True, preview plans without modifying files or committing.
            force: If True, bypass duplicate-day protection check.
            is_resume: If True, resume from incomplete state without resetting.

        Returns:
            Final or updated DailyState.
        """
        today_str = self.get_today_date_str()
        self._logger.info(
            f"Daily runner started for {today_str} (Mode: {'DRY_RUN' if dry_run else 'COMMIT'}, Resume: {is_resume})"
        )

        # 1. Duplicate-Day Protection Check
        if not force and not is_resume and self._state_mgr.is_today_completed(today_str):
            state = self._state_mgr.get_or_create_state(today_str, self._target)
            self._logger.info(
                f"Today's activity target ({state.completed}/{state.target}) already completed for {today_str}."
            )
            return state

        # 2. Load or initialize state
        state = self._state_mgr.get_or_create_state(today_str, self._target)
        state.target = self._target


        # 3. Calculate remaining items
        if force:
            state.completed = 0
            state.failed = 0
            remaining_needed = state.target
        else:
            remaining_needed = max(0, state.target - state.completed)
            if remaining_needed == 0:
                state.status = SchedulerStatus.COMPLETED
                self._state_mgr.save_state(state)
                return state

        plans_to_generate = remaining_needed


        state.status = SchedulerStatus.RUNNING
        if not state.started_at:
            state.started_at = datetime.now(timezone.utc).isoformat()
        self._state_mgr.save_state(state)

        # 4. Generate Activity Plans via Phase 3 Planner
        plans = self._planner.plan_daily_activities(
            target_count=plans_to_generate,
            record_in_history=False,
        )

        if not plans:
            self._logger.warning("No valid activity plans available for planning.")
            if state.completed > 0:
                state.status = SchedulerStatus.COMPLETED
            else:
                state.status = SchedulerStatus.FAILED
            self._state_mgr.save_state(state)
            return state

        self._logger.info(f"Generated {len(plans)} validated activity plans.")

        # 5. Sequential Execution via Phase 4 CommitManager
        for idx, plan in enumerate(plans, start=1):
            if self._stop_requested:
                self._logger.info("Runner stop requested. Halting sequential execution.")
                state.status = SchedulerStatus.STOPPED
                self._state_mgr.save_state(state)
                return state

            self._logger.info(
                f"Executing activity {idx}/{len(plans)}: {plan.repository} -> {plan.target_file}"
            )

            result: CommitResult = self._commit_mgr.execute_activity(
                plan=plan,
                dry_run=dry_run,
            )

            now_iso = datetime.now(timezone.utc).isoformat()
            state.last_activity_at = now_iso

            if result.success:
                state.completed += 1
                state.activities.append({
                    "repository": plan.repository,
                    "target_file": plan.target_file,
                    "activity_type": plan.activity_type.value,
                    "title": plan.title,
                    "commit_hash": result.commit_hash,
                    "commit_message": result.commit_message,
                    "status": "SUCCESS" if not dry_run else "DRY_RUN_VALID",
                    "timestamp": now_iso,
                })
                self._logger.info(
                    f"Activity {idx} succeeded (Commit: {result.commit_hash or 'DRY_RUN'})."
                )
            else:
                state.failed += 1
                state.activities.append({
                    "repository": plan.repository,
                    "target_file": plan.target_file,
                    "activity_type": plan.activity_type.value,
                    "title": plan.title,
                    "status": "FAILED",
                    "error": result.error_message,
                    "timestamp": now_iso,
                })
                self._logger.warning(
                    f"Activity {idx} failed: {result.error_message}"
                )

            self._state_mgr.save_state(state)

            if state.completed >= state.target:
                break

            # Pacing interval between activities
            if not dry_run and self._min_interval > 0 and idx < len(plans):
                self._logger.info(
                    f"Waiting {self._min_interval} minute(s) interval before next activity..."
                )
                self._sleep(self._min_interval * 60)

        # 6. Finalize Run State
        if state.completed >= state.target or (state.completed > 0 and not dry_run):
            state.status = SchedulerStatus.COMPLETED
            state.completed_at = datetime.now(timezone.utc).isoformat()
        elif dry_run and state.completed > 0:
            state.status = SchedulerStatus.COMPLETED
        else:
            state.status = SchedulerStatus.FAILED

        self._state_mgr.save_state(state)
        self._logger.info(
            f"Daily run finished: {state.completed}/{state.target} completed, {state.failed} failed. Status: {state.status.value}"
        )
        return state
