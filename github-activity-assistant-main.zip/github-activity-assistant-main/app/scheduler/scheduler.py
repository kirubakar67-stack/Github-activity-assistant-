"""Foreground daily scheduler with timezone calculations, graceful shutdown, and visible status."""

from __future__ import annotations

import logging
import signal
import sys
import time
from datetime import datetime, timedelta
from typing import Callable, Optional
from zoneinfo import ZoneInfo

from app.logging.activity_logger import get_logger
from app.scheduler.daily_runner import DailyRunner


class ActivityScheduler:
    """Foreground scheduler coordinating daily automated activity execution."""

    def __init__(
        self,
        daily_runner: DailyRunner,
        schedule_time_str: str = "18:00",
        timezone_name: str = "Asia/Kolkata",
        logger: Optional[logging.Logger] = None,
        sleep_func: Optional[Callable[[float], None]] = None,
    ) -> None:
        """Initialize ActivityScheduler.

        Args:
            daily_runner: DailyRunner instance.
            schedule_time_str: 24-hr execution time string ('HH:MM').
            timezone_name: Valid IANA timezone string.
            logger: Optional custom logger.
            sleep_func: Optional sleep function for timer loops.
        """
        self._runner = daily_runner
        self._schedule_time_str = schedule_time_str
        self._tz_name = timezone_name
        self._logger = logger or get_logger()
        self._sleep = sleep_func or time.sleep

        parts = [int(p) for p in schedule_time_str.split(":")]
        self._target_hour = parts[0]
        self._target_minute = parts[1]

        self._running = False
        self._paused = False
        self._stop_requested = False

    @property
    def is_running(self) -> bool:
        """Check if scheduler is currently running."""
        return self._running

    @property
    def is_paused(self) -> bool:
        """Check if scheduler is paused."""
        return self._paused

    def get_timezone(self) -> ZoneInfo:
        """Return ZoneInfo object for the configured timezone."""
        try:
            return ZoneInfo(self._tz_name)
        except Exception:
            return ZoneInfo("UTC")

    def calculate_next_run(self, from_dt: Optional[datetime] = None) -> datetime:
        """Calculate the next scheduled run datetime in configured timezone.

        Args:
            from_dt: Optional reference datetime (defaults to current time in timezone).

        Returns:
            Next run datetime with timezone info.
        """
        tz = self.get_timezone()
        now = from_dt if from_dt is not None else datetime.now(tz)
        if now.tzinfo is None:
            now = now.replace(tzinfo=tz)

        scheduled_today = now.replace(
            hour=self._target_hour,
            minute=self._target_minute,
            second=0,
            microsecond=0,
        )

        if now < scheduled_today:
            return scheduled_today
        else:
            return scheduled_today + timedelta(days=1)

    def calculate_seconds_until_next_run(self, from_dt: Optional[datetime] = None) -> float:
        """Return remaining seconds until next scheduled run."""
        tz = self.get_timezone()
        now = from_dt if from_dt is not None else datetime.now(tz)
        if now.tzinfo is None:
            now = now.replace(tzinfo=tz)

        next_run = self.calculate_next_run(from_dt=now)
        return max(0.0, (next_run - now).total_seconds())

    def stop(self) -> None:
        """Request graceful shutdown of the scheduler."""
        self._stop_requested = True
        self._running = False
        self._runner.request_stop()
        self._logger.info("Scheduler stop requested.")

    def pause(self) -> None:
        """Pause scheduler execution."""
        self._paused = True
        self._logger.info("Scheduler paused.")

    def resume(self) -> None:
        """Resume scheduler execution."""
        self._paused = False
        self._logger.info("Scheduler resumed.")

    def _handle_signal(self, signum: int, frame: object) -> None:
        """Handle termination signal (SIGINT / Ctrl+C)."""
        print("\n\n[!] Shutdown requested by user (Ctrl+C).")
        print("    Stopping scheduler safely and saving state...")
        self.stop()

    def start(
        self,
        dry_run: bool = False,
        max_cycles: Optional[int] = None,
    ) -> None:
        """Start the visible foreground scheduler loop.

        Args:
            dry_run: Whether daily runner should operate in dry-run mode.
            max_cycles: Optional maximum number of scheduled executions before exiting.
        """
        self._running = True
        self._stop_requested = False
        self._logger.info(
            f"Scheduler started (Time: {self._schedule_time_str}, Timezone: {self._tz_name}, DryRun: {dry_run})"
        )

        # Register SIGINT handler
        try:
            signal.signal(signal.SIGINT, self._handle_signal)
        except (ValueError, AttributeError):
            # Not in main thread or platform unsupported
            pass

        next_run = self.calculate_next_run()
        print("==================================================")
        print("       GitHub Activity Assistant Scheduler        ")
        print("==================================================")
        print(f"Status        : RUNNING (Foreground Mode)")
        print(f"Schedule Time : {self._schedule_time_str}")
        print(f"Timezone      : {self._tz_name}")
        print(f"Daily Target  : {self._runner.target}")
        print(f"Mode          : {'DRY-RUN (Preview)' if dry_run else 'COMMIT (Local Commits)'}")
        print(f"Next Run      : {next_run.strftime('%Y-%m-%d %H:%M:%S')} ({self._tz_name})")
        print("--------------------------------------------------")
        print("Press Ctrl+C to stop safely.\n")

        cycle_count = 0

        while self._running and not self._stop_requested:
            if max_cycles is not None and cycle_count >= max_cycles:
                break

            seconds_left = self.calculate_seconds_until_next_run()

            # Sleep in chunks to allow responsive shutdown
            while seconds_left > 0 and self._running and not self._stop_requested:
                if self._paused:
                    self._sleep(1)
                    continue

                sleep_chunk = min(seconds_left, 1.0)
                self._sleep(sleep_chunk)
                seconds_left = self.calculate_seconds_until_next_run()

            if not self._running or self._stop_requested:
                break

            if self._paused:
                continue

            # Schedule time reached -> Trigger daily runner
            print(f"\n[{datetime.now(self.get_timezone()).strftime('%Y-%m-%d %H:%M:%S')}] Triggering daily workflow...")
            self._logger.info("Scheduled trigger firing daily runner.")

            try:
                state = self._runner.run(dry_run=dry_run, force=False)
                print(f"Daily Workflow Completed: {state.completed}/{state.target} succeeded ({state.status.value}).")
            except Exception as exc:
                self._logger.error(f"Error during daily runner execution: {exc}", exc_info=True)
                print(f"[!] Error during daily run: {exc}")

            cycle_count += 1
            next_run = self.calculate_next_run()
            print(f"Next scheduled run: {next_run.strftime('%Y-%m-%d %H:%M:%S')} ({self._tz_name})\n")

        print("\nScheduler stopped safely. Current state preserved.")
        self._logger.info("Scheduler execution loop terminated.")
