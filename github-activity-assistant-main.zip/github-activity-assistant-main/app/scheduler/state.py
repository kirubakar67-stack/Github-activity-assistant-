"""State management module for daily scheduler execution tracking."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

DEFAULT_STATE_FILE: Path = Path("data") / "scheduler_state.json"


class SchedulerStatus(str, Enum):
    """Execution status states for the scheduler."""

    IDLE = "IDLE"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    STOPPED = "STOPPED"

    @classmethod
    def from_string(cls, val: str) -> SchedulerStatus:
        """Parse status from string case-insensitively."""
        normalized = val.strip().upper()
        for item in cls:
            if item.value == normalized:
                return item
        return cls.IDLE


@dataclass
class DailyState:
    """State record for a single day's scheduled activities.

    Attributes:
        date: Date string in 'YYYY-MM-DD' format.
        status: Current SchedulerStatus.
        target: Target number of activities planned for this day.
        completed: Number of successfully executed and committed activities.
        failed: Number of failed activity execution attempts.
        started_at: ISO timestamp when daily run commenced.
        completed_at: ISO timestamp when daily run reached completion.
        last_activity_at: ISO timestamp of the most recent activity execution.
        activities: List of executed activity metadata dictionaries.
    """

    date: str
    status: SchedulerStatus = SchedulerStatus.IDLE
    target: int = 5
    completed: int = 0
    failed: int = 0
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    last_activity_at: Optional[str] = None
    activities: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Normalize status enum if string passed."""
        if isinstance(self.status, str) and not isinstance(self.status, SchedulerStatus):
            self.status = SchedulerStatus.from_string(self.status)

    def to_dict(self) -> dict[str, Any]:
        """Convert state to serializable dictionary."""
        data = asdict(self)
        data["status"] = self.status.value
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DailyState:
        """Construct DailyState from dictionary."""
        return cls(
            date=data.get("date", datetime.now(timezone.utc).strftime("%Y-%m-%d")),
            status=SchedulerStatus.from_string(data.get("status", "IDLE")),
            target=data.get("target", 5),
            completed=data.get("completed", 0),
            failed=data.get("failed", 0),
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            last_activity_at=data.get("last_activity_at"),
            activities=data.get("activities", []),
        )


class SchedulerStateManager:
    """Manages reading and writing daily scheduler execution state to JSON."""

    def __init__(self, state_file: Optional[Path | str] = None) -> None:
        """Initialize state manager with destination file path."""
        self._state_file = Path(state_file or DEFAULT_STATE_FILE)

    @property
    def state_file(self) -> Path:
        """Return the state file path."""
        return self._state_file

    def load_state(self) -> Optional[DailyState]:
        """Load state record from disk."""
        if not self._state_file.exists():
            return None
        try:
            with open(self._state_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return DailyState.from_dict(data)
                return None
        except Exception:
            return None

    def save_state(self, state: DailyState) -> None:
        """Atomically persist daily state to disk."""
        self._state_file.parent.mkdir(parents=True, exist_ok=True)
        temp_file = self._state_file.with_suffix(".tmp")
        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(state.to_dict(), f, indent=2)
        temp_file.replace(self._state_file)

    def get_or_create_state(self, date_str: str, target: int) -> DailyState:
        """Retrieve existing state for date or initialize a new DailyState."""
        existing = self.load_state()
        if existing and existing.date == date_str:
            return existing

        new_state = DailyState(
            date=date_str,
            status=SchedulerStatus.IDLE,
            target=target,
            completed=0,
            failed=0,
        )
        self.save_state(new_state)
        return new_state

    def is_today_completed(self, date_str: str) -> bool:
        """Check if today's activity target is already marked complete."""
        existing = self.load_state()
        if not existing or existing.date != date_str:
            return False
        return (
            existing.status == SchedulerStatus.COMPLETED
            or (existing.completed >= existing.target and existing.target > 0)
        )

    def detect_incomplete_run(self, date_str: Optional[str] = None) -> Optional[DailyState]:
        """Check for an interrupted run that did not reach COMPLETED status."""
        existing = self.load_state()
        if not existing:
            return None
        if date_str and existing.date != date_str:
            return None
        if existing.status in {SchedulerStatus.RUNNING, SchedulerStatus.PAUSED, SchedulerStatus.STOPPED}:
            if existing.completed < existing.target:
                return existing
        return None

    def clear(self) -> None:
        """Delete local state file."""
        if self._state_file.exists():
            self._state_file.unlink()
