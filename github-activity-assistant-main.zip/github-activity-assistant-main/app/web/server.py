"""Mobile Web Application & REST API Server for GitHub Activity Assistant."""

from __future__ import annotations

import json
import os
import socket
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Optional

from app.activity import ActivityPlanner, ActivityValidator
from app.config import AppConfig, ConfigError, load_config
from app.git import CommitManager, GitManager
from app.github_client import GitHubClient
from app.logging import get_logger, setup_logger
from app.monitoring import HistoryStore, StatisticsEngine
from app.repository_manager import RepositoryManager
from app.scheduler import (
    ActivityScheduler,
    DailyRunner,
    SchedulerStatus,
    SchedulerStateManager,
)

STATIC_DIR = Path(__file__).parent / "static"


def get_local_ip() -> str:
    """Detect local LAN IP address for mobile connection."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Doesn't have to be reachable; used to identify outbound local adapter IP
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def print_qr_code(url: str) -> None:
    """Print ASCII QR Code in terminal for mobile scanning."""
    try:
        import qrcode

        qr = qrcode.QRCode(border=1)
        qr.add_data(url)
        qr.make(fit=True)
        print("\nScan this QR Code with your phone camera:")
        print("--------------------------------------------------")
        qr.print_ascii(invert=True)
        print("--------------------------------------------------\n")
    except Exception:
        pass


class AssistantRequestHandler(BaseHTTPRequestHandler):
    """HTTP Handler serving the Mobile Single Page App and REST endpoints."""

    # Class-level state injected from server
    config: AppConfig
    runner: DailyRunner
    scheduler: ActivityScheduler
    state_mgr: SchedulerStateManager
    history_store: HistoryStore
    commit_mgr: CommitManager

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress standard HTTP server access spam."""
        return

    def _set_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self) -> None:
        self.send_response(200)
        self._set_cors_headers()
        self.end_headers()

    def _send_json(self, data: dict[str, Any], status_code: int = 200) -> None:
        self.send_response(status_code)
        self._set_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(data, default=str).encode("utf-8"))

    def do_GET(self) -> None:
        """Handle GET requests for static UI or API endpoints."""
        url_path = self.path.split("?")[0]

        if url_path in {"/", "/index.html"}:
            index_file = STATIC_DIR / "index.html"
            if index_file.exists():
                content = index_file.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
            else:
                self._send_json({"error": "UI index.html not found"}, 404)
            return

        if url_path == "/api/status":
            state = self.state_mgr.load_state()
            today_str = self.runner.get_today_date_str()
            status_val = state.status.value if state else "IDLE"
            completed = state.completed if state else 0
            failed = state.failed if state else 0
            target = state.target if state else self.config.daily_activity_target
            acts = state.activities if state else []

            user_login = self.commit_mgr.author_name

            self._send_json({
                "success": True,
                "date": today_str,
                "status": status_val,
                "completed": completed,
                "failed": failed,
                "target": target,
                "user": user_login,
                "repositories": list(self.config.github_repositories),
                "activities": acts,
                "schedule_time": self.config.schedule_time,
                "timezone": self.config.timezone,
            })
            return

        if url_path == "/api/history":
            records = self.history_store.get_records()
            records_data = [r.to_dict() for r in records[-20:]]
            self._send_json({"success": True, "records": records_data})
            return

        self._send_json({"error": "Not Found"}, 404)

    def do_POST(self) -> None:
        """Handle POST action endpoints."""
        url_path = self.path.split("?")[0]
        content_len = int(self.headers.get("Content-Length", 0))
        body: dict[str, Any] = {}
        if content_len > 0:
            try:
                raw = self.rfile.read(content_len).decode("utf-8")
                body = json.loads(raw)
            except Exception:
                body = {}

        if url_path == "/api/execute":
            dry_run = bool(body.get("dry_run", False))
            should_push = bool(body.get("push", False))

            try:
                state = self.runner.run(dry_run=dry_run, force=True)

                # If push requested and commits succeeded, push to remote
                pushed_repos: list[str] = []
                if should_push and not dry_run and state.completed > 0:
                    for repo in self.config.github_repositories:
                        short_name = repo.split("/")[-1]
                        repo_dir = self.config.local_repository_path / short_name
                        if (repo_dir / ".git").exists():
                            cmd = ["git", "-C", str(repo_dir), "push", "origin", "main"]
                            res = subprocess.run(cmd, capture_output=True, text=True)
                            if res.returncode == 0:
                                pushed_repos.append(short_name)

                self._send_json({
                    "success": True,
                    "completed": state.completed,
                    "failed": state.failed,
                    "dry_run": dry_run,
                    "pushed": pushed_repos,
                })
            except Exception as exc:
                self._send_json({"success": False, "error": str(exc)}, 500)
            return

        if url_path == "/api/push":
            target_repo = body.get("repository")
            pushed: list[str] = []
            errors: list[str] = []

            repos_to_push = (
                [target_repo] if target_repo else [r.split("/")[-1] for r in self.config.github_repositories]
            )

            for short_name in repos_to_push:
                repo_dir = self.config.local_repository_path / short_name
                if (repo_dir / ".git").exists():
                    cmd = ["git", "-C", str(repo_dir), "push", "origin", "main"]
                    res = subprocess.run(cmd, capture_output=True, text=True)
                    if res.returncode == 0:
                        pushed.append(short_name)
                    else:
                        errors.append(f"{short_name}: {res.stderr.strip()}")

            self._send_json({
                "success": len(pushed) > 0,
                "pushed": pushed,
                "errors": errors,
            })
            return

        if url_path == "/api/scheduler/toggle":
            if self.scheduler.is_running:
                self.scheduler.stop()
                status_str = "STOPPED"
            else:
                threading.Thread(
                    target=lambda: self.scheduler.start(dry_run=False, max_cycles=1),
                    daemon=True,
                ).start()
                status_str = "RUNNING"

            self._send_json({"success": True, "status": status_str})
            return

        self._send_json({"error": "Endpoint not found"}, 404)


def start_mobile_server(port: int = 8080) -> None:
    """Initialize and run the mobile web app HTTP server."""
    config = load_config()
    setup_logger(blocked_tokens=[config.github_token])
    logger = get_logger()

    client = GitHubClient(
        token=config.github_token,
        default_repository=config.github_repositories[0],
    )
    user_info = client.authenticate()

    repo_mgr = RepositoryManager(client=client, repositories=config.github_repositories)
    validator = ActivityValidator(blocked_tokens=[config.github_token])
    planner = ActivityPlanner(
        repository_manager=repo_mgr,
        validator=validator,
        daily_target=config.daily_activity_target,
    )

    git_mgr = GitManager()
    author_name = user_info.name or user_info.login
    author_email = user_info.email or f"{user_info.login}@users.noreply.github.com"

    commit_mgr = CommitManager(
        git_manager=git_mgr,
        validator=validator,
        local_base_path=config.local_repository_path,
        token=config.github_token,
        default_author_name=author_name,
        default_author_email=author_email,
    )

    state_mgr = SchedulerStateManager()
    runner = DailyRunner(
        planner=planner,
        commit_manager=commit_mgr,
        state_manager=state_mgr,
        target_count=config.daily_activity_target,
        timezone_name=config.timezone,
        min_interval_minutes=config.min_activity_interval_minutes,
        logger=logger,
    )

    scheduler = ActivityScheduler(
        daily_runner=runner,
        schedule_time_str=config.schedule_time,
        timezone_name=config.timezone,
        logger=logger,
    )

    history_store = HistoryStore()

    # Inject dependencies into request handler
    AssistantRequestHandler.config = config
    AssistantRequestHandler.runner = runner
    AssistantRequestHandler.scheduler = scheduler
    AssistantRequestHandler.state_mgr = state_mgr
    AssistantRequestHandler.history_store = history_store
    AssistantRequestHandler.commit_mgr = commit_mgr

    server = ThreadingHTTPServer(("0.0.0.0", port), AssistantRequestHandler)
    local_ip = get_local_ip()
    mobile_url = f"http://{local_ip}:{port}"

    print("==================================================")
    print("      GitHub Activity Assistant — Mobile Web      ")
    print("==================================================")
    print(f"Server Status : RUNNING on port {port}")
    print(f"Local Access  : http://localhost:{port}")
    print(f"Mobile Access : {mobile_url}")
    print("--------------------------------------------------")
    print("Open this URL on your phone's browser (Safari/Chrome)")
    print("Connected to the same Wi-Fi network.")

    print_qr_code(mobile_url)
    print("Press Ctrl+C to stop the mobile web server.\n")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Mobile Web Server...")
    finally:
        server.server_close()
        client.close()
        print("Mobile Web Server stopped.")
