"""CLI and GUI Entry point for GitHub Activity Assistant (Phase 7).

Orchestrates configuration loading, GitHub authentication, multi-repository validation,
activity planning, local Git execution, scheduler automation, monitoring dashboards,
and launches the PySide6 Desktop GUI application.
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional

from app.activity import ActivityPlanner, ActivityValidator
from app.config import ConfigError, load_config
from app.git import CommitManager, GitManager
from app.github_client import (
    GitHubAuthError,
    GitHubClient,
    GitHubClientError,
    GitHubRateLimitError,
)
from app.gui import run_gui_app
from app.logging import get_logger, setup_logger
from app.monitoring import (
    HistoryStore,
    ReportGenerator,
    StatisticsEngine,
    TerminalDashboard,
)
from app.repository_manager import RepositoryManager
from app.scheduler import (
    ActivityScheduler,
    DailyRunner,
    SchedulerStatus,
    SchedulerStateManager,
)


def print_banner(subtitle: str = "") -> None:
    """Print the application banner."""
    print("==================================================")
    print("           GitHub Activity Assistant              ")
    print("==================================================")
    if subtitle:
        print(subtitle)
        print("--------------------------------------------------")


def display_status() -> int:
    """Display current scheduler state and today's progress."""
    print_banner("Scheduler & Activity Status")
    state_mgr = SchedulerStateManager()
    state = state_mgr.load_state()

    if not state:
        print("No previous execution state found.")
        print("Status: IDLE (No activities recorded yet)")
        return 0

    print(f"Date            : {state.date}")
    print(f"Status          : {state.status.value}")
    print(f"Today's Progress: {state.completed}/{state.target} completed ({state.failed} failed)")
    if state.started_at:
        print(f"Started At      : {state.started_at}")
    if state.last_activity_at:
        print(f"Last Activity   : {state.last_activity_at}")
    if state.completed_at:
        print(f"Completed At    : {state.completed_at}")

    if state.activities:
        print("\nRecorded Activities Today:")
        for idx, act in enumerate(state.activities, start=1):
            repo = act.get("repository", "")
            target_file = act.get("target_file", "")
            act_status = act.get("status", "")
            c_hash = act.get("commit_hash") or "N/A"
            print(f"  [{idx}] {repo} -> {target_file} ({act_status}, Commit: {c_hash})")

    print("--------------------------------------------------\n")
    return 0


def display_dashboard(watch_mode: bool = False) -> int:
    """Render the terminal dashboard once or in live auto-refresh mode."""
    try:
        config = load_config()
        tz_name = config.timezone
        target = config.daily_activity_target
        refresh_sec = config.dashboard_refresh_seconds
    except Exception:
        tz_name = "Asia/Kolkata"
        target = 5
        refresh_sec = 5

    dashboard = TerminalDashboard(
        timezone_name=tz_name,
        daily_target=target,
    )

    if watch_mode:
        dashboard.render_live(refresh_seconds=refresh_sec)
    else:
        dashboard.display()
    return 0


def display_statistics(from_date: Optional[str] = None, to_date: Optional[str] = None) -> int:
    """Calculate and display high-level analytical statistics."""
    print_banner("Activity Statistics Summary")
    engine = StatisticsEngine()
    stats = engine.get_summary_statistics(from_date=from_date, to_date=to_date)

    print(f"Total Activities      : {stats['total_activities']}")
    print(f"Successful Commits    : {stats['successful_activities']}")
    print(f"Failed Executions     : {stats['failed_activities']}")
    print(f"Overall Success Rate  : {stats['success_rate']:.1f}%")
    print(f"Most Active Repository: {stats['most_active_repository']}")
    print(f"Most Common Activity  : {stats['most_common_activity_type']}")
    if stats["average_duration_seconds"] > 0:
        print(f"Average Duration      : {stats['average_duration_seconds']:.2f}s")

    print("\nRepository Breakdown:")
    for repo, r_stats in stats.get("repository_breakdown", {}).items():
        print(f"  - {repo:<28} : {r_stats['total']:>2} activities ({r_stats['success_rate']:.1f}% success)")

    print("\nActivity Types Distribution:")
    for a_type, t_stats in stats.get("activity_type_breakdown", {}).items():
        print(f"  - {a_type:<24} : {t_stats['count']:>2} ({t_stats['percentage']:.1f}%)")

    print("--------------------------------------------------\n")
    return 0


def generate_report(
    report_format: str = "json",
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
) -> int:
    """Generate and export JSON or CSV activity reports."""
    print_banner(f"Exporting Activity Report ({report_format.upper()})")
    try:
        config = load_config()
        output_dir = config.report_directory
    except Exception:
        output_dir = None

    generator = ReportGenerator(default_output_dir=output_dir)

    if report_format.lower() == "csv":
        path = generator.export_csv(from_date=from_date, to_date=to_date)
    else:
        path = generator.export_json(from_date=from_date, to_date=to_date)

    print(f"Report format : {report_format.upper()}")
    if from_date or to_date:
        print(f"Date filter   : {from_date or 'Start'} to {to_date or 'Latest'}")
    print(f"Export file   : {path.resolve()}")
    print("Status        : SUCCESS")
    print("--------------------------------------------------\n")
    return 0


def build_pipeline(
    target_override: Optional[int] = None,
    repo_filter: Optional[str] = None,
) -> tuple[DailyRunner, ActivityScheduler, GitHubClient, object]:
    """Initialize and assemble the complete multi-phase pipeline."""
    config = load_config()
    daily_target = target_override if target_override is not None else config.daily_activity_target

    setup_logger(blocked_tokens=[config.github_token])
    logger = get_logger()

    repositories = config.github_repositories
    if repo_filter:
        matched = [r for r in repositories if r.lower() == repo_filter.strip().lower()]
        if not matched:
            raise ConfigError(
                f"Repository '{repo_filter}' is not configured in GITHUB_REPOSITORIES."
            )
        repositories = tuple(matched)

    # 1. Authenticate with GitHub
    client = GitHubClient(
        token=config.github_token,
        default_repository=repositories[0],
    )
    user_info = client.authenticate()

    # 2. Validate Repositories
    repo_manager = RepositoryManager(
        client=client,
        repositories=repositories,
    )
    validated_list = repo_manager.validate_repositories()
    accessible_repos = [r for r in validated_list if r.accessible]
    if not accessible_repos:
        client.close()
        raise ConfigError("All configured repositories failed access validation.")

    # 3. Phase 3 Activity Planner
    validator = ActivityValidator(blocked_tokens=[config.github_token])
    planner = ActivityPlanner(
        repository_manager=repo_manager,
        validator=validator,
        daily_target=daily_target,
    )

    # 4. Phase 4 Git & Commit Manager (with author fallback)
    git_mgr = GitManager()
    author_name = user_info.name or user_info.login
    author_email = user_info.email or f"{user_info.login}@users.noreply.github.com"

    commit_mgr = CommitManager(
        git_manager=git_mgr,
        validator=validator,
        local_base_path=config.local_repository_path,
        token=config.github_token,
        default_author_name=author_name,
        default_author_email=author_email,
    )

    # 5. Phase 5 State & Daily Runner
    state_mgr = SchedulerStateManager()
    runner = DailyRunner(
        planner=planner,
        commit_manager=commit_mgr,
        state_manager=state_mgr,
        target_count=daily_target,
        timezone_name=config.timezone,
        min_interval_minutes=config.min_activity_interval_minutes,
        logger=logger,
    )

    # 6. Phase 5 Scheduler
    scheduler = ActivityScheduler(
        daily_runner=runner,
        schedule_time_str=config.schedule_time,
        timezone_name=config.timezone,
        logger=logger,
    )

    return runner, scheduler, client, config


def run_now(
    dry_run: bool = False,
    auto_confirm: bool = False,
    target_override: Optional[int] = None,
    repo_filter: Optional[str] = None,
    is_resume: bool = False,
) -> int:
    """Execute daily workflow immediately."""
    print_banner(f"Phase 7: {'Resume Daily Run' if is_resume else 'Manual Daily Run'}")

    try:
        runner, _, client, config = build_pipeline(
            target_override=target_override, repo_filter=repo_filter
        )
    except ConfigError as err:
        print(f"\n[!] Configuration Error:\n    {err}")
        return 1
    except (GitHubAuthError, GitHubRateLimitError, GitHubClientError) as err:
        print(f"\n[!] GitHub API Error:\n    {err}")
        return 1

    today_str = runner.get_today_date_str()
    mode_label = "DRY-RUN (Preview Only)" if dry_run else "COMMIT (Local Commits)"

    print(f"Date          : {today_str} ({config.timezone})")
    print(f"Daily Target  : {runner.target} activities")
    print(f"Execution Mode: {mode_label}")
    print(f"Repositories  : {len(config.github_repositories)}")
    print("--------------------------------------------------")

    if not auto_confirm:
        confirm = input("\nContinue with execution? [y/N]: ").strip().lower()
        if confirm not in {"y", "yes"}:
            print("Execution cancelled by user.")
            client.close()
            return 0

    print("\nExecuting daily activity workflow...")
    state = runner.run(dry_run=dry_run, force=not is_resume, is_resume=is_resume)

    client.close()

    print("\n==================================================")
    print("            DAILY WORKFLOW RESULTS                ")
    print("==================================================")
    print(f"Date          : {state.date}")
    print(f"Status        : {state.status.value}")
    print(f"Completed     : {state.completed}/{state.target}")
    print(f"Failed        : {state.failed}")
    print("--------------------------------------------------")

    if dry_run:
        print("NO COMMITS CREATED (Dry-run mode).")
    else:
        print(f"{state.completed} local commit(s) created.")
        print("Push has NOT been performed.")
        print("You can review local commits in ./repositories/ and push manually.")
    print("==================================================\n")
    return 0 if state.status == SchedulerStatus.COMPLETED else 1


def run_scheduler_mode(
    dry_run: bool = False,
    target_override: Optional[int] = None,
    repo_filter: Optional[str] = None,
) -> int:
    """Start the visible foreground daily scheduler loop."""
    try:
        _, scheduler, client, _ = build_pipeline(
            target_override=target_override, repo_filter=repo_filter
        )
    except ConfigError as err:
        print(f"\n[!] Configuration Error:\n    {err}")
        return 1
    except (GitHubAuthError, GitHubRateLimitError, GitHubClientError) as err:
        print(f"\n[!] GitHub API Error:\n    {err}")
        return 1

    try:
        scheduler.start(dry_run=dry_run)
    finally:
        client.close()
    return 0


# Backward compatibility aliases
run_phase1 = lambda: run_now(dry_run=True, auto_confirm=True)
run_phase2 = lambda interactive=True: run_now(dry_run=True, auto_confirm=True)
run_phase3 = lambda dry_run=True, target_override=None: run_now(dry_run=dry_run, auto_confirm=True, target_override=target_override)
run_phase4 = lambda commit_mode=False, target_override=None, repo_filter=None: run_now(dry_run=not commit_mode, auto_confirm=True, target_override=target_override, repo_filter=repo_filter)
run_phase5 = lambda: run_now(dry_run=False, auto_confirm=True)


def main() -> None:
    """CLI script entry point with argument parsing."""
    parser = argparse.ArgumentParser(
        description="GitHub Activity Assistant — Desktop GUI & CLI Automation Toolkit"
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        default=False,
        help="Launch the desktop PySide6 Graphical User Interface.",
    )
    parser.add_argument(
        "--web",
        "--mobile",
        action="store_true",
        default=False,
        help="Launch the Mobile Web App and REST API server for phone access.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port number for the Mobile Web App server (default: 8080).",
    )

    parser.add_argument(
        "--status",
        action="store_true",
        default=False,
        help="Display current scheduler state, progress, and today's activity log.",
    )
    parser.add_argument(
        "--dashboard",
        action="store_true",
        default=False,
        help="Display the visual terminal monitoring dashboard.",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        default=False,
        help="Enable live auto-refresh watch mode when viewing the dashboard.",
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        default=False,
        help="Display aggregated analytical statistics across all activities.",
    )
    parser.add_argument(
        "--report",
        action="store_true",
        default=False,
        help="Export structured audit report.",
    )
    parser.add_argument(
        "--format",
        choices=["json", "csv"],
        default="json",
        help="Format for exported reports (json or csv, default: json).",
    )
    parser.add_argument(
        "--from",
        dest="from_date",
        type=str,
        default=None,
        help="Start date filter for reports/stats (YYYY-MM-DD).",
    )
    parser.add_argument(
        "--to",
        dest="to_date",
        type=str,
        default=None,
        help="End date filter for reports/stats (YYYY-MM-DD).",
    )
    parser.add_argument(
        "--run-now",
        action="store_true",
        default=False,
        help="Execute today's daily workflow immediately.",
    )
    parser.add_argument(
        "--schedule",
        action="store_true",
        default=False,
        help="Start the foreground daily scheduler loop.",
    )
    parser.add_argument(
        "--resume-run",
        action="store_true",
        default=False,
        help="Resume an incomplete daily run from saved state.",
    )
    parser.add_argument(
        "--commit",
        action="store_true",
        default=False,
        help="Execute activities and create local Git commits.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Run in preview mode (zero file modifications and zero commits).",
    )
    parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        default=False,
        help="Automatically confirm prompts without interactive user input.",
    )
    parser.add_argument(
        "--target",
        type=int,
        default=None,
        help="Override the daily planned activity target count.",
    )
    parser.add_argument(
        "--repository",
        type=str,
        default=None,
        help="Restrict execution to a specific configured repository ('owner/repo').",
    )

    args = parser.parse_args()

    if args.gui:
        sys.exit(run_gui_app())

    if args.web:
        from app.web import start_mobile_server
        start_mobile_server(port=args.port)
        sys.exit(0)


    if args.status:
        sys.exit(display_status())

    if args.dashboard:
        sys.exit(display_dashboard(watch_mode=args.watch))

    if args.stats:
        sys.exit(display_statistics(from_date=args.from_date, to_date=args.to_date))

    if args.report:
        sys.exit(
            generate_report(
                report_format=args.format,
                from_date=args.from_date,
                to_date=args.to_date,
            )
        )

    if args.schedule:
        sys.exit(
            run_scheduler_mode(
                dry_run=args.dry_run,
                target_override=args.target,
                repo_filter=args.repository,
            )
        )

    if args.resume_run:
        sys.exit(
            run_now(
                dry_run=args.dry_run,
                auto_confirm=args.yes,
                target_override=args.target,
                repo_filter=args.repository,
                is_resume=True,
            )
        )

    if args.run_now:
        sys.exit(
            run_now(
                dry_run=args.dry_run,
                auto_confirm=args.yes,
                target_override=args.target,
                repo_filter=args.repository,
                is_resume=False,
            )
        )

    # Default fallback: if --commit passed, treat as run-now with commit
    if args.commit:
        sys.exit(
            run_now(
                dry_run=False,
                auto_confirm=args.yes,
                target_override=args.target,
                repo_filter=args.repository,
                is_resume=False,
            )
        )

    # Default fallback without CLI arguments:
    # If no flags passed, launch the GUI desktop app!
    if len(sys.argv) == 1:
        sys.exit(run_gui_app())

    # Otherwise default to dry-run
    sys.exit(
        run_now(
            dry_run=True,
            auto_confirm=args.yes or True,
            target_override=args.target,
            repo_filter=args.repository,
            is_resume=False,
        )
    )


if __name__ == "__main__":
    main()
