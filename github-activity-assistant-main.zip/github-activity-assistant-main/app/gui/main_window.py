"""Main desktop application window and navigation controller."""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtGui import QCloseEvent, QIcon
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from app.activity import ActivityPlanner, ActivityValidator
from app.config import AppConfig
from app.git import CommitManager, GitManager
from app.github_client import GitHubClient, RepositoryInfo, UserInfo
from app.gui.dialogs import ConfirmationDialog
from app.gui.styles import get_theme_qss
from app.gui.widgets import (
    ActivityWidget,
    DashboardWidget,
    HistoryWidget,
    LogsWidget,
    ReportsWidget,
    RepositoriesWidget,
    SchedulerWidget,
    SettingsWidget,
)
from app.gui.workers import GitHubValidationWorker
from app.logging import get_logger, setup_logger
from app.monitoring import HistoryStore, ReportGenerator, StatisticsEngine
from app.repository_manager import RepositoryManager
from app.scheduler import (
    ActivityScheduler,
    DailyRunner,
    SchedulerStatus,
    SchedulerStateManager,
)


class MainWindow(QMainWindow):
    """Main window controller providing sidebar navigation, page switching, and system wiring."""

    def __init__(
        self,
        config: AppConfig,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._config = config
        self._current_theme = "dark"

        # Initialize logging
        setup_logger(blocked_tokens=[self._config.github_token])
        self._logger = get_logger()

        # Initialize core stores
        self._store = HistoryStore()
        self._stats = StatisticsEngine(self._store)
        self._state_mgr = SchedulerStateManager()

        self.setWindowTitle("GitHub Activity Assistant")
        self.resize(1100, 720)
        self.setMinimumSize(900, 600)

        self._init_backend()
        self._setup_ui()
        self._apply_theme("dark")

        # Async validation
        self._validate_github_connection()

    def _init_backend(self) -> None:
        """Initialize domain engine instances."""
        self._validator = ActivityValidator(blocked_tokens=[self._config.github_token])

        # Client and Repo manager placeholder
        self._client = GitHubClient(
            token=self._config.github_token,
            default_repository=self._config.github_repositories[0],
        )
        self._repo_mgr = RepositoryManager(
            client=self._client,
            repositories=self._config.github_repositories,
        )

        self._planner = ActivityPlanner(
            repository_manager=self._repo_mgr,
            validator=self._validator,
            daily_target=self._config.daily_activity_target,
        )

        self._git_mgr = GitManager()
        self._commit_mgr = CommitManager(
            git_manager=self._git_mgr,
            validator=self._validator,
            local_base_path=self._config.local_repository_path,
            token=self._config.github_token,
        )

        self._runner = DailyRunner(
            planner=self._planner,
            commit_manager=self._commit_mgr,
            state_manager=self._state_mgr,
            target_count=self._config.daily_activity_target,
            timezone_name=self._config.timezone,
            min_interval_minutes=self._config.min_activity_interval_minutes,
            logger=self._logger,
        )

        self._scheduler = ActivityScheduler(
            daily_runner=self._runner,
            schedule_time_str=self._config.schedule_time,
            timezone_name=self._config.timezone,
            logger=self._logger,
        )

        self._report_gen = ReportGenerator(
            history_store=self._store,
            stats_engine=self._stats,
            default_output_dir=self._config.report_directory,
        )

    def _setup_ui(self) -> None:
        """Construct the main window layout."""
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        root_layout = QHBoxLayout(central_widget)
        root_layout.setSpacing(0)
        root_layout.setContentsMargins(0, 0, 0, 0)

        # 1. Left Sidebar Navigation
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setSpacing(4)
        sidebar_layout.setContentsMargins(8, 12, 8, 12)

        app_title = QLabel("GitHub Activity")
        app_title.setObjectName("AppTitle")
        app_sub = QLabel("Assistant v1.0.0")
        app_sub.setObjectName("AppSubtitle")
        sidebar_layout.addWidget(app_title)
        sidebar_layout.addWidget(app_sub)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        self.nav_items = [
            ("Dashboard", 0),
            ("Repositories", 1),
            ("Activity Plans", 2),
            ("Scheduler", 3),
            ("History", 4),
            ("Logs", 5),
            ("Reports", 6),
            ("Settings", 7),
        ]

        self.nav_buttons: list[QPushButton] = []
        for label, page_idx in self.nav_items:
            btn = QPushButton(f"  {label}")
            btn.setProperty("class", "NavButton")
            btn.setCheckable(True)
            if page_idx == 0:
                btn.setChecked(True)
            btn.clicked.connect(lambda _, idx=page_idx: self._switch_page(idx))
            self.nav_group.addButton(btn)
            sidebar_layout.addWidget(btn)
            self.nav_buttons.append(btn)

        sidebar_layout.addStretch()
        root_layout.addWidget(sidebar)

        # 2. Right Content Area
        content_pane = QWidget()
        content_pane.setObjectName("MainContent")
        content_layout = QVBoxLayout(content_pane)
        content_layout.setSpacing(0)
        content_layout.setContentsMargins(0, 0, 0, 0)

        # Top Header
        top_header = QFrame()
        top_header.setObjectName("TopHeader")
        header_layout = QHBoxLayout(top_header)
        header_layout.setContentsMargins(20, 0, 20, 0)

        self.header_title = QLabel("Dashboard")
        self.header_title.setObjectName("HeaderTitle")
        header_layout.addWidget(self.header_title)
        header_layout.addStretch()

        self.conn_badge = QLabel("Connecting...")
        self.conn_badge.setObjectName("StatusBadge")
        self.conn_badge.setProperty("connected", "false")
        header_layout.addWidget(self.conn_badge)
        content_layout.addWidget(top_header)

        # Center Stack of Pages
        self.stack = QStackedWidget()

        # Instantiate 8 Page Widgets
        self.page_dashboard = DashboardWidget(
            history_store=self._store,
            stats_engine=self._stats,
            state_manager=self._state_mgr,
            timezone_name=self._config.timezone,
            daily_target=self._config.daily_activity_target,
        )
        self.page_repos = RepositoriesWidget(
            repositories=self._config.github_repositories,
            local_base_path=self._config.local_repository_path,
            history_store=self._store,
            on_view_history=self._switch_to_history_for_repo,
        )
        self.page_activity = ActivityWidget(
            planner=self._planner,
            commit_manager=self._commit_mgr,
            daily_target=self._config.daily_activity_target,
        )
        self.page_scheduler = SchedulerWidget(
            scheduler=self._scheduler,
            daily_runner=self._runner,
            state_manager=self._state_mgr,
            schedule_time=self._config.schedule_time,
            timezone_name=self._config.timezone,
            daily_target=self._config.daily_activity_target,
        )
        self.page_history = HistoryWidget(
            history_store=self._store,
            repositories=self._config.github_repositories,
        )
        self.page_logs = LogsWidget()
        self.page_reports = ReportsWidget(
            report_generator=self._report_gen,
            history_store=self._store,
            output_dir=self._config.report_directory,
        )
        self.page_settings = SettingsWidget(
            config=self._config,
            on_theme_changed=self._apply_theme,
        )

        self.stack.addWidget(self.page_dashboard)
        self.stack.addWidget(self.page_repos)
        self.stack.addWidget(self.page_activity)
        self.stack.addWidget(self.page_scheduler)
        self.stack.addWidget(self.page_history)
        self.stack.addWidget(self.page_logs)
        self.stack.addWidget(self.page_reports)
        self.stack.addWidget(self.page_settings)

        content_layout.addWidget(self.stack)
        root_layout.addWidget(content_pane)

        # 3. Bottom Status Bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready. Initializing GitHub Assistant...")

    def _switch_page(self, page_index: int) -> None:
        """Switch current stacked widget page and update header title."""
        self.stack.setCurrentIndex(page_index)
        page_names = [
            "Dashboard",
            "Repositories",
            "Activity Planning",
            "Scheduler Control",
            "Activity History",
            "Audit Logs",
            "Reports Export",
            "Settings & Configuration",
        ]
        if 0 <= page_index < len(page_names):
            self.header_title.setText(page_names[page_index])

        # Refresh dashboard or history on display
        if page_index == 0:
            self.page_dashboard.refresh_data()
        elif page_index == 4:
            self.page_history.reload_history()

    def _switch_to_history_for_repo(self, repo_name: str) -> None:
        """Switch to history tab and set repository filter."""
        self._switch_page(4)
        self.nav_buttons[4].setChecked(True)
        idx = self.page_history.repo_combo.findText(repo_name)
        if idx >= 0:
            self.page_history.repo_combo.setCurrentIndex(idx)

    def _apply_theme(self, theme_name: str) -> None:
        """Apply theme QSS stylesheet across application."""
        self._current_theme = theme_name
        self.setStyleSheet(get_theme_qss(theme_name))

    def _validate_github_connection(self) -> None:
        """Run asynchronous GitHub token and repo validation worker."""
        self._auth_worker = GitHubValidationWorker(
            token=self._config.github_token,
            repositories=self._config.github_repositories,
        )
        self._auth_worker.success.connect(self._on_auth_success)
        self._auth_worker.failure.connect(self._on_auth_failure)
        self._auth_worker.start()

    def _on_auth_success(self, user_info: UserInfo, validated_repos: list[RepositoryInfo]) -> None:
        """Update connection badge and author information on successful validation."""
        self.conn_badge.setText(f"● Connected ({user_info.login})")
        self.conn_badge.setProperty("connected", "true")
        self.conn_badge.style().unpolish(self.conn_badge)
        self.conn_badge.style().polish(self.conn_badge)

        # Update commit author fallback
        author_name = user_info.name or user_info.login
        author_email = user_info.email or f"{user_info.login}@users.noreply.github.com"
        self._commit_mgr.author_name = author_name
        self._commit_mgr.author_email = author_email


        self.status_bar.showMessage(
            f"Connected to GitHub as {user_info.login} • {len(validated_repos)} repositories accessible"
        )

    def _on_auth_failure(self, error_message: str) -> None:
        """Update connection badge on auth error."""
        self.conn_badge.setText("● Offline (Auth Error)")
        self.conn_badge.setProperty("connected", "false")
        self.conn_badge.style().unpolish(self.conn_badge)
        self.conn_badge.style().polish(self.conn_badge)
        self.status_bar.showMessage(f"Authentication Error: {error_message}")

    def closeEvent(self, event: QCloseEvent) -> None:
        """Safely intercept window close event and stop scheduler if running."""
        state = self._state_mgr.load_state()
        if state and state.status == SchedulerStatus.RUNNING:
            confirm = ConfirmationDialog(
                title="Scheduler Running",
                message="The scheduler is currently active. Stop scheduler and exit?",
                is_danger=True,
                parent=self,
            )
            if confirm.exec() != ConfirmationDialog.DialogCode.Accepted:
                event.ignore()
                return

            if self._scheduler:
                self._scheduler.stop()

        event.accept()
