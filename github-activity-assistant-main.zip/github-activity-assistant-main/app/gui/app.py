"""Application entry point and QApplication lifecycle manager for desktop GUI."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import QApplication

from app.config import AppConfig, ConfigError, load_config
from app.gui.dialogs import FirstRunWizardDialog
from app.gui.main_window import MainWindow


def run_gui_app(custom_config: Optional[AppConfig] = None) -> int:
    """Initialize and run the PySide6 Desktop GUI Application.

    Args:
        custom_config: Optional pre-loaded AppConfig instance.

    Returns:
        Application exit code.
    """
    app = QApplication.instance()
    if not app:
        app = QApplication(sys.argv)

    app.setApplicationName("GitHub Activity Assistant")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("GitHubActivityAssistant")

    config = custom_config
    if not config:
        try:
            config = load_config()
        except ConfigError:
            # Show first run wizard if config is missing or invalid
            wizard = FirstRunWizardDialog()
            if wizard.exec() == FirstRunWizardDialog.DialogCode.Accepted:
                token = wizard.token_input.text().strip()
                repos = wizard.repos_input.text().strip()
                target = wizard.target_spin.value()
                schedule_time = wizard.schedule_input.text().strip()

                # Write initial .env file
                env_file = Path(".env")
                env_content = (
                    f"GITHUB_TOKEN={token}\n"
                    f"GITHUB_REPOSITORIES={repos}\n"
                    f"DAILY_ACTIVITY_TARGET={target}\n"
                    f"SCHEDULE_TIME={schedule_time}\n"
                    "TIMEZONE=Asia/Kolkata\n"
                    "SCHEDULER_ENABLED=false\n"
                    "MIN_ACTIVITY_INTERVAL_MINUTES=5\n"
                )
                env_file.write_text(env_content, encoding="utf-8")
                try:
                    config = load_config()
                except ConfigError as err:
                    print(f"Error loading configuration after wizard: {err}")
                    return 1
            else:
                return 0

    window = MainWindow(config=config)
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(run_gui_app())
