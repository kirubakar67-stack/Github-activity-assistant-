"""Theme and Qt Style Sheet (QSS) definitions for GitHub Activity Assistant Desktop GUI."""

from __future__ import annotations

DARK_THEME_QSS = """
/* ========================================================================= */
/*                              DARK THEME QSS                               */
/* ========================================================================= */

QMainWindow, QWidget#MainContent {
    background-color: #0F172A;
    color: #F8FAFC;
    font-family: "Segoe UI", -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
    font-size: 13px;
}

/* Sidebar Navigation */
QWidget#Sidebar {
    background-color: #1E293B;
    border-right: 1px solid #334155;
    min-width: 220px;
    max-width: 240px;
}

QLabel#AppTitle {
    font-size: 16px;
    font-weight: 700;
    color: #38BDF8;
    padding: 18px 12px 6px 12px;
}

QLabel#AppSubtitle {
    font-size: 11px;
    color: #94A3B8;
    padding: 0px 12px 14px 12px;
}

QPushButton.NavButton {
    background-color: transparent;
    color: #CBD5E1;
    text-align: left;
    padding: 10px 16px;
    border: none;
    border-radius: 6px;
    margin: 2px 8px;
    font-size: 13px;
    font-weight: 500;
}

QPushButton.NavButton:hover {
    background-color: #334155;
    color: #F8FAFC;
}

QPushButton.NavButton:checked, QPushButton.NavButton[active="true"] {
    background-color: #0284C7;
    color: #FFFFFF;
    font-weight: 600;
}

/* Top Header */
QFrame#TopHeader {
    background-color: #1E293B;
    border-bottom: 1px solid #334155;
    min-height: 52px;
    padding: 0 16px;
}

QLabel#HeaderTitle {
    font-size: 18px;
    font-weight: 600;
    color: #F8FAFC;
}

QLabel#StatusBadge {
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}

QLabel#StatusBadge[connected="true"] {
    background-color: #065F46;
    color: #34D399;
}

QLabel#StatusBadge[connected="false"] {
    background-color: #7F1D1D;
    color: #F87171;
}

/* Cards & Containers */
QFrame.Card {
    background-color: #1E293B;
    border: 1px solid #334155;
    border-radius: 8px;
    padding: 16px;
}

QFrame.StatCard {
    background-color: #1E293B;
    border: 1px solid #334155;
    border-radius: 8px;
    padding: 14px;
}

QLabel.StatValue {
    font-size: 26px;
    font-weight: 700;
    color: #38BDF8;
}

QLabel.StatLabel {
    font-size: 12px;
    color: #94A3B8;
    font-weight: 500;
    text-transform: uppercase;
}

/* Buttons */
QPushButton {
    background-color: #0284C7;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
    min-height: 20px;
}

QPushButton:hover {
    background-color: #0369A1;
}

QPushButton:pressed {
    background-color: #075985;
}

QPushButton:disabled {
    background-color: #334155;
    color: #64748B;
}

QPushButton.SecondaryButton {
    background-color: #334155;
    color: #F1F5F9;
    border: 1px solid #475569;
}

QPushButton.SecondaryButton:hover {
    background-color: #475569;
}

QPushButton.SuccessButton {
    background-color: #16A34A;
    color: #FFFFFF;
}

QPushButton.SuccessButton:hover {
    background-color: #15803D;
}

QPushButton.DangerButton {
    background-color: #DC2626;
    color: #FFFFFF;
}

QPushButton.DangerButton:hover {
    background-color: #B91C1C;
}

/* Input Fields */
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox, QDateEdit {
    background-color: #0F172A;
    color: #F8FAFC;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 8px;
    selection-background-color: #0284C7;
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QComboBox:focus, QDateEdit:focus {
    border: 1px solid #38BDF8;
}

QComboBox::drop-down {
    border: none;
    padding-right: 8px;
}

/* Tables */
QTableWidget, QTableView {
    background-color: #0F172A;
    color: #F8FAFC;
    border: 1px solid #334155;
    border-radius: 6px;
    gridline-color: #1E293B;
    selection-background-color: #0369A1;
    selection-color: #FFFFFF;
}

QHeaderView::section {
    background-color: #1E293B;
    color: #94A3B8;
    padding: 8px 10px;
    border: none;
    border-bottom: 1px solid #334155;
    border-right: 1px solid #334155;
    font-weight: 600;
    font-size: 12px;
}

/* Progress Bar */
QProgressBar {
    background-color: #0F172A;
    border: 1px solid #334155;
    border-radius: 6px;
    text-align: center;
    color: #F8FAFC;
    font-weight: 600;
    height: 18px;
}

QProgressBar::chunk {
    background-color: #0284C7;
    border-radius: 5px;
}

/* Scroll Bars */
QScrollBar:vertical {
    background: #0F172A;
    width: 8px;
    margin: 0;
}

QScrollBar::handle:vertical {
    background: #334155;
    min-height: 20px;
    border-radius: 4px;
}

QScrollBar::handle:vertical:hover {
    background: #475569;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

/* Bottom Status Bar */
QStatusBar {
    background-color: #1E293B;
    color: #94A3B8;
    border-top: 1px solid #334155;
    font-size: 12px;
}
"""

LIGHT_THEME_QSS = """
/* ========================================================================= */
/*                              LIGHT THEME QSS                              */
/* ========================================================================= */

QMainWindow, QWidget#MainContent {
    background-color: #F8FAFC;
    color: #0F172A;
    font-family: "Segoe UI", -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
    font-size: 13px;
}

QWidget#Sidebar {
    background-color: #F1F5F9;
    border-right: 1px solid #E2E8F0;
    min-width: 220px;
    max-width: 240px;
}

QLabel#AppTitle {
    font-size: 16px;
    font-weight: 700;
    color: #0284C7;
    padding: 18px 12px 6px 12px;
}

QLabel#AppSubtitle {
    font-size: 11px;
    color: #64748B;
    padding: 0px 12px 14px 12px;
}

QPushButton.NavButton {
    background-color: transparent;
    color: #475569;
    text-align: left;
    padding: 10px 16px;
    border: none;
    border-radius: 6px;
    margin: 2px 8px;
    font-size: 13px;
    font-weight: 500;
}

QPushButton.NavButton:hover {
    background-color: #E2E8F0;
    color: #0F172A;
}

QPushButton.NavButton:checked, QPushButton.NavButton[active="true"] {
    background-color: #0284C7;
    color: #FFFFFF;
    font-weight: 600;
}

QFrame#TopHeader {
    background-color: #FFFFFF;
    border-bottom: 1px solid #E2E8F0;
    min-height: 52px;
    padding: 0 16px;
}

QLabel#HeaderTitle {
    font-size: 18px;
    font-weight: 600;
    color: #0F172A;
}

QLabel#StatusBadge {
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}

QLabel#StatusBadge[connected="true"] {
    background-color: #D1FAE5;
    color: #065F46;
}

QLabel#StatusBadge[connected="false"] {
    background-color: #FEE2E2;
    color: #991B1B;
}

QFrame.Card {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 8px;
    padding: 16px;
}

QFrame.StatCard {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 8px;
    padding: 14px;
}

QLabel.StatValue {
    font-size: 26px;
    font-weight: 700;
    color: #0284C7;
}

QLabel.StatLabel {
    font-size: 12px;
    color: #64748B;
    font-weight: 500;
    text-transform: uppercase;
}

QPushButton {
    background-color: #0284C7;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
    min-height: 20px;
}

QPushButton:hover {
    background-color: #0369A1;
}

QPushButton.SecondaryButton {
    background-color: #E2E8F0;
    color: #1E293B;
    border: 1px solid #CBD5E1;
}

QPushButton.SecondaryButton:hover {
    background-color: #CBD5E1;
}

QPushButton.SuccessButton {
    background-color: #16A34A;
    color: #FFFFFF;
}

QPushButton.SuccessButton:hover {
    background-color: #15803D;
}

QPushButton.DangerButton {
    background-color: #DC2626;
    color: #FFFFFF;
}

QPushButton.DangerButton:hover {
    background-color: #B91C1C;
}

QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox, QDateEdit {
    background-color: #FFFFFF;
    color: #0F172A;
    border: 1px solid #CBD5E1;
    border-radius: 6px;
    padding: 8px;
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QComboBox:focus, QDateEdit:focus {
    border: 1px solid #0284C7;
}

QTableWidget, QTableView {
    background-color: #FFFFFF;
    color: #0F172A;
    border: 1px solid #E2E8F0;
    border-radius: 6px;
    gridline-color: #F1F5F9;
    selection-background-color: #E0F2FE;
    selection-color: #0369A1;
}

QHeaderView::section {
    background-color: #F8FAFC;
    color: #64748B;
    padding: 8px 10px;
    border: none;
    border-bottom: 1px solid #E2E8F0;
    border-right: 1px solid #E2E8F0;
    font-weight: 600;
    font-size: 12px;
}

QProgressBar {
    background-color: #E2E8F0;
    border: 1px solid #CBD5E1;
    border-radius: 6px;
    text-align: center;
    color: #0F172A;
    font-weight: 600;
    height: 18px;
}

QProgressBar::chunk {
    background-color: #0284C7;
    border-radius: 5px;
}

QStatusBar {
    background-color: #F1F5F9;
    color: #64748B;
    border-top: 1px solid #E2E8F0;
    font-size: 12px;
}
"""


def get_theme_qss(theme_name: str = "dark") -> str:
    """Retrieve QSS stylesheet string for the requested theme.

    Args:
        theme_name: 'dark' or 'light'.

    Returns:
        Theme CSS/QSS string.
    """
    if theme_name.lower() == "light":
        return LIGHT_THEME_QSS
    return DARK_THEME_QSS
