"""Modal dialogs for user confirmations, activity diff preview, and initial setup."""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.activity.models import ActivityPlan


class ConfirmationDialog(QDialog):
    """Clean confirmation dialog for critical or automated user actions."""

    def __init__(
        self,
        title: str,
        message: str,
        detail_text: str = "",
        is_danger: bool = False,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(440)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 20, 20, 20)

        msg_label = QLabel(message)
        msg_label.setWordWrap(True)
        msg_label.setStyleSheet("font-size: 14px; font-weight: 600;")
        layout.addWidget(msg_label)

        if detail_text:
            detail_label = QLabel(detail_text)
            detail_label.setWordWrap(True)
            detail_label.setStyleSheet("color: #94A3B8; font-size: 12px;")
            layout.addWidget(detail_label)

        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Ok
        )
        ok_btn = btn_box.button(QDialogButtonBox.StandardButton.Ok)
        ok_btn.setText("Proceed")
        if is_danger:
            ok_btn.setProperty("class", "DangerButton")
        else:
            ok_btn.setProperty("class", "SuccessButton")

        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)


class ActivityPreviewDialog(QDialog):
    """Detailed visual inspection dialog for proposed activity plans and file diffs."""

    def __init__(
        self,
        plan: ActivityPlan,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"Activity Preview — {plan.title}")
        self.resize(680, 520)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        # Header details
        form = QFormLayout()
        form.setSpacing(8)

        repo_val = QLabel(plan.repository)
        repo_val.setStyleSheet("font-weight: 600; color: #38BDF8;")
        form.addRow("Repository:", repo_val)

        type_val = QLabel(plan.activity_type.value.replace("_", " ").title())
        form.addRow("Activity Type:", type_val)

        file_val = QLabel(plan.target_file)
        file_val.setStyleSheet("font-family: monospace; color: #34D399;")
        form.addRow("Target File:", file_val)

        title_val = QLabel(plan.title)
        form.addRow("Title:", title_val)

        desc_val = QLabel(plan.description)
        desc_val.setWordWrap(True)
        form.addRow("Description:", desc_val)

        layout.addLayout(form)

        # Proposed Content Preview
        content_label = QLabel("Proposed File Content:")
        content_label.setStyleSheet("font-weight: 600; margin-top: 6px;")
        layout.addWidget(content_label)

        text_preview = QPlainTextEdit()
        text_preview.setReadOnly(True)
        text_preview.setPlainText(plan.proposed_content)
        text_preview.setStyleSheet(
            "font-family: 'Consolas', 'Courier New', monospace; font-size: 12px;"
        )
        layout.addWidget(text_preview)

        # Bottom buttons
        btn_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)


class FirstRunWizardDialog(QDialog):
    """Initial environment setup wizard dialog."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Welcome to GitHub Activity Assistant")
        self.setMinimumWidth(500)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)

        title = QLabel("Initial Configuration Setup")
        title.setStyleSheet("font-size: 16px; font-weight: 700; color: #38BDF8;")
        layout.addWidget(title)

        intro = QLabel(
            "Please configure your GitHub Personal Access Token and target repositories "
            "to get started."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        form = QFormLayout()
        form.setSpacing(10)

        self.token_input = QLineEdit()
        self.token_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.token_input.setPlaceholderText("ghp_...")
        form.addRow("GitHub Token:", self.token_input)

        self.repos_input = QLineEdit()
        self.repos_input.setPlaceholderText("owner/repo1, owner/repo2")
        form.addRow("Repositories:", self.repos_input)

        self.target_spin = QSpinBox()
        self.target_spin.setRange(1, 20)
        self.target_spin.setValue(5)
        form.addRow("Daily Target:", self.target_spin)

        self.schedule_input = QLineEdit()
        self.schedule_input.setText("18:00")
        form.addRow("Schedule Time:", self.schedule_input)

        layout.addLayout(form)

        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Save
        )
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)
