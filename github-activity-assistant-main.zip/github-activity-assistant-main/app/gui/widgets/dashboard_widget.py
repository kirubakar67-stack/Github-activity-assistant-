"""Dashboard page widget for desktop GUI."""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app.monitoring.history_store import HistoryStore
from app.monitoring.statistics import StatisticsEngine
from app.scheduler.state import SchedulerStateManager


class DashboardWidget(QWidget):
    """Visual overview page displaying progress, scheduler state, repo cards, calendar, and logs."""

    def __init__(
        self,
        history_store: Optional[HistoryStore] = None,
        stats_engine: Optional[StatisticsEngine] = None,
        state_manager: Optional[SchedulerStateManager] = None,
        timezone_name: str = "Asia/Kolkata",
        daily_target: int = 5,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._store = history_store or HistoryStore()
        self._stats = stats_engine or StatisticsEngine(self._store)
        self._state_mgr = state_manager or SchedulerStateManager()
        self._tz_name = timezone_name
        self._target = daily_target

        self._setup_ui()
        self.refresh_data()

    def _setup_ui(self) -> None:
        """Construct dashboard widget layout."""
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        container = QWidget()
        self.main_layout = QVBoxLayout(container)
        self.main_layout.setSpacing(16)
        self.main_layout.setContentsMargins(20, 20, 20, 20)

        # Top stat cards row
        stat_row = QHBoxLayout()
        stat_row.setSpacing(14)

        self.card_completed = self._create_stat_card("Completed Today", "0", "#34D399")
        self.card_target = self._create_stat_card("Daily Target", str(self._target), "#38BDF8")
        self.card_remaining = self._create_stat_card("Remaining", "0", "#FBBF24")
        self.card_success_rate = self._create_stat_card("Success Rate", "100%", "#A78BFA")

        stat_row.addWidget(self.card_completed)
        stat_row.addWidget(self.card_target)
        stat_row.addWidget(self.card_remaining)
        stat_row.addWidget(self.card_success_rate)
        self.main_layout.addLayout(stat_row)

        # Progress bar card
        prog_card = QFrame()
        prog_card.setProperty("class", "Card")
        prog_layout = QVBoxLayout(prog_card)
        prog_layout.setSpacing(8)

        prog_header = QHBoxLayout()
        prog_title = QLabel("Today's Daily Progress")
        prog_title.setStyleSheet("font-weight: 600; font-size: 14px;")
        self.prog_pct_label = QLabel("0.0%")
        self.prog_pct_label.setStyleSheet("font-weight: 700; color: #38BDF8;")
        prog_header.addWidget(prog_title)
        prog_header.addStretch()
        prog_header.addWidget(self.prog_pct_label)
        prog_layout.addLayout(prog_header)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        prog_layout.addWidget(self.progress_bar)

        self.main_layout.addWidget(prog_card)

        # Middle row: Repositories + Activity Calendar
        mid_row = QHBoxLayout()
        mid_row.setSpacing(14)

        # Left: Repositories distribution card
        self.repo_card = QFrame()
        self.repo_card.setProperty("class", "Card")
        self.repo_layout = QVBoxLayout(self.repo_card)
        repo_title = QLabel("Repository Distribution")
        repo_title.setStyleSheet("font-weight: 600; font-size: 14px; margin-bottom: 6px;")
        self.repo_layout.addWidget(repo_title)
        self.repo_list_layout = QVBoxLayout()
        self.repo_layout.addLayout(self.repo_list_layout)
        self.repo_layout.addStretch()
        mid_row.addWidget(self.repo_card, stretch=1)

        # Right: Activity Calendar Card
        cal_card = QFrame()
        cal_card.setProperty("class", "Card")
        cal_layout = QVBoxLayout(cal_card)
        cal_title = QLabel("Application Activity Calendar (Last 4 Weeks)")
        cal_title.setStyleSheet("font-weight: 600; font-size: 14px; margin-bottom: 6px;")
        cal_layout.addWidget(cal_title)

        self.cal_grid = QGridLayout()
        self.cal_grid.setSpacing(4)
        cal_layout.addLayout(self.cal_grid)
        cal_layout.addStretch()
        mid_row.addWidget(cal_card, stretch=1)

        self.main_layout.addLayout(mid_row)

        # Bottom: Recent Activities Card
        recent_card = QFrame()
        recent_card.setProperty("class", "Card")
        self.recent_layout = QVBoxLayout(recent_card)
        recent_title = QLabel("Recent Recorded Activities")
        recent_title.setStyleSheet("font-weight: 600; font-size: 14px; margin-bottom: 6px;")
        self.recent_layout.addWidget(recent_title)
        self.recent_list_layout = QVBoxLayout()
        self.recent_layout.addLayout(self.recent_list_layout)

        self.main_layout.addWidget(recent_card)

        # Refresh action button
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        refresh_btn = QPushButton("Refresh Dashboard")
        refresh_btn.setProperty("class", "SecondaryButton")
        refresh_btn.clicked.connect(self.refresh_data)
        btn_row.addWidget(refresh_btn)
        self.main_layout.addLayout(btn_row)

        scroll.setWidget(container)
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.addWidget(scroll)

    def _create_stat_card(self, title: str, initial_value: str, color_hex: str) -> QFrame:
        """Create a styled statistical KPI card."""
        card = QFrame()
        card.setProperty("class", "StatCard")
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(4)

        val_label = QLabel(initial_value)
        val_label.setProperty("class", "StatValue")
        val_label.setStyleSheet(f"color: {color_hex}; font-size: 24px; font-weight: 700;")

        title_label = QLabel(title)
        title_label.setProperty("class", "StatLabel")

        card_layout.addWidget(val_label)
        card_layout.addWidget(title_label)
        card.val_label = val_label  # type: ignore
        return card

    def refresh_data(self) -> None:
        """Reload and refresh all dashboard metrics from the history store and state."""
        try:
            tz = ZoneInfo(self._tz_name)
        except Exception:
            tz = ZoneInfo("UTC")

        today_str = datetime.now(tz).strftime("%Y-%m-%d")
        progress = self._stats.get_daily_progress(date_str=today_str, target=self._target)
        summary = self._stats.get_summary_statistics()

        # Update KPI cards
        self.card_completed.val_label.setText(str(progress["completed"]))  # type: ignore
        self.card_target.val_label.setText(str(progress["target"]))        # type: ignore
        self.card_remaining.val_label.setText(str(progress["remaining"]))    # type: ignore
        self.card_success_rate.val_label.setText(f"{summary['success_rate']:.1f}%")  # type: ignore

        # Update Progress Bar
        pct = progress["progress_percent"]
        self.progress_bar.setValue(int(pct))
        self.prog_pct_label.setText(f"{pct:.1f}% ({progress['completed']}/{progress['target']})")

        # Update Repositories list
        while self.repo_list_layout.count():
            item = self.repo_list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        repo_stats = summary.get("repository_breakdown", {})
        if repo_stats:
            for repo, r_data in repo_stats.items():
                repo_short = repo.split("/")[-1] if "/" in repo else repo
                row = QLabel(
                    f"• {repo_short:<22}  {r_data['total']} activities  ({r_data['success_rate']:.0f}% success)"
                )
                row.setStyleSheet("font-family: monospace; font-size: 12px; color: #CBD5E1;")
                self.repo_list_layout.addWidget(row)
        else:
            self.repo_list_layout.addWidget(QLabel("No repository activity recorded yet."))

        # Update Calendar Grid
        while self.cal_grid.count():
            item = self.cal_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        day_headers = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for col, h in enumerate(day_headers):
            lbl = QLabel(h)
            lbl.setStyleSheet("font-size: 11px; font-weight: 600; color: #94A3B8; alignment: center;")
            self.cal_grid.addWidget(lbl, 0, col, Qt.AlignmentFlag.AlignCenter)

        days = self._stats.get_calendar_data(weeks=4, timezone_name=self._tz_name)
        for idx, d in enumerate(days):
            row = (idx // 7) + 1
            col = idx % 7
            chip = QLabel()
            chip.setFixedSize(22, 22)
            chip.setAlignment(Qt.AlignmentFlag.AlignCenter)

            if d.get("is_future"):
                chip.setStyleSheet("background-color: #1E293B; border-radius: 4px;")
            elif d.get("has_activity"):
                count = d.get("activity_count", 1)
                bg = "#10B981" if count >= 3 else "#34D399"
                chip.setStyleSheet(
                    f"background-color: {bg}; border-radius: 4px; color: #064E3B; font-weight: 700; font-size: 10px;"
                )
                chip.setText(str(count))
            else:
                chip.setStyleSheet("background-color: #334155; border-radius: 4px;")

            chip.setToolTip(f"{d['date']}: {d.get('activity_count', 0)} activities")
            self.cal_grid.addWidget(chip, row, col, Qt.AlignmentFlag.AlignCenter)

        # Update Recent Activities
        while self.recent_list_layout.count():
            item = self.recent_list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        recent = self._store.get_recent_activities(limit=5)
        if recent:
            for r in recent:
                timestamp_str = r.timestamp[11:16] if r.timestamp and len(r.timestamp) >= 16 else "--:--"
                repo_short = r.repository.split("/")[-1] if "/" in r.repository else (r.repository or "unknown")
                c_hash = f"[{r.commit_hash[:7]}]" if r.commit_hash else "[DRY_RUN]"
                status_color = "#34D399" if "commit" in r.status or "success" in r.status else "#F87171"
                row = QLabel(
                    f"<b>{timestamp_str}</b>  {repo_short:<16}  {r.title:<35}  "
                    f"<span style='color: {status_color}; font-weight: bold;'>{r.status.upper()}</span> {c_hash}"
                )
                row.setTextFormat(Qt.TextFormat.RichText)
                row.setStyleSheet("font-family: monospace; font-size: 12px; padding: 2px 0;")
                self.recent_list_layout.addWidget(row)
        else:
            self.recent_list_layout.addWidget(QLabel("No recent activities recorded."))
