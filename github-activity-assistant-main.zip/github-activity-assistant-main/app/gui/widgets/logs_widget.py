"""Live log inspection page widget for desktop GUI."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

DEFAULT_LOG_FILE: Path = Path("logs") / "assistant.log"


class LogsWidget(QWidget):
    """Real-time log viewer reading logs/assistant.log with search and level filters."""

    def __init__(
        self,
        log_file: Optional[Path | str] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._log_file = Path(log_file or DEFAULT_LOG_FILE)

        self._setup_ui()

        # Auto refresh timer every 2 seconds
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.reload_logs)
        self._timer.start(2000)

        self.reload_logs()

    def _setup_ui(self) -> None:
        """Build logs viewer layout."""
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        # Controls bar
        ctrl_card = QFrame()
        ctrl_card.setProperty("class", "Card")
        ctrl_layout = QHBoxLayout(ctrl_card)
        ctrl_layout.setSpacing(10)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Filter logs by text...")
        self.search_input.textChanged.connect(self._render_filtered_logs)
        ctrl_layout.addWidget(self.search_input, stretch=2)

        self.level_combo = QComboBox()
        self.level_combo.addItems(["ALL LEVELS", "INFO", "WARNING", "ERROR"])
        self.level_combo.currentIndexChanged.connect(self._render_filtered_logs)
        ctrl_layout.addWidget(self.level_combo, stretch=1)

        self.auto_scroll_check = QCheckBox("Auto-scroll")
        self.auto_scroll_check.setChecked(True)
        ctrl_layout.addWidget(self.auto_scroll_check)

        refresh_btn = QPushButton("Refresh")
        refresh_btn.setProperty("class", "SecondaryButton")
        refresh_btn.clicked.connect(self.reload_logs)
        ctrl_layout.addWidget(refresh_btn)

        open_btn = QPushButton("Open File")
        open_btn.setProperty("class", "SecondaryButton")
        open_btn.clicked.connect(self._open_log_file)
        ctrl_layout.addWidget(open_btn)

        layout.addWidget(ctrl_card)

        # Log content text edit
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setStyleSheet(
            "font-family: 'Consolas', 'Courier New', monospace; font-size: 12px; background-color: #0F172A; color: #E2E8F0;"
        )
        layout.addWidget(self.log_view)

    def reload_logs(self) -> None:
        """Read log file and apply filters."""
        if not self._log_file.exists():
            self._raw_lines = ["(No log records found yet in logs/assistant.log)"]
        else:
            try:
                content = self._log_file.read_text(encoding="utf-8", errors="replace")
                self._raw_lines = content.splitlines()
            except Exception as exc:
                self._raw_lines = [f"(Error reading log file: {exc})"]

        self._render_filtered_logs()

    def _render_filtered_logs(self) -> None:
        """Filter log lines based on search text and selected level."""
        search_txt = self.search_input.text().strip().lower()
        level = self.level_combo.currentText()

        filtered: list[str] = []
        for line in self._raw_lines:
            if level != "ALL LEVELS" and f"[{level}]" not in line and level not in line:
                continue
            if search_txt and search_txt not in line.lower():
                continue
            filtered.append(line)

        self.log_view.setPlainText("\n".join(filtered))

        if self.auto_scroll_check.isChecked():
            scrollbar = self.log_view.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())

    def _open_log_file(self) -> None:
        """Open log file in system text editor."""
        if self._log_file.exists():
            if os.name == "nt":
                os.startfile(str(self._log_file.resolve()))
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._log_file.resolve())))
