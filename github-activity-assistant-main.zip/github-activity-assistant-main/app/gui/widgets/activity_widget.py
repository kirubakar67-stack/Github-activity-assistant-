"""Activity planning and execution page widget for desktop GUI."""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.activity.models import ActivityPlan
from app.activity.planner import ActivityPlanner
from app.activity.validator import ActivityValidator
from app.git.commit_manager import CommitManager, CommitResult
from app.gui.dialogs import ActivityPreviewDialog, ConfirmationDialog
from app.gui.workers import ActivityExecutionWorker, ActivityPlanWorker


class ActivityWidget(QWidget):
    """Activity planning, diff inspection, validation, and controlled execution page."""

    def __init__(
        self,
        planner: Optional[ActivityPlanner] = None,
        commit_manager: Optional[CommitManager] = None,
        daily_target: int = 5,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._planner = planner
        self._commit_mgr = commit_manager
        self._target = daily_target
        self._current_plans: list[ActivityPlan] = []
        self._plan_worker: Optional[ActivityPlanWorker] = None
        self._exec_worker: Optional[ActivityExecutionWorker] = None

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Construct activity widget layout."""
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 20, 20, 20)

        # Header controls
        header_card = QFrame()
        header_card.setProperty("class", "Card")
        header_layout = QHBoxLayout(header_card)

        target_lbl = QLabel("Daily Target Count:")
        target_lbl.setStyleSheet("font-weight: 600;")
        header_layout.addWidget(target_lbl)

        self.target_spin = QSpinBox()
        self.target_spin.setRange(1, 20)
        self.target_spin.setValue(self._target)
        header_layout.addWidget(self.target_spin)

        self.generate_btn = QPushButton("Generate Plans")
        self.generate_btn.clicked.connect(self._on_generate_plans)
        header_layout.addWidget(self.generate_btn)

        header_layout.addStretch()

        self.preview_btn = QPushButton("Preview Selected")
        self.preview_btn.setProperty("class", "SecondaryButton")
        self.preview_btn.setEnabled(False)
        self.preview_btn.clicked.connect(self._on_preview_selected)
        header_layout.addWidget(self.preview_btn)

        layout.addWidget(header_card)

        # Plans table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(
            ["Repository", "Activity Type", "Target File", "Title", "Validation"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.itemSelectionChanged.connect(self._on_table_selection_changed)
        self.table.cellDoubleClicked.connect(lambda row, col: self._on_preview_selected())
        layout.addWidget(self.table)

        # Execution Progress & Status
        self.status_lbl = QLabel("Ready. Click 'Generate Plans' to plan daily activities.")
        self.status_lbl.setStyleSheet("color: #94A3B8; font-size: 12px;")
        layout.addWidget(self.status_lbl)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        # Action Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        self.dry_run_btn = QPushButton("Execute (Dry Run)")
        self.dry_run_btn.setProperty("class", "SecondaryButton")
        self.dry_run_btn.setEnabled(False)
        self.dry_run_btn.clicked.connect(lambda: self._on_execute(dry_run=True))
        btn_row.addWidget(self.dry_run_btn)

        self.commit_btn = QPushButton("Execute & Commit")
        self.commit_btn.setProperty("class", "SuccessButton")
        self.commit_btn.setEnabled(False)
        self.commit_btn.clicked.connect(lambda: self._on_execute(dry_run=False))
        btn_row.addWidget(self.commit_btn)

        layout.addLayout(btn_row)

    def _on_generate_plans(self) -> None:
        """Trigger background planning worker."""
        if not self._planner:
            QMessageBox.warning(self, "Planner Not Initialized", "Activity planner is not configured.")
            return

        self.generate_btn.setEnabled(False)
        self.status_lbl.setText("Generating and validating daily activity plans...")

        self._plan_worker = ActivityPlanWorker(
            planner=self._planner,
            target_count=self.target_spin.value(),
        )
        self._plan_worker.success.connect(self._on_plans_generated)
        self._plan_worker.failure.connect(self._on_plans_failed)
        self._plan_worker.start()

    def _on_plans_generated(self, plans: list[ActivityPlan]) -> None:
        """Populate plans table with generated results."""
        self.generate_btn.setEnabled(True)
        self._current_plans = plans
        self.table.setRowCount(len(plans))

        for row, plan in enumerate(plans):
            self.table.setItem(row, 0, QTableWidgetItem(plan.repository))
            self.table.setItem(
                row, 1, QTableWidgetItem(plan.activity_type.value.replace("_", " ").title())
            )
            self.table.setItem(row, 2, QTableWidgetItem(plan.target_file))
            self.table.setItem(row, 3, QTableWidgetItem(plan.title))

            val_item = QTableWidgetItem("Valid [✓]")
            val_item.setForeground(Qt.GlobalColor.green)
            self.table.setItem(row, 4, val_item)

        self.status_lbl.setText(f"Generated {len(plans)} validated activity plans.")
        has_plans = len(plans) > 0
        self.dry_run_btn.setEnabled(has_plans)
        self.commit_btn.setEnabled(has_plans)

    def _on_plans_failed(self, error: str) -> None:
        """Handle plan generation failure."""
        self.generate_btn.setEnabled(True)
        self.status_lbl.setText(f"Plan generation failed: {error}")
        QMessageBox.critical(self, "Plan Generation Error", error)

    def _on_table_selection_changed(self) -> None:
        """Enable preview button if row selected."""
        self.preview_btn.setEnabled(len(self.table.selectedItems()) > 0)

    def _on_preview_selected(self) -> None:
        """Open ActivityPreviewDialog for selected row."""
        row = self.table.currentRow()
        if 0 <= row < len(self._current_plans):
            plan = self._current_plans[row]
            dlg = ActivityPreviewDialog(plan=plan, parent=self)
            dlg.exec()

    def _on_execute(self, dry_run: bool) -> None:
        """Execute plans with background worker."""
        if not self._commit_mgr or not self._current_plans:
            return

        if not dry_run:
            confirm = ConfirmationDialog(
                title="Confirm Local Git Commits",
                message=f"Execute {len(self._current_plans)} planned activities and create local Git commits?",
                detail_text="Local commits will be created in ./repositories/. No push to GitHub will be performed.",
                parent=self,
            )
            if confirm.exec() != ConfirmationDialog.DialogCode.Accepted:
                return

        self.dry_run_btn.setEnabled(False)
        self.commit_btn.setEnabled(False)
        self.generate_btn.setEnabled(False)

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        mode_str = "Preview Dry Run" if dry_run else "Local Commits"
        self.status_lbl.setText(f"Executing activities ({mode_str})...")

        self._exec_worker = ActivityExecutionWorker(
            commit_manager=self._commit_mgr,
            plans=self._current_plans,
            dry_run=dry_run,
        )
        self._exec_worker.step_progress.connect(self._on_exec_step)
        self._exec_worker.finished.connect(self._on_exec_finished)
        self._exec_worker.failure.connect(self._on_exec_error)
        self._exec_worker.start()

    def _on_exec_step(self, current: int, total: int, plan: ActivityPlan, res: CommitResult) -> None:
        """Update progress bar on each executed activity."""
        pct = int((current / total) * 100)
        self.progress_bar.setValue(pct)
        c_str = f"Commit {res.commit_hash[:7]}" if res.commit_hash else "Success"
        self.status_lbl.setText(f"Executed {current}/{total}: {plan.repository} ({c_str})")

    def _on_exec_finished(self, completed: int, failed: int, results: list[CommitResult]) -> None:
        """Handle execution completion."""
        self.dry_run_btn.setEnabled(True)
        self.commit_btn.setEnabled(True)
        self.generate_btn.setEnabled(True)
        self.progress_bar.setValue(100)
        self.status_lbl.setText(f"Execution complete: {completed} completed, {failed} failed.")

        if failed > 0:
            failed_msgs = [f"• {r.repository}: {r.error_message}" for r in results if not r.success]
            detail_msg = "\n".join(failed_msgs)
            QMessageBox.warning(
                self,
                "Execution Completed with Failures",
                f"Completed: {completed}\nFailed: {failed}\n\nFailure Details:\n{detail_msg}",
            )
        else:
            QMessageBox.information(
                self,
                "Execution Successful",
                f"Successfully completed {completed} activity plan(s) and created local Git commits!",
            )


    def _on_exec_error(self, error: str) -> None:
        """Handle execution worker error."""
        self.dry_run_btn.setEnabled(True)
        self.commit_btn.setEnabled(True)
        self.generate_btn.setEnabled(True)
        self.status_lbl.setText(f"Execution error: {error}")
        QMessageBox.critical(self, "Execution Error", error)
