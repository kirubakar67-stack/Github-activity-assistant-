"""Settings and configuration page widget for desktop GUI."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Optional
from zoneinfo import ZoneInfo

from PySide6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.config import AppConfig, ConfigError, validate_repository_name


class SettingsWidget(QWidget):
    """Configuration management page allowing safe updates to environment settings."""

    def __init__(
        self,
        config: AppConfig,
        on_theme_changed: Optional[Callable[[str], None]] = None,
        on_config_saved: Optional[Callable[[AppConfig], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._config = config
        self._on_theme_changed = on_theme_changed
        self._on_config_saved = on_config_saved

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Construct settings form layout."""
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(16)
        layout.setContentsMargins(20, 20, 20, 20)

        # 1. GitHub Authentication Card
        auth_card = QFrame()
        auth_card.setProperty("class", "Card")
        auth_layout = QVBoxLayout(auth_card)
        auth_title = QLabel("GitHub Authentication")
        auth_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #38BDF8;")
        auth_layout.addWidget(auth_title)

        auth_form = QFormLayout()
        auth_form.setSpacing(10)

        token_status = QLabel("Token Configured: YES [✓]")
        token_status.setStyleSheet("color: #34D399; font-weight: 600;")
        auth_form.addRow("Current Status:", token_status)

        self.token_input = QLineEdit()
        self.token_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.token_input.setPlaceholderText("Enter new token to replace (leave blank to keep current)")
        auth_form.addRow("Update Token:", self.token_input)

        auth_layout.addLayout(auth_form)
        layout.addWidget(auth_card)

        # 2. Managed Repositories Card
        repo_card = QFrame()
        repo_card.setProperty("class", "Card")
        repo_layout = QVBoxLayout(repo_card)
        repo_title = QLabel("Managed Repositories")
        repo_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #38BDF8;")
        repo_layout.addWidget(repo_title)

        repo_form = QFormLayout()
        self.repos_input = QLineEdit()
        self.repos_input.setText(", ".join(self._config.github_repositories))
        repo_form.addRow("Repositories (comma-separated):", self.repos_input)
        repo_layout.addLayout(repo_form)
        layout.addWidget(repo_card)

        # 3. Scheduler & Automation Settings Card
        sched_card = QFrame()
        sched_card.setProperty("class", "Card")
        sched_layout = QVBoxLayout(sched_card)
        sched_title = QLabel("Scheduler & Automation Parameters")
        sched_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #38BDF8;")
        sched_layout.addWidget(sched_title)

        sched_form = QFormLayout()
        sched_form.setSpacing(10)

        self.target_spin = QSpinBox()
        self.target_spin.setRange(1, 20)
        self.target_spin.setValue(self._config.daily_activity_target)
        sched_form.addRow("Daily Activity Target:", self.target_spin)

        self.schedule_time_input = QLineEdit()
        self.schedule_time_input.setText(self._config.schedule_time)
        sched_form.addRow("Schedule Time (HH:MM):", self.schedule_time_input)

        self.timezone_combo = QComboBox()
        common_timezones = [
            "Asia/Kolkata",
            "UTC",
            "America/New_York",
            "America/Los_Angeles",
            "America/Chicago",
            "Europe/London",
            "Europe/Paris",
            "Asia/Tokyo",
            "Asia/Singapore",
            "Australia/Sydney",
        ]
        if self._config.timezone not in common_timezones:
            common_timezones.insert(0, self._config.timezone)
        self.timezone_combo.addItems(common_timezones)
        self.timezone_combo.setCurrentText(self._config.timezone)
        sched_form.addRow("Timezone:", self.timezone_combo)

        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(0, 1440)
        self.interval_spin.setValue(self._config.min_activity_interval_minutes)
        sched_form.addRow("Min Activity Interval (min):", self.interval_spin)

        sched_layout.addLayout(sched_form)
        layout.addWidget(sched_card)

        # 4. Appearance Card
        app_card = QFrame()
        app_card.setProperty("class", "Card")
        app_layout = QVBoxLayout(app_card)
        app_title = QLabel("Appearance & Theme")
        app_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #38BDF8;")
        app_layout.addWidget(app_title)

        app_form = QFormLayout()
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Dark Theme", "Light Theme"])
        self.theme_combo.currentIndexChanged.connect(self._on_theme_selection)
        app_form.addRow("Interface Theme:", self.theme_combo)
        app_layout.addLayout(app_form)
        layout.addWidget(app_card)

        # Bottom Save Action
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        save_btn = QPushButton("Save Settings")
        save_btn.setProperty("class", "SuccessButton")
        save_btn.clicked.connect(self._on_save_settings)
        btn_row.addWidget(save_btn)

        layout.addLayout(btn_row)

        scroll.setWidget(container)
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.addWidget(scroll)

    def _on_theme_selection(self, idx: int) -> None:
        """Propagate theme change to main window."""
        theme_name = "dark" if idx == 0 else "light"
        if self._on_theme_changed:
            self._on_theme_changed(theme_name)

    def _on_save_settings(self) -> None:
        """Validate inputs and write updates safely to .env file."""
        new_token = self.token_input.text().strip()
        final_token = new_token if new_token else self._config.github_token

        raw_repos = [r.strip() for r in self.repos_input.text().split(",") if r.strip()]
        if not raw_repos:
            QMessageBox.critical(self, "Invalid Configuration", "Please provide at least one valid repository.")
            return

        for repo in raw_repos:
            if not validate_repository_name(repo):
                QMessageBox.critical(
                    self,
                    "Invalid Repository Format",
                    f"Repository '{repo}' is invalid. Must be in 'owner/repo' format.",
                )
                return

        time_str = self.schedule_time_input.text().strip()
        tz_str = self.timezone_combo.currentText()
        target_val = self.target_spin.value()
        interval_val = self.interval_spin.value()

        # Update .env file safely
        env_file = Path(".env")
        env_lines: list[str] = []
        if env_file.exists():
            env_lines = env_file.read_text(encoding="utf-8").splitlines()

        updated_keys = {
            "GITHUB_REPOSITORIES": ", ".join(raw_repos),
            "DAILY_ACTIVITY_TARGET": str(target_val),
            "SCHEDULE_TIME": time_str,
            "TIMEZONE": tz_str,
            "MIN_ACTIVITY_INTERVAL_MINUTES": str(interval_val),
        }
        if new_token:
            updated_keys["GITHUB_TOKEN"] = new_token

        new_env_lines: list[str] = []
        seen_keys: set[str] = set()

        for line in env_lines:
            if "=" in line and not line.strip().startswith("#"):
                key = line.split("=", 1)[0].strip()
                if key in updated_keys:
                    new_env_lines.append(f"{key}={updated_keys[key]}")
                    seen_keys.add(key)
                    continue
            new_env_lines.append(line)

        for key, val in updated_keys.items():
            if key not in seen_keys:
                new_env_lines.append(f"{key}={val}")

        env_file.write_text("\n".join(new_env_lines) + "\n", encoding="utf-8")

        self.token_input.clear()
        QMessageBox.information(
            self,
            "Settings Saved",
            "Configuration settings saved successfully to .env.",
        )
