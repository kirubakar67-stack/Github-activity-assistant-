"""Scheduler management and control page widget for desktop GUI."""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.gui.dialogs import ConfirmationDialog
from app.scheduler.daily_runner import DailyRunner
from app.scheduler.scheduler import ActivityScheduler
from app.scheduler.state import SchedulerStatus, SchedulerStateManager


class SchedulerWidget(QWidget):
    """Scheduler control page providing Start, Pause, Resume, Stop, and Run Now actions."""

    def __init__(
        self,
        scheduler: Optional[ActivityScheduler] = None,
        daily_runner: Optional[DailyRunner] = None,
        state_manager: Optional[SchedulerStateManager] = None,
        schedule_time: str = "18:00",
        timezone_name: str = "Asia/Kolkata",
        daily_target: int = 5,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._scheduler = scheduler
        self._runner = daily_runner
        self._state_mgr = state_manager or SchedulerStateManager()
        self._schedule_time = schedule_time
        self._tz_name = timezone_name
        self._target = daily_target

        self._setup_ui()

        # Polling timer for status updates
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self.refresh_status)
        self._poll_timer.start(3000)

        self.refresh_status()

    def _setup_ui(self) -> None:
        """Construct scheduler controls layout."""
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(20, 20, 20, 20)

        # Status & Configuration Card
        status_card = QFrame()
        status_card.setProperty("class", "Card")
        card_layout = QVBoxLayout(status_card)
        card_layout.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel("Daily Scheduler Control")
        title.setStyleSheet("font-size: 16px; font-weight: 700; color: #38BDF8;")
        header_row.addWidget(title)
        header_row.addStretch()

        self.status_badge = QLabel("STOPPED")
        self.status_badge.setStyleSheet(
            "background-color: #334155; color: #94A3B8; padding: 4px 12px; border-radius: 12px; font-weight: 700;"
        )
        header_row.addWidget(self.status_badge)
        card_layout.addLayout(header_row)

        # Meta Grid
        grid = QGridLayout()
        grid.setSpacing(10)

        grid.addWidget(QLabel("<b>Daily Activity Target:</b>"), 0, 0)
        self.target_val = QLabel(str(self._target))
        grid.addWidget(self.target_val, 0, 1)

        grid.addWidget(QLabel("<b>Scheduled Time:</b>"), 0, 2)
        self.time_val = QLabel(self._schedule_time)
        grid.addWidget(self.time_val, 0, 3)

        grid.addWidget(QLabel("<b>Local Timezone:</b>"), 1, 0)
        self.tz_val = QLabel(self._tz_name)
        grid.addWidget(self.tz_val, 1, 1)

        grid.addWidget(QLabel("<b>Next Scheduled Run:</b>"), 1, 2)
        self.next_run_val = QLabel("Calculating...")
        grid.addWidget(self.next_run_val, 1, 3)

        card_layout.addLayout(grid)
        layout.addWidget(status_card)

        # Controls Card
        ctrl_card = QFrame()
        ctrl_card.setProperty("class", "Card")
        ctrl_layout = QVBoxLayout(ctrl_card)
        ctrl_layout.setSpacing(12)

        ctrl_title = QLabel("Execution Controls")
        ctrl_title.setStyleSheet("font-weight: 600; font-size: 14px;")
        ctrl_layout.addWidget(ctrl_title)

        self.dry_run_check = QCheckBox("Enable Dry-Run Mode (Preview only, no commits)")
        self.dry_run_check.setStyleSheet("font-weight: 600; color: #FBBF24;")
        ctrl_layout.addWidget(self.dry_run_check)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        self.start_btn = QPushButton("Start Scheduler")
        self.start_btn.setProperty("class", "SuccessButton")
        self.start_btn.clicked.connect(self._on_start_scheduler)
        btn_row.addWidget(self.start_btn)

        self.pause_btn = QPushButton("Pause")
        self.pause_btn.setProperty("class", "SecondaryButton")
        self.pause_btn.setEnabled(False)
        self.pause_btn.clicked.connect(self._on_pause_scheduler)
        btn_row.addWidget(self.pause_btn)

        self.stop_btn = QPushButton("Stop Scheduler")
        self.stop_btn.setProperty("class", "DangerButton")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._on_stop_scheduler)
        btn_row.addWidget(self.stop_btn)

        btn_row.addStretch()

        self.run_now_btn = QPushButton("Run Today Now")
        self.run_now_btn.clicked.connect(self._on_run_now)
        btn_row.addWidget(self.run_now_btn)

        ctrl_layout.addLayout(btn_row)
        layout.addWidget(ctrl_card)

        layout.addStretch()

    def refresh_status(self) -> None:
        """Poll and update scheduler status display."""
        state = self._state_mgr.load_state()
        status_enum = state.status if state else SchedulerStatus.STOPPED

        self.status_badge.setText(status_enum.value)
        if status_enum == SchedulerStatus.RUNNING:
            self.status_badge.setStyleSheet(
                "background-color: #065F46; color: #34D399; padding: 4px 12px; border-radius: 12px; font-weight: 700;"
            )
            self.start_btn.setEnabled(False)
            self.pause_btn.setEnabled(True)
            self.stop_btn.setEnabled(True)
        elif status_enum == SchedulerStatus.PAUSED:
            self.status_badge.setStyleSheet(
                "background-color: #78350F; color: #FBBF24; padding: 4px 12px; border-radius: 12px; font-weight: 700;"
            )
            self.start_btn.setEnabled(False)
            self.pause_btn.setText("Resume")
            self.pause_btn.setEnabled(True)
            self.stop_btn.setEnabled(True)
        else:
            self.status_badge.setStyleSheet(
                "background-color: #334155; color: #94A3B8; padding: 4px 12px; border-radius: 12px; font-weight: 700;"
            )
            self.start_btn.setEnabled(True)
            self.pause_btn.setText("Pause")
            self.pause_btn.setEnabled(False)
            self.stop_btn.setEnabled(False)

        if self._scheduler:
            next_dt = self._scheduler.calculate_next_run()
            self.next_run_val.setText(next_dt.strftime("%Y-%m-%d %H:%M:%S"))

    def _on_start_scheduler(self) -> None:
        """Handle Start Scheduler action."""
        dlg = ConfirmationDialog(
            title="Start Scheduled Automation",
            message=f"Start automated scheduler for {self._schedule_time} ({self._tz_name})?",
            detail_text=f"Daily target: {self._target} activities. The scheduler runs non-destructively in the background.",
            parent=self,
        )
        if dlg.exec() == ConfirmationDialog.DialogCode.Accepted:
            if self._scheduler:
                self._scheduler.start(dry_run=self.dry_run_check.isChecked(), max_cycles=1)
            self.refresh_status()

    def _on_pause_scheduler(self) -> None:
        """Handle Pause/Resume Scheduler action."""
        if self._scheduler:
            if self._scheduler.is_paused:
                self._scheduler.resume()
            else:
                self._scheduler.pause()
            self.refresh_status()

    def _on_stop_scheduler(self) -> None:
        """Handle Stop Scheduler action."""
        if self._scheduler:
            self._scheduler.stop()
            self.refresh_status()

    def _on_run_now(self) -> None:
        """Handle Run Today Now action."""
        is_dry = self.dry_run_check.isChecked()
        mode_text = "Preview Dry Run (No commits created)" if is_dry else "Local Commits"
        dlg = ConfirmationDialog(
            title="Run Daily Activities Now",
            message=f"Execute today's activity workflow immediately?\n\nMode: {mode_text}",
            detail_text="Validated activities will be executed for configured repositories.",
            parent=self,
        )
        if dlg.exec() == ConfirmationDialog.DialogCode.Accepted:
            if self._runner:
                state = self._runner.run(dry_run=is_dry, force=True)
                QMessageBox.information(
                    self,
                    "Execution Result",
                    f"Workflow finished.\n\nDate: {state.date}\nCompleted: {state.completed}/{state.target}\nFailed: {state.failed}",
                )
            self.refresh_status()
