"""Reports generation and export page widget for desktop GUI."""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QDate, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QDateEdit,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.gui.workers import ReportExportWorker
from app.monitoring.history_store import HistoryStore
from app.monitoring.reports import ReportGenerator


class ReportsWidget(QWidget):
    """Reports configuration and one-click JSON/CSV export page."""

    def __init__(
        self,
        report_generator: Optional[ReportGenerator] = None,
        history_store: Optional[HistoryStore] = None,
        output_dir: Optional[Path | str] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._store = history_store or HistoryStore()
        self._generator = report_generator or ReportGenerator(
            history_store=self._store, default_output_dir=output_dir
        )
        self._worker: Optional[ReportExportWorker] = None

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Construct reports export UI layout."""
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(20, 20, 20, 20)

        # Date Range Card
        card = QFrame()
        card.setProperty("class", "Card")
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(14)

        title = QLabel("Activity Audit Reports Export")
        title.setStyleSheet("font-size: 16px; font-weight: 700; color: #38BDF8;")
        card_layout.addWidget(title)

        desc = QLabel(
            "Export comprehensive activity records and aggregated statistics in structured JSON or CSV format."
        )
        desc.setStyleSheet("color: #94A3B8; font-size: 13px;")
        card_layout.addWidget(desc)

        # Date Pickers
        date_row = QHBoxLayout()
        date_row.setSpacing(12)

        date_row.addWidget(QLabel("<b>From Date:</b>"))
        self.from_date_edit = QDateEdit()
        self.from_date_edit.setCalendarPopup(True)
        self.from_date_edit.setDate(QDate.currentDate().addDays(-7))
        date_row.addWidget(self.from_date_edit)

        date_row.addWidget(QLabel("<b>To Date:</b>"))
        self.to_date_edit = QDateEdit()
        self.to_date_edit.setCalendarPopup(True)
        self.to_date_edit.setDate(QDate.currentDate())
        date_row.addWidget(self.to_date_edit)

        date_row.addStretch()

        # Preset buttons
        btn_today = QPushButton("Today")
        btn_today.setProperty("class", "SecondaryButton")
        btn_today.clicked.connect(self._set_today)
        date_row.addWidget(btn_today)

        btn_7d = QPushButton("Last 7 Days")
        btn_7d.setProperty("class", "SecondaryButton")
        btn_7d.clicked.connect(self._set_last_7_days)
        date_row.addWidget(btn_7d)

        btn_30d = QPushButton("Last 30 Days")
        btn_30d.setProperty("class", "SecondaryButton")
        btn_30d.clicked.connect(self._set_last_30_days)
        date_row.addWidget(btn_30d)

        card_layout.addLayout(date_row)
        layout.addWidget(card)

        # Export Actions Card
        export_card = QFrame()
        export_card.setProperty("class", "Card")
        export_layout = QVBoxLayout(export_card)
        export_layout.setSpacing(12)

        export_title = QLabel("Generate Reports")
        export_title.setStyleSheet("font-weight: 600; font-size: 14px;")
        export_layout.addWidget(export_title)

        act_row = QHBoxLayout()
        act_row.setSpacing(12)

        self.json_btn = QPushButton("Export JSON Report")
        self.json_btn.clicked.connect(lambda: self._export("json"))
        act_row.addWidget(self.json_btn)

        self.csv_btn = QPushButton("Export CSV Report")
        self.csv_btn.clicked.connect(lambda: self._export("csv"))
        act_row.addWidget(self.csv_btn)

        act_row.addStretch()

        open_folder_btn = QPushButton("Open Reports Folder")
        open_folder_btn.setProperty("class", "SecondaryButton")
        open_folder_btn.clicked.connect(self._open_reports_folder)
        act_row.addWidget(open_folder_btn)

        export_layout.addLayout(act_row)

        self.status_lbl = QLabel("")
        self.status_lbl.setStyleSheet("color: #34D399; font-size: 12px; font-weight: 600;")
        export_layout.addWidget(self.status_lbl)

        layout.addWidget(export_card)
        layout.addStretch()

    def _set_today(self) -> None:
        """Set date filter to today."""
        now = QDate.currentDate()
        self.from_date_edit.setDate(now)
        self.to_date_edit.setDate(now)

    def _set_last_7_days(self) -> None:
        """Set date filter to last 7 days."""
        now = QDate.currentDate()
        self.from_date_edit.setDate(now.addDays(-6))
        self.to_date_edit.setDate(now)

    def _set_last_30_days(self) -> None:
        """Set date filter to last 30 days."""
        now = QDate.currentDate()
        self.from_date_edit.setDate(now.addDays(-29))
        self.to_date_edit.setDate(now)

    def _export(self, fmt: str) -> None:
        """Run export in background worker."""
        from_str = self.from_date_edit.date().toString("yyyy-MM-dd")
        to_str = self.to_date_edit.date().toString("yyyy-MM-dd")

        self.json_btn.setEnabled(False)
        self.csv_btn.setEnabled(False)
        self.status_lbl.setText(f"Exporting {fmt.upper()} report...")

        self._worker = ReportExportWorker(
            report_generator=self._generator,
            report_format=fmt,
            from_date=from_str,
            to_date=to_str,
        )
        self._worker.success.connect(self._on_export_success)
        self._worker.failure.connect(self._on_export_failure)
        self._worker.start()

    def _on_export_success(self, file_path: str) -> None:
        """Handle export success."""
        self.json_btn.setEnabled(True)
        self.csv_btn.setEnabled(True)
        self.status_lbl.setText(f"Report exported successfully: {Path(file_path).name}")
        QMessageBox.information(
            self,
            "Report Exported",
            f"Successfully exported report:\n\n{file_path}",
        )

    def _on_export_failure(self, error: str) -> None:
        """Handle export failure."""
        self.json_btn.setEnabled(True)
        self.csv_btn.setEnabled(True)
        self.status_lbl.setText(f"Export failed: {error}")
        QMessageBox.critical(self, "Export Error", f"Failed to export report: {error}")

    def _open_reports_folder(self) -> None:
        """Open reports directory in Windows Explorer."""
        folder = self._generator.output_dir
        folder.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(str(folder.resolve()))
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder.resolve())))
