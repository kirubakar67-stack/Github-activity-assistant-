"""Repositories page widget for desktop GUI."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Optional

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app.monitoring.history_store import HistoryStore


class RepositoriesWidget(QWidget):
    """Repository management and status inspection page."""

    def __init__(
        self,
        repositories: tuple[str, ...],
        local_base_path: Path,
        history_store: Optional[HistoryStore] = None,
        on_view_history: Optional[Callable[[str], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._repositories = repositories
        self._local_base = local_base_path
        self._store = history_store or HistoryStore()
        self._on_view_history = on_view_history

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Build repository cards list UI."""
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        container = QWidget()
        self.cards_layout = QVBoxLayout(container)
        self.cards_layout.setSpacing(14)
        self.cards_layout.setContentsMargins(20, 20, 20, 20)

        header = QLabel(f"Managed GitHub Repositories ({len(self._repositories)})")
        header.setStyleSheet("font-size: 16px; font-weight: 700; color: #38BDF8;")
        self.cards_layout.addWidget(header)

        for repo in self._repositories:
            card = self._create_repo_card(repo)
            self.cards_layout.addWidget(card)

        self.cards_layout.addStretch()

        scroll.setWidget(container)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(scroll)

    def _create_repo_card(self, repo_name: str) -> QFrame:
        """Create a card container displaying repository details and action shortcuts."""
        card = QFrame()
        card.setProperty("class", "Card")
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(10)

        # Header: Name + Badge
        top_row = QHBoxLayout()
        name_lbl = QLabel(repo_name)
        name_lbl.setStyleSheet("font-size: 15px; font-weight: 700; color: #F8FAFC;")
        top_row.addWidget(name_lbl)
        top_row.addStretch()

        access_badge = QLabel("Accessible")
        access_badge.setStyleSheet(
            "background-color: #065F46; color: #34D399; padding: 3px 8px; border-radius: 10px; font-size: 11px; font-weight: 600;"
        )
        top_row.addWidget(access_badge)
        card_layout.addLayout(top_row)

        # Meta Details
        repo_simple = repo_name.split("/")[-1]
        local_dir = self._local_base / repo_simple
        activity_count = len(self._store.get_records(repository=repo_name))

        info_layout = QHBoxLayout()
        info_layout.setSpacing(20)

        info1 = QLabel(f"<b>Default Branch:</b> main")
        info2 = QLabel(f"<b>Visibility:</b> Public")
        info3 = QLabel(f"<b>Recorded Activities:</b> {activity_count}")
        for lbl in (info1, info2, info3):
            lbl.setStyleSheet("color: #94A3B8; font-size: 12px;")
            info_layout.addWidget(lbl)
        info_layout.addStretch()
        card_layout.addLayout(info_layout)

        path_lbl = QLabel(f"<b>Local Path:</b> <code>{local_dir}</code>")
        path_lbl.setStyleSheet("color: #64748B; font-size: 12px;")
        card_layout.addWidget(path_lbl)

        # Action buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        open_btn = QPushButton("Open Folder")
        open_btn.setProperty("class", "SecondaryButton")
        open_btn.clicked.connect(lambda _, p=local_dir: self._open_folder(p))
        btn_row.addWidget(open_btn)

        if self._on_view_history:
            hist_btn = QPushButton("View History")
            hist_btn.setProperty("class", "SecondaryButton")
            hist_btn.clicked.connect(lambda _, r=repo_name: self._on_view_history(r))  # type: ignore
            btn_row.addWidget(hist_btn)

        card_layout.addLayout(btn_row)
        return card

    def _open_folder(self, path: Path) -> None:
        """Open local repository path in Windows Explorer."""
        path.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(str(path))
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
