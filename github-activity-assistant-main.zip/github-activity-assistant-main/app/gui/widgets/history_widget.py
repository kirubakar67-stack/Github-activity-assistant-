"""History audit log page widget for desktop GUI."""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.monitoring.history_store import ActivityRecord, HistoryStore


class HistoryWidget(QWidget):
    """Interactive historical activities table with filtering, search, and sorting."""

    def __init__(
        self,
        history_store: Optional[HistoryStore] = None,
        repositories: tuple[str, ...] = (),
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._store = history_store or HistoryStore()
        self._repos = repositories

        self._setup_ui()
        self.reload_history()

    def _setup_ui(self) -> None:
        """Construct history table layout."""
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 20, 20, 20)

        # Filters card
        filter_card = QFrame()
        filter_card.setProperty("class", "Card")
        filter_layout = QHBoxLayout(filter_card)
        filter_layout.setSpacing(10)

        # Search field
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search title, repository, or message...")
        self.search_input.textChanged.connect(self._apply_filters)
        filter_layout.addWidget(self.search_input, stretch=2)

        # Repository Filter
        self.repo_combo = QComboBox()
        self.repo_combo.addItem("All Repositories")
        for r in self._repos:
            self.repo_combo.addItem(r)
        self.repo_combo.currentIndexChanged.connect(self._apply_filters)
        filter_layout.addWidget(self.repo_combo, stretch=1)

        # Status Filter
        self.status_combo = QComboBox()
        self.status_combo.addItems(["All Statuses", "Committed", "Failed", "Dry_Run", "Planned"])
        self.status_combo.currentIndexChanged.connect(self._apply_filters)
        filter_layout.addWidget(self.status_combo, stretch=1)

        # Refresh button
        refresh_btn = QPushButton("Refresh")
        refresh_btn.setProperty("class", "SecondaryButton")
        refresh_btn.clicked.connect(self.reload_history)
        filter_layout.addWidget(refresh_btn)

        layout.addWidget(filter_card)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["Date / Time", "Repository", "Type", "Title", "Status", "Commit"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.setSortingEnabled(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.table)

        self.footer_lbl = QLabel("0 records found.")
        self.footer_lbl.setStyleSheet("color: #94A3B8; font-size: 12px;")
        layout.addWidget(self.footer_lbl)

    def reload_history(self) -> None:
        """Fetch records from HistoryStore and populate table."""
        self._all_records = self._store.get_records()
        self._all_records.sort(key=lambda r: r.timestamp or r.date, reverse=True)
        self._apply_filters()

    def _apply_filters(self) -> None:
        """Filter in-memory records and display in table."""
        search_txt = self.search_input.text().strip().lower()
        selected_repo = self.repo_combo.currentText()
        selected_status = self.status_combo.currentText().lower()

        filtered: list[ActivityRecord] = []
        for r in self._all_records:
            if selected_repo != "All Repositories" and r.repository != selected_repo:
                continue
            if selected_status != "all statuses" and r.status.lower() != selected_status:
                continue
            if search_txt:
                haystack = f"{r.title} {r.repository} {r.commit_message or ''} {r.commit_hash or ''}".lower()
                if search_txt not in haystack:
                    continue
            filtered.append(r)

        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(filtered))

        for row, r in enumerate(filtered):
            time_str = r.timestamp[11:16] if len(r.timestamp) >= 16 else ""
            dt_display = f"{r.date} {time_str}".strip()
            self.table.setItem(row, 0, QTableWidgetItem(dt_display))
            self.table.setItem(row, 1, QTableWidgetItem(r.repository))
            self.table.setItem(row, 2, QTableWidgetItem(r.activity_type.replace("_", " ").title()))
            self.table.setItem(row, 3, QTableWidgetItem(r.title))

            status_item = QTableWidgetItem(r.status.upper())
            if "commit" in r.status or "success" in r.status:
                status_item.setForeground(Qt.GlobalColor.green)
            elif "fail" in r.status:
                status_item.setForeground(Qt.GlobalColor.red)
            self.table.setItem(row, 4, status_item)

            c_hash = r.commit_hash[:7] if r.commit_hash else "-"
            self.table.setItem(row, 5, QTableWidgetItem(c_hash))

        self.table.setSortingEnabled(True)
        self.footer_lbl.setText(f"{len(filtered)} records displayed (Total: {len(self._all_records)})")
