"""Widgets package for GitHub Activity Assistant Desktop GUI."""

from app.gui.widgets.activity_widget import ActivityWidget
from app.gui.widgets.dashboard_widget import DashboardWidget
from app.gui.widgets.history_widget import HistoryWidget
from app.gui.widgets.logs_widget import LogsWidget
from app.gui.widgets.reports_widget import ReportsWidget
from app.gui.widgets.repositories_widget import RepositoriesWidget
from app.gui.widgets.scheduler_widget import SchedulerWidget
from app.gui.widgets.settings_widget import SettingsWidget

__all__ = [
    "ActivityWidget",
    "DashboardWidget",
    "HistoryWidget",
    "LogsWidget",
    "ReportsWidget",
    "RepositoriesWidget",
    "SchedulerWidget",
    "SettingsWidget",
]
