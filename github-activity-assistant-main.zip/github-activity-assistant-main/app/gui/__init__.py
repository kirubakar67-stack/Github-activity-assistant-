"""Desktop Graphical User Interface package for GitHub Activity Assistant."""

from app.gui.app import run_gui_app
from app.gui.dialogs import ActivityPreviewDialog, ConfirmationDialog, FirstRunWizardDialog
from app.gui.main_window import MainWindow
from app.gui.styles import get_theme_qss
from app.gui.workers import (
    ActivityExecutionWorker,
    ActivityPlanWorker,
    GitHubValidationWorker,
    ReportExportWorker,
)

__all__ = [
    "ActivityExecutionWorker",
    "ActivityPlanWorker",
    "ActivityPreviewDialog",
    "ConfirmationDialog",
    "FirstRunWizardDialog",
    "GitHubValidationWorker",
    "MainWindow",
    "ReportExportWorker",
    "get_theme_qss",
    "run_gui_app",
]
