"""Background QThread workers for non-blocking asynchronous desktop GUI operations."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from PySide6.QtCore import QObject, QThread, Signal

from app.activity.models import ActivityPlan
from app.activity.planner import ActivityPlanner
from app.activity.validator import ActivityValidator
from app.git.commit_manager import CommitManager, CommitResult
from app.github_client import GitHubClient, RepositoryInfo, UserInfo
from app.monitoring.reports import ReportGenerator
from app.repository_manager import RepositoryManager


class GitHubValidationWorker(QThread):
    """Asynchronously validates GitHub credentials and configured repositories."""

    success = Signal(object, list)  # (UserInfo, list[RepositoryInfo])
    failure = Signal(str)           # (error_message)

    def __init__(
        self,
        token: str,
        repositories: tuple[str, ...],
        parent: Optional[QObject] = None,
    ) -> None:
        super().__init__(parent)
        self._token = token
        self._repos = repositories

    def run(self) -> None:
        """Execute authentication and repository validation on background thread."""
        client = None
        try:
            client = GitHubClient(
                token=self._token,
                default_repository=self._repos[0] if self._repos else None,
            )
            user_info = client.authenticate()

            repo_mgr = RepositoryManager(client=client, repositories=self._repos)
            validated_list = repo_mgr.validate_repositories()

            self.success.emit(user_info, validated_list)
        except Exception as exc:
            self.failure.emit(str(exc))
        finally:
            if client:
                try:
                    client.close()
                except Exception:
                    pass


class ActivityPlanWorker(QThread):
    """Asynchronously plans daily repository activities."""

    success = Signal(list)  # (list[ActivityPlan])
    failure = Signal(str)   # (error_message)

    def __init__(
        self,
        planner: ActivityPlanner,
        target_count: int,
        parent: Optional[QObject] = None,
    ) -> None:
        super().__init__(parent)
        self._planner = planner
        self._target_count = target_count

    def run(self) -> None:
        """Generate validated activity plans on background thread."""
        try:
            plans = self._planner.plan_daily_activities(
                target_count=self._target_count,
                record_in_history=False,
            )
            self.success.emit(plans)
        except Exception as exc:
            self.failure.emit(str(exc))


class ActivityExecutionWorker(QThread):
    """Asynchronously executes activity plans, diffs, and local Git commits."""

    step_progress = Signal(int, int, object, object)  # (current, total, ActivityPlan, CommitResult)
    finished = Signal(int, int, list)                 # (completed, failed, list[CommitResult])
    failure = Signal(str)                             # (error_message)

    def __init__(
        self,
        commit_manager: CommitManager,
        plans: list[ActivityPlan],
        dry_run: bool = False,
        parent: Optional[QObject] = None,
    ) -> None:
        super().__init__(parent)
        self._commit_mgr = commit_manager
        self._plans = plans
        self._dry_run = dry_run
        self._is_cancelled = False

    def cancel(self) -> None:
        """Request cancellation of execution between items."""
        self._is_cancelled = True

    def run(self) -> None:
        """Execute plans sequentially."""
        try:
            results: list[CommitResult] = []
            completed = 0
            failed = 0
            total = len(self._plans)

            for idx, plan in enumerate(self._plans, start=1):
                if self._is_cancelled:
                    break

                res = self._commit_mgr.execute_activity(plan, dry_run=self._dry_run)
                results.append(res)
                if res.success:
                    completed += 1
                else:
                    failed += 1

                self.step_progress.emit(idx, total, plan, res)

            self.finished.emit(completed, failed, results)
        except Exception as exc:
            self.failure.emit(str(exc))


class ReportExportWorker(QThread):
    """Asynchronously exports JSON or CSV audit reports."""

    success = Signal(str)  # (output_file_path_str)
    failure = Signal(str)  # (error_message)

    def __init__(
        self,
        report_generator: ReportGenerator,
        report_format: str = "json",
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        output_dir: Optional[Path | str] = None,
        parent: Optional[QObject] = None,
    ) -> None:
        super().__init__(parent)
        self._generator = report_generator
        self._format = report_format.lower()
        self._from_date = from_date
        self._to_date = to_date
        self._output_dir = output_dir

    def run(self) -> None:
        """Generate report on background thread."""
        try:
            if self._format == "csv":
                path = self._generator.export_csv(
                    from_date=self._from_date,
                    to_date=self._to_date,
                    output_dir=self._output_dir,
                )
            else:
                path = self._generator.export_json(
                    from_date=self._from_date,
                    to_date=self._to_date,
                    output_dir=self._output_dir,
                )
            self.success.emit(str(path.resolve()))
        except Exception as exc:
            self.failure.emit(str(exc))
