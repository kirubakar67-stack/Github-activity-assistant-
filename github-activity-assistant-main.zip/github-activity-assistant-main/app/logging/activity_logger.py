"""Activity logging infrastructure for GitHub Activity Assistant.

Provides structured logging to logs/assistant.log with automatic credential masking.
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

DEFAULT_LOG_PATH: Path = Path("logs") / "assistant.log"


class SecretMaskingFilter(logging.Filter):
    """Filter that intercepts and masks sensitive tokens or keys in log messages."""

    def __init__(self, blocked_tokens: Optional[list[str]] = None) -> None:
        """Initialize filter with optional list of known secrets to redact."""
        super().__init__()
        self._blocked_tokens: list[str] = [
            t.strip() for t in (blocked_tokens or []) if t and len(t.strip()) > 6
        ]

    def filter(self, record: logging.LogRecord) -> bool:
        """Mask secrets in log record message."""
        if isinstance(record.msg, str):
            for token in self._blocked_tokens:
                if token in record.msg:
                    record.msg = record.msg.replace(token, "***")
        return True


def setup_logger(
    log_file: Optional[Path | str] = None,
    level: int = logging.INFO,
    blocked_tokens: Optional[list[str]] = None,
) -> logging.Logger:
    """Configure and return the shared application logger.

    Args:
        log_file: Optional custom log file destination.
        level: Logging level (default: INFO).
        blocked_tokens: Optional list of sensitive tokens to mask.

    Returns:
        Configured Logger instance.
    """
    logger = logging.getLogger("github_activity_assistant")
    logger.setLevel(level)

    # Avoid duplicate handlers on re-initialization
    if logger.handlers:
        return logger

    target_path = Path(log_file or DEFAULT_LOG_PATH)
    target_path.parent.mkdir(parents=True, exist_ok=True)

    file_handler = RotatingFileHandler(
        filename=target_path,
        maxBytes=5 * 1024 * 1024,  # 5MB
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(level)

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(formatter)

    masking_filter = SecretMaskingFilter(blocked_tokens=blocked_tokens)
    file_handler.addFilter(masking_filter)
    logger.addFilter(masking_filter)

    logger.addHandler(file_handler)
    return logger


def get_logger() -> logging.Logger:
    """Retrieve existing logger or create default if not yet initialized."""
    logger = logging.getLogger("github_activity_assistant")
    if not logger.handlers:
        return setup_logger()
    return logger
